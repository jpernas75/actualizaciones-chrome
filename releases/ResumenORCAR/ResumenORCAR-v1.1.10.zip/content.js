/**
 * marked v15.0.4 - a markdown parser
 * Copyright (c) 2011-2024, Christopher Jeffrey. (MIT Licensed)
 * https://github.com/markedjs/marked
 */
!function(e,t){"object"==typeof exports&&"undefined"!=typeof module?t(exports):"function"==typeof define&&define.amd?define(["exports"],t):t((e="undefined"!=typeof globalThis?globalThis:e||self).marked={})}(this,(function(e){"use strict";function t(){return{async:!1,breaks:!1,extensions:null,gfm:!0,hooks:null,pedantic:!1,renderer:null,silent:!1,tokenizer:null,walkTokens:null}}function n(t){e.defaults=t}e.defaults={async:!1,breaks:!1,extensions:null,gfm:!0,hooks:null,pedantic:!1,renderer:null,silent:!1,tokenizer:null,walkTokens:null};const s={exec:()=>null};function r(e,t=""){let n="string"==typeof e?e:e.source;const s={replace:(e,t)=>{let r="string"==typeof t?t:t.source;return r=r.replace(i.caret,"$1"),n=n.replace(e,r),s},getRegex:()=>new RegExp(n,t)};return s}const i={codeRemoveIndent:/^(?: {1,4}| {0,3}\t)/gm,outputLinkReplace:/\\([\[\]])/g,indentCodeCompensation:/^(\s+)(?:```)/,beginningSpace:/^\s+/,endingHash:/#$/,startingSpaceChar:/^ /,endingSpaceChar:/ $/,nonSpaceChar:/[^ ]/,newLineCharGlobal:/\n/g,tabCharGlobal:/\t/g,multipleSpaceGlobal:/\s+/g,blankLine:/^[ \t]*$/,doubleBlankLine:/\n[ \t]*\n[ \t]*$/,blockquoteStart:/^ {0,3}>/,blockquoteSetextReplace:/\n {0,3}((?:=+|-+) *)(?=\n|$)/g,blockquoteSetextReplace2:/^ {0,3}>[ \t]?/gm,listReplaceTabs:/^\t+/,listReplaceNesting:/^ {1,4}(?=( {4})*[^ ])/g,listIsTask:/^\[[ xX]\] /,listReplaceTask:/^\[[ xX]\] +/,anyLine:/\n.*\n/,hrefBrackets:/^<(.*)>$/,tableDelimiter:/[:|]/,tableAlignChars:/^\||\| *$/g,tableRowBlankLine:/\n[ \t]*$/,tableAlignRight:/^ *-+: *$/,tableAlignCenter:/^ *:-+: *$/,tableAlignLeft:/^ *:-+ *$/,startATag:/^<a /i,endATag:/^<\/a>/i,startPreScriptTag:/^<(pre|code|kbd|script)(\s|>)/i,endPreScriptTag:/^<\/(pre|code|kbd|script)(\s|>)/i,startAngleBracket:/^</,endAngleBracket:/>$/,pedanticHrefTitle:/^([^'"]*[^\s])\s+(['"])(.*)\2/,unicodeAlphaNumeric:/[\p{L}\p{N}]/u,escapeTest:/[&<>"']/,escapeReplace:/[&<>"']/g,escapeTestNoEncode:/[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,escapeReplaceNoEncode:/[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,unescapeTest:/&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/gi,caret:/(^|[^\[])\^/g,percentDecode:/%25/g,findPipe:/\|/g,splitPipe:/ \|/,slashPipe:/\\\|/g,carriageReturn:/\r\n|\r/g,spaceLine:/^ +$/gm,notSpaceStart:/^\S*/,endingNewline:/\n$/,listItemRegex:e=>new RegExp(`^( {0,3}${e})((?:[\t ][^\\n]*)?(?:\\n|$))`),nextBulletRegex:e=>new RegExp(`^ {0,${Math.min(3,e-1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ \t][^\\n]*)?(?:\\n|$))`),hrRegex:e=>new RegExp(`^ {0,${Math.min(3,e-1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`),fencesBeginRegex:e=>new RegExp(`^ {0,${Math.min(3,e-1)}}(?:\`\`\`|~~~)`),headingBeginRegex:e=>new RegExp(`^ {0,${Math.min(3,e-1)}}#`),htmlBeginRegex:e=>new RegExp(`^ {0,${Math.min(3,e-1)}}<(?:[a-z].*>|!--)`,"i")},l=/^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/,o=/(?:[*+-]|\d{1,9}[.)])/,a=r(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g,o).replace(/blockCode/g,/(?: {4}| {0,3}\t)/).replace(/fences/g,/ {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g,/ {0,3}>/).replace(/heading/g,/ {0,3}#{1,6}/).replace(/html/g,/ {0,3}<[^\n>]+>\n/).getRegex(),c=/^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/,h=/(?!\s*\])(?:\\.|[^\[\]\\])+/,p=r(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label",h).replace("title",/(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(),u=r(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g,o).getRegex(),g="address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul",k=/<!--(?:-?>|[\s\S]*?(?:-->|$))/,f=r("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ \t]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ \t]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ \t]*)+\\n|$))","i").replace("comment",k).replace("tag",g).replace("attribute",/ +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(),d=r(c).replace("hr",l).replace("heading"," {0,3}#{1,6}(?:\\s|$)").replace("|lheading","").replace("|table","").replace("blockquote"," {0,3}>").replace("fences"," {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list"," {0,3}(?:[*+-]|1[.)]) ").replace("html","</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag",g).getRegex(),x={blockquote:r(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph",d).getRegex(),code:/^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/,def:p,fences:/^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/,heading:/^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/,hr:l,html:f,lheading:a,list:u,newline:/^(?:[ \t]*(?:\n|$))+/,paragraph:d,table:s,text:/^[^\n]+/},b=r("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr",l).replace("heading"," {0,3}#{1,6}(?:\\s|$)").replace("blockquote"," {0,3}>").replace("code","(?: {4}| {0,3}\t)[^\\n]").replace("fences"," {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list"," {0,3}(?:[*+-]|1[.)]) ").replace("html","</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag",g).getRegex(),w={...x,table:b,paragraph:r(c).replace("hr",l).replace("heading"," {0,3}#{1,6}(?:\\s|$)").replace("|lheading","").replace("table",b).replace("blockquote"," {0,3}>").replace("fences"," {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list"," {0,3}(?:[*+-]|1[.)]) ").replace("html","</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag",g).getRegex()},m={...x,html:r("^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:\"[^\"]*\"|'[^']*'|\\s[^'\"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))").replace("comment",k).replace(/tag/g,"(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),def:/^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,heading:/^(#{1,6})(.*)(?:\n+|$)/,fences:s,lheading:/^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,paragraph:r(c).replace("hr",l).replace("heading"," *#{1,6} *[^\n]").replace("lheading",a).replace("|table","").replace("blockquote"," {0,3}>").replace("|fences","").replace("|list","").replace("|html","").replace("|tag","").getRegex()},y=/^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/,$=/^( {2,}|\\)\n(?!\s*$)/,R=/[\p{P}\p{S}]/u,S=/[\s\p{P}\p{S}]/u,T=/[^\s\p{P}\p{S}]/u,z=r(/^((?![*_])punctSpace)/,"u").replace(/punctSpace/g,S).getRegex(),A=r(/^(?:\*+(?:((?!\*)punct)|[^\s*]))|^_+(?:((?!_)punct)|([^\s_]))/,"u").replace(/punct/g,R).getRegex(),_=r("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)","gu").replace(/notPunctSpace/g,T).replace(/punctSpace/g,S).replace(/punct/g,R).getRegex(),P=r("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)","gu").replace(/notPunctSpace/g,T).replace(/punctSpace/g,S).replace(/punct/g,R).getRegex(),I=r(/\\(punct)/,"gu").replace(/punct/g,R).getRegex(),L=r(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme",/[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email",/[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(),B=r(k).replace("(?:--\x3e|$)","--\x3e").getRegex(),C=r("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment",B).replace("attribute",/\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(),E=/(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/,q=r(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label",E).replace("href",/<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title",/"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(),Z=r(/^!?\[(label)\]\[(ref)\]/).replace("label",E).replace("ref",h).getRegex(),v=r(/^!?\[(ref)\](?:\[\])?/).replace("ref",h).getRegex(),D={_backpedal:s,anyPunctuation:I,autolink:L,blockSkip:/\[[^[\]]*?\]\((?:\\.|[^\\\(\)]|\((?:\\.|[^\\\(\)])*\))*\)|`[^`]*?`|<[^<>]*?>/g,br:$,code:/^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/,del:s,emStrongLDelim:A,emStrongRDelimAst:_,emStrongRDelimUnd:P,escape:y,link:q,nolink:v,punctuation:z,reflink:Z,reflinkSearch:r("reflink|nolink(?!\\()","g").replace("reflink",Z).replace("nolink",v).getRegex(),tag:C,text:/^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/,url:s},M={...D,link:r(/^!?\[(label)\]\((.*?)\)/).replace("label",E).getRegex(),reflink:r(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label",E).getRegex()},O={...D,escape:r(y).replace("])","~|])").getRegex(),url:r(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/,"i").replace("email",/[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),_backpedal:/(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,del:/^(~~?)(?=[^\s~])((?:\\.|[^\\])*?(?:\\.|[^\s~\\]))\1(?=[^~]|$)/,text:/^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/},Q={...O,br:r($).replace("{2,}","*").getRegex(),text:r(O.text).replace("\\b_","\\b_| {2,}\\n").replace(/\{2,\}/g,"*").getRegex()},j={normal:x,gfm:w,pedantic:m},N={normal:D,gfm:O,breaks:Q,pedantic:M},G={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"},H=e=>G[e];function X(e,t){if(t){if(i.escapeTest.test(e))return e.replace(i.escapeReplace,H)}else if(i.escapeTestNoEncode.test(e))return e.replace(i.escapeReplaceNoEncode,H);return e}function F(e){try{e=encodeURI(e).replace(i.percentDecode,"%")}catch{return null}return e}function U(e,t){const n=e.replace(i.findPipe,((e,t,n)=>{let s=!1,r=t;for(;--r>=0&&"\\"===n[r];)s=!s;return s?"|":" |"})).split(i.splitPipe);let s=0;if(n[0].trim()||n.shift(),n.length>0&&!n.at(-1)?.trim()&&n.pop(),t)if(n.length>t)n.splice(t);else for(;n.length<t;)n.push("");for(;s<n.length;s++)n[s]=n[s].trim().replace(i.slashPipe,"|");return n}function J(e,t,n){const s=e.length;if(0===s)return"";let r=0;for(;r<s;){const i=e.charAt(s-r-1);if(i!==t||n){if(i===t||!n)break;r++}else r++}return e.slice(0,s-r)}function K(e,t,n,s,r){const i=t.href,l=t.title||null,o=e[1].replace(r.other.outputLinkReplace,"$1");if("!"!==e[0].charAt(0)){s.state.inLink=!0;const e={type:"link",raw:n,href:i,title:l,text:o,tokens:s.inlineTokens(o)};return s.state.inLink=!1,e}return{type:"image",raw:n,href:i,title:l,text:o}}class V{options;rules;lexer;constructor(t){this.options=t||e.defaults}space(e){const t=this.rules.block.newline.exec(e);if(t&&t[0].length>0)return{type:"space",raw:t[0]}}code(e){const t=this.rules.block.code.exec(e);if(t){const e=t[0].replace(this.rules.other.codeRemoveIndent,"");return{type:"code",raw:t[0],codeBlockStyle:"indented",text:this.options.pedantic?e:J(e,"\n")}}}fences(e){const t=this.rules.block.fences.exec(e);if(t){const e=t[0],n=function(e,t,n){const s=e.match(n.other.indentCodeCompensation);if(null===s)return t;const r=s[1];return t.split("\n").map((e=>{const t=e.match(n.other.beginningSpace);if(null===t)return e;const[s]=t;return s.length>=r.length?e.slice(r.length):e})).join("\n")}(e,t[3]||"",this.rules);return{type:"code",raw:e,lang:t[2]?t[2].trim().replace(this.rules.inline.anyPunctuation,"$1"):t[2],text:n}}}heading(e){const t=this.rules.block.heading.exec(e);if(t){let e=t[2].trim();if(this.rules.other.endingHash.test(e)){const t=J(e,"#");this.options.pedantic?e=t.trim():t&&!this.rules.other.endingSpaceChar.test(t)||(e=t.trim())}return{type:"heading",raw:t[0],depth:t[1].length,text:e,tokens:this.lexer.inline(e)}}}hr(e){const t=this.rules.block.hr.exec(e);if(t)return{type:"hr",raw:J(t[0],"\n")}}blockquote(e){const t=this.rules.block.blockquote.exec(e);if(t){let e=J(t[0],"\n").split("\n"),n="",s="";const r=[];for(;e.length>0;){let t=!1;const i=[];let l;for(l=0;l<e.length;l++)if(this.rules.other.blockquoteStart.test(e[l]))i.push(e[l]),t=!0;else{if(t)break;i.push(e[l])}e=e.slice(l);const o=i.join("\n"),a=o.replace(this.rules.other.blockquoteSetextReplace,"\n    $1").replace(this.rules.other.blockquoteSetextReplace2,"");n=n?`${n}\n${o}`:o,s=s?`${s}\n${a}`:a;const c=this.lexer.state.top;if(this.lexer.state.top=!0,this.lexer.blockTokens(a,r,!0),this.lexer.state.top=c,0===e.length)break;const h=r.at(-1);if("code"===h?.type)break;if("blockquote"===h?.type){const t=h,i=t.raw+"\n"+e.join("\n"),l=this.blockquote(i);r[r.length-1]=l,n=n.substring(0,n.length-t.raw.length)+l.raw,s=s.substring(0,s.length-t.text.length)+l.text;break}if("list"!==h?.type);else{const t=h,i=t.raw+"\n"+e.join("\n"),l=this.list(i);r[r.length-1]=l,n=n.substring(0,n.length-h.raw.length)+l.raw,s=s.substring(0,s.length-t.raw.length)+l.raw,e=i.substring(r.at(-1).raw.length).split("\n")}}return{type:"blockquote",raw:n,tokens:r,text:s}}}list(e){let t=this.rules.block.list.exec(e);if(t){let n=t[1].trim();const s=n.length>1,r={type:"list",raw:"",ordered:s,start:s?+n.slice(0,-1):"",loose:!1,items:[]};n=s?`\\d{1,9}\\${n.slice(-1)}`:`\\${n}`,this.options.pedantic&&(n=s?n:"[*+-]");const i=this.rules.other.listItemRegex(n);let l=!1;for(;e;){let n=!1,s="",o="";if(!(t=i.exec(e)))break;if(this.rules.block.hr.test(e))break;s=t[0],e=e.substring(s.length);let a=t[2].split("\n",1)[0].replace(this.rules.other.listReplaceTabs,(e=>" ".repeat(3*e.length))),c=e.split("\n",1)[0],h=!a.trim(),p=0;if(this.options.pedantic?(p=2,o=a.trimStart()):h?p=t[1].length+1:(p=t[2].search(this.rules.other.nonSpaceChar),p=p>4?1:p,o=a.slice(p),p+=t[1].length),h&&this.rules.other.blankLine.test(c)&&(s+=c+"\n",e=e.substring(c.length+1),n=!0),!n){const t=this.rules.other.nextBulletRegex(p),n=this.rules.other.hrRegex(p),r=this.rules.other.fencesBeginRegex(p),i=this.rules.other.headingBeginRegex(p),l=this.rules.other.htmlBeginRegex(p);for(;e;){const u=e.split("\n",1)[0];let g;if(c=u,this.options.pedantic?(c=c.replace(this.rules.other.listReplaceNesting,"  "),g=c):g=c.replace(this.rules.other.tabCharGlobal,"    "),r.test(c))break;if(i.test(c))break;if(l.test(c))break;if(t.test(c))break;if(n.test(c))break;if(g.search(this.rules.other.nonSpaceChar)>=p||!c.trim())o+="\n"+g.slice(p);else{if(h)break;if(a.replace(this.rules.other.tabCharGlobal,"    ").search(this.rules.other.nonSpaceChar)>=4)break;if(r.test(a))break;if(i.test(a))break;if(n.test(a))break;o+="\n"+c}h||c.trim()||(h=!0),s+=u+"\n",e=e.substring(u.length+1),a=g.slice(p)}}r.loose||(l?r.loose=!0:this.rules.other.doubleBlankLine.test(s)&&(l=!0));let u,g=null;this.options.gfm&&(g=this.rules.other.listIsTask.exec(o),g&&(u="[ ] "!==g[0],o=o.replace(this.rules.other.listReplaceTask,""))),r.items.push({type:"list_item",raw:s,task:!!g,checked:u,loose:!1,text:o,tokens:[]}),r.raw+=s}const o=r.items.at(-1);if(!o)return;o.raw=o.raw.trimEnd(),o.text=o.text.trimEnd(),r.raw=r.raw.trimEnd();for(let e=0;e<r.items.length;e++)if(this.lexer.state.top=!1,r.items[e].tokens=this.lexer.blockTokens(r.items[e].text,[]),!r.loose){const t=r.items[e].tokens.filter((e=>"space"===e.type)),n=t.length>0&&t.some((e=>this.rules.other.anyLine.test(e.raw)));r.loose=n}if(r.loose)for(let e=0;e<r.items.length;e++)r.items[e].loose=!0;return r}}html(e){const t=this.rules.block.html.exec(e);if(t){return{type:"html",block:!0,raw:t[0],pre:"pre"===t[1]||"script"===t[1]||"style"===t[1],text:t[0]}}}def(e){const t=this.rules.block.def.exec(e);if(t){const e=t[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal," "),n=t[2]?t[2].replace(this.rules.other.hrefBrackets,"$1").replace(this.rules.inline.anyPunctuation,"$1"):"",s=t[3]?t[3].substring(1,t[3].length-1).replace(this.rules.inline.anyPunctuation,"$1"):t[3];return{type:"def",tag:e,raw:t[0],href:n,title:s}}}table(e){const t=this.rules.block.table.exec(e);if(!t)return;if(!this.rules.other.tableDelimiter.test(t[2]))return;const n=U(t[1]),s=t[2].replace(this.rules.other.tableAlignChars,"").split("|"),r=t[3]?.trim()?t[3].replace(this.rules.other.tableRowBlankLine,"").split("\n"):[],i={type:"table",raw:t[0],header:[],align:[],rows:[]};if(n.length===s.length){for(const e of s)this.rules.other.tableAlignRight.test(e)?i.align.push("right"):this.rules.other.tableAlignCenter.test(e)?i.align.push("center"):this.rules.other.tableAlignLeft.test(e)?i.align.push("left"):i.align.push(null);for(let e=0;e<n.length;e++)i.header.push({text:n[e],tokens:this.lexer.inline(n[e]),header:!0,align:i.align[e]});for(const e of r)i.rows.push(U(e,i.header.length).map(((e,t)=>({text:e,tokens:this.lexer.inline(e),header:!1,align:i.align[t]}))));return i}}lheading(e){const t=this.rules.block.lheading.exec(e);if(t)return{type:"heading",raw:t[0],depth:"="===t[2].charAt(0)?1:2,text:t[1],tokens:this.lexer.inline(t[1])}}paragraph(e){const t=this.rules.block.paragraph.exec(e);if(t){const e="\n"===t[1].charAt(t[1].length-1)?t[1].slice(0,-1):t[1];return{type:"paragraph",raw:t[0],text:e,tokens:this.lexer.inline(e)}}}text(e){const t=this.rules.block.text.exec(e);if(t)return{type:"text",raw:t[0],text:t[0],tokens:this.lexer.inline(t[0])}}escape(e){const t=this.rules.inline.escape.exec(e);if(t)return{type:"escape",raw:t[0],text:t[1]}}tag(e){const t=this.rules.inline.tag.exec(e);if(t)return!this.lexer.state.inLink&&this.rules.other.startATag.test(t[0])?this.lexer.state.inLink=!0:this.lexer.state.inLink&&this.rules.other.endATag.test(t[0])&&(this.lexer.state.inLink=!1),!this.lexer.state.inRawBlock&&this.rules.other.startPreScriptTag.test(t[0])?this.lexer.state.inRawBlock=!0:this.lexer.state.inRawBlock&&this.rules.other.endPreScriptTag.test(t[0])&&(this.lexer.state.inRawBlock=!1),{type:"html",raw:t[0],inLink:this.lexer.state.inLink,inRawBlock:this.lexer.state.inRawBlock,block:!1,text:t[0]}}link(e){const t=this.rules.inline.link.exec(e);if(t){const e=t[2].trim();if(!this.options.pedantic&&this.rules.other.startAngleBracket.test(e)){if(!this.rules.other.endAngleBracket.test(e))return;const t=J(e.slice(0,-1),"\\");if((e.length-t.length)%2==0)return}else{const e=function(e,t){if(-1===e.indexOf(t[1]))return-1;let n=0;for(let s=0;s<e.length;s++)if("\\"===e[s])s++;else if(e[s]===t[0])n++;else if(e[s]===t[1]&&(n--,n<0))return s;return-1}(t[2],"()");if(e>-1){const n=(0===t[0].indexOf("!")?5:4)+t[1].length+e;t[2]=t[2].substring(0,e),t[0]=t[0].substring(0,n).trim(),t[3]=""}}let n=t[2],s="";if(this.options.pedantic){const e=this.rules.other.pedanticHrefTitle.exec(n);e&&(n=e[1],s=e[3])}else s=t[3]?t[3].slice(1,-1):"";return n=n.trim(),this.rules.other.startAngleBracket.test(n)&&(n=this.options.pedantic&&!this.rules.other.endAngleBracket.test(e)?n.slice(1):n.slice(1,-1)),K(t,{href:n?n.replace(this.rules.inline.anyPunctuation,"$1"):n,title:s?s.replace(this.rules.inline.anyPunctuation,"$1"):s},t[0],this.lexer,this.rules)}}reflink(e,t){let n;if((n=this.rules.inline.reflink.exec(e))||(n=this.rules.inline.nolink.exec(e))){const e=t[(n[2]||n[1]).replace(this.rules.other.multipleSpaceGlobal," ").toLowerCase()];if(!e){const e=n[0].charAt(0);return{type:"text",raw:e,text:e}}return K(n,e,n[0],this.lexer,this.rules)}}emStrong(e,t,n=""){let s=this.rules.inline.emStrongLDelim.exec(e);if(!s)return;if(s[3]&&n.match(this.rules.other.unicodeAlphaNumeric))return;if(!(s[1]||s[2]||"")||!n||this.rules.inline.punctuation.exec(n)){const n=[...s[0]].length-1;let r,i,l=n,o=0;const a="*"===s[0][0]?this.rules.inline.emStrongRDelimAst:this.rules.inline.emStrongRDelimUnd;for(a.lastIndex=0,t=t.slice(-1*e.length+n);null!=(s=a.exec(t));){if(r=s[1]||s[2]||s[3]||s[4]||s[5]||s[6],!r)continue;if(i=[...r].length,s[3]||s[4]){l+=i;continue}if((s[5]||s[6])&&n%3&&!((n+i)%3)){o+=i;continue}if(l-=i,l>0)continue;i=Math.min(i,i+l+o);const t=[...s[0]][0].length,a=e.slice(0,n+s.index+t+i);if(Math.min(n,i)%2){const e=a.slice(1,-1);return{type:"em",raw:a,text:e,tokens:this.lexer.inlineTokens(e)}}const c=a.slice(2,-2);return{type:"strong",raw:a,text:c,tokens:this.lexer.inlineTokens(c)}}}}codespan(e){const t=this.rules.inline.code.exec(e);if(t){let e=t[2].replace(this.rules.other.newLineCharGlobal," ");const n=this.rules.other.nonSpaceChar.test(e),s=this.rules.other.startingSpaceChar.test(e)&&this.rules.other.endingSpaceChar.test(e);return n&&s&&(e=e.substring(1,e.length-1)),{type:"codespan",raw:t[0],text:e}}}br(e){const t=this.rules.inline.br.exec(e);if(t)return{type:"br",raw:t[0]}}del(e){const t=this.rules.inline.del.exec(e);if(t)return{type:"del",raw:t[0],text:t[2],tokens:this.lexer.inlineTokens(t[2])}}autolink(e){const t=this.rules.inline.autolink.exec(e);if(t){let e,n;return"@"===t[2]?(e=t[1],n="mailto:"+e):(e=t[1],n=e),{type:"link",raw:t[0],text:e,href:n,tokens:[{type:"text",raw:e,text:e}]}}}url(e){let t;if(t=this.rules.inline.url.exec(e)){let e,n;if("@"===t[2])e=t[0],n="mailto:"+e;else{let s;do{s=t[0],t[0]=this.rules.inline._backpedal.exec(t[0])?.[0]??""}while(s!==t[0]);e=t[0],n="www."===t[1]?"http://"+t[0]:t[0]}return{type:"link",raw:t[0],text:e,href:n,tokens:[{type:"text",raw:e,text:e}]}}}inlineText(e){const t=this.rules.inline.text.exec(e);if(t){const e=this.lexer.state.inRawBlock;return{type:"text",raw:t[0],text:t[0],escaped:e}}}}class W{tokens;options;state;tokenizer;inlineQueue;constructor(t){this.tokens=[],this.tokens.links=Object.create(null),this.options=t||e.defaults,this.options.tokenizer=this.options.tokenizer||new V,this.tokenizer=this.options.tokenizer,this.tokenizer.options=this.options,this.tokenizer.lexer=this,this.inlineQueue=[],this.state={inLink:!1,inRawBlock:!1,top:!0};const n={other:i,block:j.normal,inline:N.normal};this.options.pedantic?(n.block=j.pedantic,n.inline=N.pedantic):this.options.gfm&&(n.block=j.gfm,this.options.breaks?n.inline=N.breaks:n.inline=N.gfm),this.tokenizer.rules=n}static get rules(){return{block:j,inline:N}}static lex(e,t){return new W(t).lex(e)}static lexInline(e,t){return new W(t).inlineTokens(e)}lex(e){e=e.replace(i.carriageReturn,"\n"),this.blockTokens(e,this.tokens);for(let e=0;e<this.inlineQueue.length;e++){const t=this.inlineQueue[e];this.inlineTokens(t.src,t.tokens)}return this.inlineQueue=[],this.tokens}blockTokens(e,t=[],n=!1){for(this.options.pedantic&&(e=e.replace(i.tabCharGlobal,"    ").replace(i.spaceLine,""));e;){let s;if(this.options.extensions?.block?.some((n=>!!(s=n.call({lexer:this},e,t))&&(e=e.substring(s.raw.length),t.push(s),!0))))continue;if(s=this.tokenizer.space(e)){e=e.substring(s.raw.length);const n=t.at(-1);1===s.raw.length&&void 0!==n?n.raw+="\n":t.push(s);continue}if(s=this.tokenizer.code(e)){e=e.substring(s.raw.length);const n=t.at(-1);"paragraph"===n?.type||"text"===n?.type?(n.raw+="\n"+s.raw,n.text+="\n"+s.text,this.inlineQueue.at(-1).src=n.text):t.push(s);continue}if(s=this.tokenizer.fences(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.heading(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.hr(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.blockquote(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.list(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.html(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.def(e)){e=e.substring(s.raw.length);const n=t.at(-1);"paragraph"===n?.type||"text"===n?.type?(n.raw+="\n"+s.raw,n.text+="\n"+s.raw,this.inlineQueue.at(-1).src=n.text):this.tokens.links[s.tag]||(this.tokens.links[s.tag]={href:s.href,title:s.title});continue}if(s=this.tokenizer.table(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.lheading(e)){e=e.substring(s.raw.length),t.push(s);continue}let r=e;if(this.options.extensions?.startBlock){let t=1/0;const n=e.slice(1);let s;this.options.extensions.startBlock.forEach((e=>{s=e.call({lexer:this},n),"number"==typeof s&&s>=0&&(t=Math.min(t,s))})),t<1/0&&t>=0&&(r=e.substring(0,t+1))}if(this.state.top&&(s=this.tokenizer.paragraph(r))){const i=t.at(-1);n&&"paragraph"===i?.type?(i.raw+="\n"+s.raw,i.text+="\n"+s.text,this.inlineQueue.pop(),this.inlineQueue.at(-1).src=i.text):t.push(s),n=r.length!==e.length,e=e.substring(s.raw.length)}else if(s=this.tokenizer.text(e)){e=e.substring(s.raw.length);const n=t.at(-1);"text"===n?.type?(n.raw+="\n"+s.raw,n.text+="\n"+s.text,this.inlineQueue.pop(),this.inlineQueue.at(-1).src=n.text):t.push(s)}else if(e){const t="Infinite loop on byte: "+e.charCodeAt(0);if(this.options.silent){console.error(t);break}throw new Error(t)}}return this.state.top=!0,t}inline(e,t=[]){return this.inlineQueue.push({src:e,tokens:t}),t}inlineTokens(e,t=[]){let n=e,s=null;if(this.tokens.links){const e=Object.keys(this.tokens.links);if(e.length>0)for(;null!=(s=this.tokenizer.rules.inline.reflinkSearch.exec(n));)e.includes(s[0].slice(s[0].lastIndexOf("[")+1,-1))&&(n=n.slice(0,s.index)+"["+"a".repeat(s[0].length-2)+"]"+n.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex))}for(;null!=(s=this.tokenizer.rules.inline.blockSkip.exec(n));)n=n.slice(0,s.index)+"["+"a".repeat(s[0].length-2)+"]"+n.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);for(;null!=(s=this.tokenizer.rules.inline.anyPunctuation.exec(n));)n=n.slice(0,s.index)+"++"+n.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);let r=!1,i="";for(;e;){let s;if(r||(i=""),r=!1,this.options.extensions?.inline?.some((n=>!!(s=n.call({lexer:this},e,t))&&(e=e.substring(s.raw.length),t.push(s),!0))))continue;if(s=this.tokenizer.escape(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.tag(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.link(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.reflink(e,this.tokens.links)){e=e.substring(s.raw.length);const n=t.at(-1);"text"===s.type&&"text"===n?.type?(n.raw+=s.raw,n.text+=s.text):t.push(s);continue}if(s=this.tokenizer.emStrong(e,n,i)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.codespan(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.br(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.del(e)){e=e.substring(s.raw.length),t.push(s);continue}if(s=this.tokenizer.autolink(e)){e=e.substring(s.raw.length),t.push(s);continue}if(!this.state.inLink&&(s=this.tokenizer.url(e))){e=e.substring(s.raw.length),t.push(s);continue}let l=e;if(this.options.extensions?.startInline){let t=1/0;const n=e.slice(1);let s;this.options.extensions.startInline.forEach((e=>{s=e.call({lexer:this},n),"number"==typeof s&&s>=0&&(t=Math.min(t,s))})),t<1/0&&t>=0&&(l=e.substring(0,t+1))}if(s=this.tokenizer.inlineText(l)){e=e.substring(s.raw.length),"_"!==s.raw.slice(-1)&&(i=s.raw.slice(-1)),r=!0;const n=t.at(-1);"text"===n?.type?(n.raw+=s.raw,n.text+=s.text):t.push(s)}else if(e){const t="Infinite loop on byte: "+e.charCodeAt(0);if(this.options.silent){console.error(t);break}throw new Error(t)}}return t}}class Y{options;parser;constructor(t){this.options=t||e.defaults}space(e){return""}code({text:e,lang:t,escaped:n}){const s=(t||"").match(i.notSpaceStart)?.[0],r=e.replace(i.endingNewline,"")+"\n";return s?'<pre><code class="language-'+X(s)+'">'+(n?r:X(r,!0))+"</code></pre>\n":"<pre><code>"+(n?r:X(r,!0))+"</code></pre>\n"}blockquote({tokens:e}){return`<blockquote>\n${this.parser.parse(e)}</blockquote>\n`}html({text:e}){return e}heading({tokens:e,depth:t}){return`<h${t}>${this.parser.parseInline(e)}</h${t}>\n`}hr(e){return"<hr>\n"}list(e){const t=e.ordered,n=e.start;let s="";for(let t=0;t<e.items.length;t++){const n=e.items[t];s+=this.listitem(n)}const r=t?"ol":"ul";return"<"+r+(t&&1!==n?' start="'+n+'"':"")+">\n"+s+"</"+r+">\n"}listitem(e){let t="";if(e.task){const n=this.checkbox({checked:!!e.checked});e.loose?"paragraph"===e.tokens[0]?.type?(e.tokens[0].text=n+" "+e.tokens[0].text,e.tokens[0].tokens&&e.tokens[0].tokens.length>0&&"text"===e.tokens[0].tokens[0].type&&(e.tokens[0].tokens[0].text=n+" "+X(e.tokens[0].tokens[0].text),e.tokens[0].tokens[0].escaped=!0)):e.tokens.unshift({type:"text",raw:n+" ",text:n+" ",escaped:!0}):t+=n+" "}return t+=this.parser.parse(e.tokens,!!e.loose),`<li>${t}</li>\n`}checkbox({checked:e}){return"<input "+(e?'checked="" ':"")+'disabled="" type="checkbox">'}paragraph({tokens:e}){return`<p>${this.parser.parseInline(e)}</p>\n`}table(e){let t="",n="";for(let t=0;t<e.header.length;t++)n+=this.tablecell(e.header[t]);t+=this.tablerow({text:n});let s="";for(let t=0;t<e.rows.length;t++){const r=e.rows[t];n="";for(let e=0;e<r.length;e++)n+=this.tablecell(r[e]);s+=this.tablerow({text:n})}return s&&(s=`<tbody>${s}</tbody>`),"<table>\n<thead>\n"+t+"</thead>\n"+s+"</table>\n"}tablerow({text:e}){return`<tr>\n${e}</tr>\n`}tablecell(e){const t=this.parser.parseInline(e.tokens),n=e.header?"th":"td";return(e.align?`<${n} align="${e.align}">`:`<${n}>`)+t+`</${n}>\n`}strong({tokens:e}){return`<strong>${this.parser.parseInline(e)}</strong>`}em({tokens:e}){return`<em>${this.parser.parseInline(e)}</em>`}codespan({text:e}){return`<code>${X(e,!0)}</code>`}br(e){return"<br>"}del({tokens:e}){return`<del>${this.parser.parseInline(e)}</del>`}link({href:e,title:t,tokens:n}){const s=this.parser.parseInline(n),r=F(e);if(null===r)return s;let i='<a href="'+(e=r)+'"';return t&&(i+=' title="'+X(t)+'"'),i+=">"+s+"</a>",i}image({href:e,title:t,text:n}){const s=F(e);if(null===s)return X(n);let r=`<img src="${e=s}" alt="${n}"`;return t&&(r+=` title="${X(t)}"`),r+=">",r}text(e){return"tokens"in e&&e.tokens?this.parser.parseInline(e.tokens):"escaped"in e&&e.escaped?e.text:X(e.text)}}class ee{strong({text:e}){return e}em({text:e}){return e}codespan({text:e}){return e}del({text:e}){return e}html({text:e}){return e}text({text:e}){return e}link({text:e}){return""+e}image({text:e}){return""+e}br(){return""}}class te{options;renderer;textRenderer;constructor(t){this.options=t||e.defaults,this.options.renderer=this.options.renderer||new Y,this.renderer=this.options.renderer,this.renderer.options=this.options,this.renderer.parser=this,this.textRenderer=new ee}static parse(e,t){return new te(t).parse(e)}static parseInline(e,t){return new te(t).parseInline(e)}parse(e,t=!0){let n="";for(let s=0;s<e.length;s++){const r=e[s];if(this.options.extensions?.renderers?.[r.type]){const e=r,t=this.options.extensions.renderers[e.type].call({parser:this},e);if(!1!==t||!["space","hr","heading","code","table","blockquote","list","html","paragraph","text"].includes(e.type)){n+=t||"";continue}}const i=r;switch(i.type){case"space":n+=this.renderer.space(i);continue;case"hr":n+=this.renderer.hr(i);continue;case"heading":n+=this.renderer.heading(i);continue;case"code":n+=this.renderer.code(i);continue;case"table":n+=this.renderer.table(i);continue;case"blockquote":n+=this.renderer.blockquote(i);continue;case"list":n+=this.renderer.list(i);continue;case"html":n+=this.renderer.html(i);continue;case"paragraph":n+=this.renderer.paragraph(i);continue;case"text":{let r=i,l=this.renderer.text(r);for(;s+1<e.length&&"text"===e[s+1].type;)r=e[++s],l+="\n"+this.renderer.text(r);n+=t?this.renderer.paragraph({type:"paragraph",raw:l,text:l,tokens:[{type:"text",raw:l,text:l,escaped:!0}]}):l;continue}default:{const e='Token with "'+i.type+'" type was not found.';if(this.options.silent)return console.error(e),"";throw new Error(e)}}}return n}parseInline(e,t=this.renderer){let n="";for(let s=0;s<e.length;s++){const r=e[s];if(this.options.extensions?.renderers?.[r.type]){const e=this.options.extensions.renderers[r.type].call({parser:this},r);if(!1!==e||!["escape","html","link","image","strong","em","codespan","br","del","text"].includes(r.type)){n+=e||"";continue}}const i=r;switch(i.type){case"escape":case"text":n+=t.text(i);break;case"html":n+=t.html(i);break;case"link":n+=t.link(i);break;case"image":n+=t.image(i);break;case"strong":n+=t.strong(i);break;case"em":n+=t.em(i);break;case"codespan":n+=t.codespan(i);break;case"br":n+=t.br(i);break;case"del":n+=t.del(i);break;default:{const e='Token with "'+i.type+'" type was not found.';if(this.options.silent)return console.error(e),"";throw new Error(e)}}}return n}}class ne{options;block;constructor(t){this.options=t||e.defaults}static passThroughHooks=new Set(["preprocess","postprocess","processAllTokens"]);preprocess(e){return e}postprocess(e){return e}processAllTokens(e){return e}provideLexer(){return this.block?W.lex:W.lexInline}provideParser(){return this.block?te.parse:te.parseInline}}class se{defaults={async:!1,breaks:!1,extensions:null,gfm:!0,hooks:null,pedantic:!1,renderer:null,silent:!1,tokenizer:null,walkTokens:null};options=this.setOptions;parse=this.parseMarkdown(!0);parseInline=this.parseMarkdown(!1);Parser=te;Renderer=Y;TextRenderer=ee;Lexer=W;Tokenizer=V;Hooks=ne;constructor(...e){this.use(...e)}walkTokens(e,t){let n=[];for(const s of e)switch(n=n.concat(t.call(this,s)),s.type){case"table":{const e=s;for(const s of e.header)n=n.concat(this.walkTokens(s.tokens,t));for(const s of e.rows)for(const e of s)n=n.concat(this.walkTokens(e.tokens,t));break}case"list":{const e=s;n=n.concat(this.walkTokens(e.items,t));break}default:{const e=s;this.defaults.extensions?.childTokens?.[e.type]?this.defaults.extensions.childTokens[e.type].forEach((s=>{const r=e[s].flat(1/0);n=n.concat(this.walkTokens(r,t))})):e.tokens&&(n=n.concat(this.walkTokens(e.tokens,t)))}}return n}use(...e){const t=this.defaults.extensions||{renderers:{},childTokens:{}};return e.forEach((e=>{const n={...e};if(n.async=this.defaults.async||n.async||!1,e.extensions&&(e.extensions.forEach((e=>{if(!e.name)throw new Error("extension name required");if("renderer"in e){const n=t.renderers[e.name];t.renderers[e.name]=n?function(...t){let s=e.renderer.apply(this,t);return!1===s&&(s=n.apply(this,t)),s}:e.renderer}if("tokenizer"in e){if(!e.level||"block"!==e.level&&"inline"!==e.level)throw new Error("extension level must be 'block' or 'inline'");const n=t[e.level];n?n.unshift(e.tokenizer):t[e.level]=[e.tokenizer],e.start&&("block"===e.level?t.startBlock?t.startBlock.push(e.start):t.startBlock=[e.start]:"inline"===e.level&&(t.startInline?t.startInline.push(e.start):t.startInline=[e.start]))}"childTokens"in e&&e.childTokens&&(t.childTokens[e.name]=e.childTokens)})),n.extensions=t),e.renderer){const t=this.defaults.renderer||new Y(this.defaults);for(const n in e.renderer){if(!(n in t))throw new Error(`renderer '${n}' does not exist`);if(["options","parser"].includes(n))continue;const s=n,r=e.renderer[s],i=t[s];t[s]=(...e)=>{let n=r.apply(t,e);return!1===n&&(n=i.apply(t,e)),n||""}}n.renderer=t}if(e.tokenizer){const t=this.defaults.tokenizer||new V(this.defaults);for(const n in e.tokenizer){if(!(n in t))throw new Error(`tokenizer '${n}' does not exist`);if(["options","rules","lexer"].includes(n))continue;const s=n,r=e.tokenizer[s],i=t[s];t[s]=(...e)=>{let n=r.apply(t,e);return!1===n&&(n=i.apply(t,e)),n}}n.tokenizer=t}if(e.hooks){const t=this.defaults.hooks||new ne;for(const n in e.hooks){if(!(n in t))throw new Error(`hook '${n}' does not exist`);if(["options","block"].includes(n))continue;const s=n,r=e.hooks[s],i=t[s];ne.passThroughHooks.has(n)?t[s]=e=>{if(this.defaults.async)return Promise.resolve(r.call(t,e)).then((e=>i.call(t,e)));const n=r.call(t,e);return i.call(t,n)}:t[s]=(...e)=>{let n=r.apply(t,e);return!1===n&&(n=i.apply(t,e)),n}}n.hooks=t}if(e.walkTokens){const t=this.defaults.walkTokens,s=e.walkTokens;n.walkTokens=function(e){let n=[];return n.push(s.call(this,e)),t&&(n=n.concat(t.call(this,e))),n}}this.defaults={...this.defaults,...n}})),this}setOptions(e){return this.defaults={...this.defaults,...e},this}lexer(e,t){return W.lex(e,t??this.defaults)}parser(e,t){return te.parse(e,t??this.defaults)}parseMarkdown(e){return(t,n)=>{const s={...n},r={...this.defaults,...s},i=this.onError(!!r.silent,!!r.async);if(!0===this.defaults.async&&!1===s.async)return i(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));if(null==t)return i(new Error("marked(): input parameter is undefined or null"));if("string"!=typeof t)return i(new Error("marked(): input parameter is of type "+Object.prototype.toString.call(t)+", string expected"));r.hooks&&(r.hooks.options=r,r.hooks.block=e);const l=r.hooks?r.hooks.provideLexer():e?W.lex:W.lexInline,o=r.hooks?r.hooks.provideParser():e?te.parse:te.parseInline;if(r.async)return Promise.resolve(r.hooks?r.hooks.preprocess(t):t).then((e=>l(e,r))).then((e=>r.hooks?r.hooks.processAllTokens(e):e)).then((e=>r.walkTokens?Promise.all(this.walkTokens(e,r.walkTokens)).then((()=>e)):e)).then((e=>o(e,r))).then((e=>r.hooks?r.hooks.postprocess(e):e)).catch(i);try{r.hooks&&(t=r.hooks.preprocess(t));let e=l(t,r);r.hooks&&(e=r.hooks.processAllTokens(e)),r.walkTokens&&this.walkTokens(e,r.walkTokens);let n=o(e,r);return r.hooks&&(n=r.hooks.postprocess(n)),n}catch(e){return i(e)}}}onError(e,t){return n=>{if(n.message+="\nPlease report this to https://github.com/markedjs/marked.",e){const e="<p>An error occurred:</p><pre>"+X(n.message+"",!0)+"</pre>";return t?Promise.resolve(e):e}if(t)return Promise.reject(n);throw n}}}const re=new se;function ie(e,t){return re.parse(e,t)}ie.options=ie.setOptions=function(e){return re.setOptions(e),ie.defaults=re.defaults,n(ie.defaults),ie},ie.getDefaults=t,ie.defaults=e.defaults,ie.use=function(...e){return re.use(...e),ie.defaults=re.defaults,n(ie.defaults),ie},ie.walkTokens=function(e,t){return re.walkTokens(e,t)},ie.parseInline=re.parseInline,ie.Parser=te,ie.parser=te.parse,ie.Renderer=Y,ie.TextRenderer=ee,ie.Lexer=W,ie.lexer=W.lex,ie.Tokenizer=V,ie.Hooks=ne,ie.parse=ie;const le=ie.options,oe=ie.setOptions,ae=ie.use,ce=ie.walkTokens,he=ie.parseInline,pe=ie,ue=te.parse,ge=W.lex;e.Hooks=ne,e.Lexer=W,e.Marked=se,e.Parser=te,e.Renderer=Y,e.TextRenderer=ee,e.Tokenizer=V,e.getDefaults=t,e.lexer=ge,e.marked=ie,e.options=le,e.parse=pe,e.parseInline=he,e.parser=ue,e.setOptions=oe,e.use=ae,e.walkTokens=ce}));

// ========================================
// CONTENT SCRIPT - ResumenORCAR
// ========================================
// Extrae información de OR y genera resúmenes con IA

console.log('[ResumenORCAR] Content script cargado');

// --- Configuración ---
let GEMINI_API_KEY = null;
const MODEL_VERSION = 'gemini-3.1-pro-preview';
const MODEL_FALLBACKS = ['gemini-3-pro-preview', 'gemini-2.5-flash'];
const CONFIG_FILE_NAME = 'ResumenORCAR-config.json';

// --- Estado Global ---
let isProcessing = false;
let conversationHistory = [];
let datosORActual = null;
let archivoAdjuntoActual = null;

// ========================================
// API KEY - CARGA DINÁMICA
// ========================================

async function obtenerApiKeyDesdeStorage() {
    return new Promise((resolve) => {
        try {
            chrome.storage.local.get(['gemini_api_key'], (result) => {
                if (chrome.runtime.lastError) {
                    console.warn('[ResumenORCAR] Error leyendo Storage:', chrome.runtime.lastError);
                    resolve(null);
                } else {
                    resolve(result.gemini_api_key || null);
                }
            });
        } catch (error) {
            console.warn('[ResumenORCAR] Error en obtenerApiKeyDesdeStorage:', error);
            resolve(null);
        }
    });
}

function isValidApiKey(value) {
    if (!value || typeof value !== 'string') return false;
    const trimmed = value.trim();
    if (!trimmed || trimmed === 'YOUR_API_KEY' || trimmed === 'YOUR_GEMINI_API_KEY') return false;
    if (/^AIza[0-9A-Za-z\-_]{20,}$/.test(trimmed)) return true;
    if (/^AQ\.[A-Za-z0-9_\-.]{20,}$/.test(trimmed)) return true;
    return false;
}

function describirFormatoApiKey(value) {
    if (!value) return 'vacía';
    const t = String(value).trim();
    if (t.startsWith('sk-')) {
        return 'formato OpenAI (sk-...); ponla en openai_api_key, no en gemini_api_key';
    }
    if (t.startsWith('AIza') || t.startsWith('AQ.')) {
        return 'empieza por ' + (t.startsWith('AQ.') ? 'AQ.' : 'AIza') + ' pero no cumple el patrón esperado';
    }
    return 'formato no reconocido para Gemini (debe ser AIza... o AQ....)';
}

function geminiApiHeaders(apiKey, extra = {}) {
    return { ...extra, 'x-goog-api-key': apiKey };
}

async function limpiarApiKeyEnStorage() {
    GEMINI_API_KEY = null;
    return new Promise((resolve) => {
        chrome.storage.local.remove(['gemini_api_key'], () => resolve(!chrome.runtime.lastError));
    });
}

async function guardarApiKeyEnStorage(apiKey) {
    return new Promise((resolve) => {
        try {
            chrome.storage.local.set({ gemini_api_key: apiKey }, () => {
                if (chrome.runtime.lastError) {
                    console.warn('[ResumenORCAR] Error guardando en Storage:', chrome.runtime.lastError);
                    resolve(false);
                } else {
                    console.log('[ResumenORCAR] API Key guardada en Storage');
                    resolve(true);
                }
            });
        } catch (error) {
            console.warn('[ResumenORCAR] Error en guardarApiKeyEnStorage:', error);
            resolve(false);
        }
    });
}

async function obtenerApiKeyDesdeDrive() {
    try {
        const resultado = await safeChromeRuntimeSendMessage({
            action: 'readFromDrive',
            data: { name: CONFIG_FILE_NAME, match: 'exact', as: 'text' }
        });

        if (resultado && resultado.success && resultado.data && resultado.data.content) {
            let content = resultado.data.content;
            if (typeof content === 'string') {
                content = content.replace(/^\uFEFF/, '').trim();
                try { content = JSON.parse(content); } catch (e) { /* sigue como string */ }
            }
            if (typeof content === 'string') {
                content = content.replace(/^\uFEFF/, '').trim();
                try { content = JSON.parse(content); } catch (e) { /* ignore */ }
            }
            const config = (typeof content === 'object') ? content : null;
            if (config && config.gemini_api_key) {
                return String(config.gemini_api_key).trim();
            }
        }
        if (resultado && !resultado.success) {
            const errMsg = resultado.data?.error || resultado.error;
            console.warn('[ResumenORCAR] Drive devolvió error:', errMsg);
        } else if (resultado?.data?.ok === false && resultado.data?.error) {
            console.warn('[ResumenORCAR] Drive:', resultado.data.error);
        }
    } catch (error) {
        console.warn('[ResumenORCAR] Error obteniendo API key desde Drive:', error);
    }
    return null;
}

async function sincronizarGeminiApiKeyDesdeDrive() {
    const keyDrive = await obtenerApiKeyDesdeDrive();
    if (!keyDrive) {
        return { ok: false, reason: 'drive_missing' };
    }

    const normalized = String(keyDrive).trim();
    if (!isValidApiKey(normalized)) {
        const hint = describirFormatoApiKey(normalized);
        console.error('[ResumenORCAR] gemini_api_key en Drive no válida para Gemini:', hint);
        const keyStorage = await obtenerApiKeyDesdeStorage();
        if (keyStorage) {
            await limpiarApiKeyEnStorage();
            console.warn('[ResumenORCAR] Caché local borrada para no usar una key antigua');
        }
        return { ok: false, reason: 'drive_invalid_format', hint };
    }

    const keyStorage = await obtenerApiKeyDesdeStorage();
    if (keyStorage !== normalized) {
        if (keyStorage) {
            console.log('[ResumenORCAR] API Key actualizada desde Drive (sustituye caché antigua)');
            console.log('[ResumenORCAR] Antes:', keyStorage.substring(0, 8) + '... → Ahora:', normalized.substring(0, 8) + '...');
        } else {
            console.log('[ResumenORCAR] API Key cargada desde Drive (' + normalized.substring(0, 8) + '...)');
        }
        await guardarApiKeyEnStorage(normalized);
    }
    GEMINI_API_KEY = normalized;
    return { ok: true };
}

async function obtenerGeminiApiKey() {
    if (GEMINI_API_KEY && isValidApiKey(GEMINI_API_KEY)) {
        return GEMINI_API_KEY;
    }

    const sync = await sincronizarGeminiApiKeyDesdeDrive();
    if (sync.ok) {
        return GEMINI_API_KEY;
    }

    if (sync.reason === 'drive_invalid_format') {
        console.error('[ResumenORCAR] Corrige gemini_api_key en ResumenORCAR-config.json (Drive):', sync.hint);
        return null;
    }

    const keyStorage = await obtenerApiKeyDesdeStorage();
    if (isValidApiKey(keyStorage)) {
        GEMINI_API_KEY = String(keyStorage).trim();
        console.warn('[ResumenORCAR] API Key desde Storage (Drive sin key válida)');
        return GEMINI_API_KEY;
    }

    console.error('[ResumenORCAR] API Key no configurada en Drive ni Storage');
    return null;
}

// ========================================
// UTILIDADES
// ========================================

function safeChromeRuntimeSendMessage(message, maxRetries = 3) {
    return new Promise((resolve, reject) => {
        let attempt = 0;
        function send() {
            attempt++;
            try {
                if (!chrome.runtime?.id) {
                    throw new Error("Contexto de extensión invalido");
                }
                chrome.runtime.sendMessage(message, (response) => {
                    const lastError = chrome.runtime.lastError;
                    if (lastError) {
                        if (lastError.message.includes("Receiving end does not exist") && attempt < maxRetries) {
                            setTimeout(send, 250 * attempt);
                        } else {
                            reject(new Error(lastError.message));
                        }
                    } else {
                        resolve(response);
                    }
                });
            } catch (error) {
                if (attempt < maxRetries) setTimeout(send, 250 * attempt);
                else reject(error);
            }
        }
        send();
    });
}

function getUsuarioSesion() {
    try {
        const userElement = document.querySelector('.user__env .d-block:nth-of-type(2) .env__val b');
        if (userElement && userElement.textContent) {
            return userElement.textContent.trim();
        }

        const labels = Array.from(document.querySelectorAll('.env__name'));
        const userLabel = labels.find(el => el.textContent.includes('Usuario:'));
        if (userLabel && userLabel.nextElementSibling) {
            return userLabel.nextElementSibling.textContent.trim();
        }

        const matches = document.cookie.match(/CAR_SESSION=([^;]+)/);
        if (matches && matches[1]) {
            let decoded = decodeURIComponent(matches[1]);
            return decoded.replace(/^"|"$/g, '');
        }
    } catch (e) {
        console.warn('[ResumenORCAR] Error obteniendo usuario:', e);
    }
    return 'Desconocido';
}

async function registrarAccesoLog(orNumber) {
    console.log('[ResumenORCAR] Registrando acceso para OR:', orNumber);
    console.log('[ResumenORCAR] Guardando en carpeta: 1ZGZr-EvgkRxi7ji8LQqh2ADYedYQcPAn');
    try {
        const usuario = getUsuarioSesion();
        const fecha = new Date().toLocaleString('es-ES');
        const rowData = [usuario, "ResumenORCAR", orNumber, "", fecha];

        safeChromeRuntimeSendMessage({
            action: 'appendRowToSheet',
            data: {
                filename: 'Registro-accesos',
                content: rowData
            }
        }).then(result => {
            if (result && result.success) {
                console.log('[ResumenORCAR] ✅ Acceso registrado correctamente en la nueva carpeta');
            } else {
                console.warn('[ResumenORCAR] ⚠️ Error registrando acceso:', result?.error);
            }
        }).catch(err => {
            console.warn('[ResumenORCAR] Error registrando acceso:', err);
        });
    } catch (e) {
        console.warn('[ResumenORCAR] Error en registrarAccesoLog:', e);
    }
}

// ========================================
// CONVERSIÓN A TOML
// ========================================

/**
 * Escapa un string para uso en TOML
 * @param {string} str - String a escapar
 * @returns {string} - String escapado
 */
function escapeTomlString(str) {
    if (str === null || str === undefined) return '';
    const s = String(str);
    return s
        .replace(/\\/g, '\\\\')
        .replace(/"/g, '\\"')
        .replace(/\n/g, '\\n')
        .replace(/\r/g, '\\r')
        .replace(/\t/g, '\\t');
}

/**
 * Escapa un string multilínea para TOML (usando triple comillas)
 * @param {string} str - String multilínea
 * @returns {string} - String escapado para triple comillas
 */
function escapeTomlMultilineString(str) {
    if (str === null || str === undefined) return '';
    const s = String(str);
    // Para triple comillas, solo necesitamos escapar las secuencias de triple comillas
    return s.replace(/"""/g, '\\"""');
}

/**
 * Formatea un valor para TOML según su tipo
 * @param {any} value - Valor a formatear
 * @returns {string} - Valor formateado para TOML
 */
function formatTomlValue(value) {
    if (value === null || value === undefined) {
        return '""';
    }
    if (typeof value === 'boolean') {
        return value ? 'true' : 'false';
    }
    if (typeof value === 'number') {
        return String(value);
    }
    if (typeof value === 'string') {
        // Si tiene saltos de línea, usar triple comillas
        if (value.includes('\n') || value.includes('\r')) {
            return `"""${escapeTomlMultilineString(value)}"""`;
        }
        return `"${escapeTomlString(value)}"`;
    }
    if (Array.isArray(value)) {
        if (value.length === 0) return '[]';
        if (value.every(v => typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean')) {
            const items = value.map(v => formatTomlValue(v));
            return `[${items.join(', ')}]`;
        }
        // Para arrays de objetos, retornar array vacío (se manejarán como tablas)
        return '[]';
    }
    return '""';
}

/**
 * Convierte los datos de la OR a formato TOML
 * @param {Object} datosOR - Datos de la OR en formato objeto
 * @returns {string} - Datos en formato TOML
 */
function convertirDatosORaTOML(datosOR) {
    let toml = '';
    
    // Comentario de cabecera
    toml += '# ===========================================\n';
    toml += '# Resumen OR - ResumenORCAR\n';
    toml += '# Formato: TOML (Tom\'s Obvious, Minimal Language)\n';
    toml += `# Generado: ${new Date().toISOString()}\n`;
    toml += '# ===========================================\n\n';
    
    // Información básica de la OR
    toml += '[or]\n';
    toml += `numero = ${formatTomlValue(datosOR.orNumber || "")}\n`;
    toml += `workfile_id = ${formatTomlValue(datosOR.workfileId || "")}\n`;
    toml += `fecha_extraccion = ${formatTomlValue(datosOR.fechaExtraccion || "")}\n`;
    toml += `fecha_matriculacion = ${formatTomlValue(datosOR.fechaMatriculacion || "")}\n`;
    toml += '\n';
    
    // Comentarios del vehículo
    if (datosOR.comentariosVehiculo) {
        toml += '[or.comentarios_vehiculo]\n';
        toml += `texto = ${formatTomlValue(datosOR.comentariosVehiculo)}\n`;
        toml += '\n';
    }
    
    // Comentarios del cliente
    if (datosOR.comentariosCliente) {
        toml += '[or.comentarios_cliente]\n';
        toml += `texto = ${formatTomlValue(datosOR.comentariosCliente)}\n`;
        toml += '\n';
    }
    
    // Comentarios de la OR
    if (datosOR.comentariosOR) {
        toml += '[or.comentarios]\n';
        toml += `total_externos = ${datosOR.comentariosOR.resumen?.totalExternos || 0}\n`;
        toml += `total_internos = ${datosOR.comentariosOR.resumen?.totalInternos || 0}\n`;
        toml += '\n';
        
        // Comentarios externos
        if (datosOR.comentariosOR.externos && datosOR.comentariosOR.externos.length > 0) {
            datosOR.comentariosOR.externos.forEach((comentario, index) => {
                toml += `[[or.comentarios.externos]]\n`;
                toml += `usuario = ${formatTomlValue(comentario.usuario || "")}\n`;
                toml += `fecha = ${formatTomlValue(comentario.fecha || "")}\n`;
                toml += `contenido = ${formatTomlValue(comentario.contenido || "")}\n`;
                toml += '\n';
            });
        }
        
        // Comentarios internos
        if (datosOR.comentariosOR.internos && datosOR.comentariosOR.internos.length > 0) {
            datosOR.comentariosOR.internos.forEach((comentario, index) => {
                toml += `[[or.comentarios.internos]]\n`;
                toml += `usuario = ${formatTomlValue(comentario.usuario || "")}\n`;
                toml += `fecha = ${formatTomlValue(comentario.fecha || "")}\n`;
                toml += `contenido = ${formatTomlValue(comentario.contenido || "")}\n`;
                toml += '\n';
            });
        }
    }
    
    // Resumen general
    if (datosOR.resumen) {
        toml += '[or.resumen]\n';
        toml += `total_actuaciones = ${datosOR.resumen.totalActuaciones || 0}\n`;
        toml += `tiempo_total_horas = ${datosOR.resumen.tiempoTotalOR || 0}\n`;
        toml += `tiempo_total_formato = ${formatTomlValue(datosOR.resumen.tiempoTotalFormato || "")}\n`;
        toml += `total_comentarios_externos = ${datosOR.resumen.totalComentariosExternos || 0}\n`;
        toml += `total_comentarios_internos = ${datosOR.resumen.totalComentariosInternos || 0}\n`;
        toml += `tiene_comentarios_vehiculo = ${datosOR.resumen.tieneComentariosVehiculo ? 'true' : 'false'}\n`;
        toml += `tiene_comentarios_cliente = ${datosOR.resumen.tieneComentariosCliente ? 'true' : 'false'}\n`;
        toml += '\n';
    }
    
    // Actuaciones
    if (datosOR.actuaciones && Array.isArray(datosOR.actuaciones) && datosOR.actuaciones.length > 0) {
        datosOR.actuaciones.forEach((actuacion, index) => {
            toml += `# -------------------------------------------\n`;
            toml += `# Actuación ${index + 1}: ${actuacion.descripcion || 'Sin descripción'}\n`;
            toml += `# -------------------------------------------\n`;
            toml += `[[or.actuaciones]]\n`;
            toml += `id = ${formatTomlValue(actuacion.id || "")}\n`;
            toml += `descripcion = ${formatTomlValue(actuacion.descripcion || "")}\n`;
            toml += `pagador = ${formatTomlValue(actuacion.pagador || "")}\n`;
            toml += `tiempo_total_horas = ${actuacion.tiempoTotal || 0}\n`;
            toml += `tiempo_total_formato = ${formatTomlValue(actuacion.tiempoTotalFormato || "")}\n`;
            toml += `tiempo_planeado_horas = ${actuacion.tiempoPlaneado || 0}\n`;
            toml += `tiempo_planeado_formato = ${formatTomlValue(actuacion.tiempoPlaneadoFormato || "")}\n`;
            toml += '\n';
            
            // Tiempos por mecánico (serializado como JSON string para mantener estructura)
            if (actuacion.tiemposPorMecanico && Object.keys(actuacion.tiemposPorMecanico).length > 0) {
                const tiemposJson = JSON.stringify(actuacion.tiemposPorMecanico);
                toml += `tiempos_por_mecanico_json = ${formatTomlValue(tiemposJson)}\n`;
            }
            
            // Comentarios de la actuación (como arrays de tablas separados)
            if (actuacion.comentarios) {
                if (actuacion.comentarios.comentarios && actuacion.comentarios.comentarios.length > 0) {
                    actuacion.comentarios.comentarios.forEach((comentario) => {
                        toml += `  [[or.actuaciones.comentarios]]\n`;
                        toml += `  tipo_comentario = ${formatTomlValue("comentario")}\n`;
                        toml += `  tipo = ${formatTomlValue(comentario.tipo || "")}\n`;
                        toml += `  usuario = ${formatTomlValue(comentario.usuario || "")}\n`;
                        toml += `  fecha = ${formatTomlValue(comentario.fecha || "")}\n`;
                        toml += `  contenido = ${formatTomlValue(comentario.contenido || "")}\n`;
                        toml += '\n';
                    });
                }
                
                if (actuacion.comentarios.causas && actuacion.comentarios.causas.length > 0) {
                    actuacion.comentarios.causas.forEach((causa) => {
                        toml += `  [[or.actuaciones.comentarios]]\n`;
                        toml += `  tipo_comentario = ${formatTomlValue("causa")}\n`;
                        toml += `  usuario = ${formatTomlValue(causa.usuario || "")}\n`;
                        toml += `  fecha = ${formatTomlValue(causa.fecha || "")}\n`;
                        toml += `  contenido = ${formatTomlValue(causa.contenido || "")}\n`;
                        toml += '\n';
                    });
                }
                
                if (actuacion.comentarios.operaciones && actuacion.comentarios.operaciones.length > 0) {
                    actuacion.comentarios.operaciones.forEach((operacion) => {
                        toml += `  [[or.actuaciones.comentarios]]\n`;
                        toml += `  tipo_comentario = ${formatTomlValue("operacion")}\n`;
                        toml += `  usuario = ${formatTomlValue(operacion.usuario || "")}\n`;
                        toml += `  fecha = ${formatTomlValue(operacion.fecha || "")}\n`;
                        toml += `  contenido = ${formatTomlValue(operacion.contenido || "")}\n`;
                        toml += '\n';
                    });
                }
            }
            
            // Recambios
            if (actuacion.recambios && Array.isArray(actuacion.recambios) && actuacion.recambios.length > 0) {
                actuacion.recambios.forEach((recambio) => {
                    toml += `  [[or.actuaciones.recambios]]\n`;
                    toml += `  fecha = ${formatTomlValue(recambio.fecha || "")}\n`;
                    toml += `  usuario = ${formatTomlValue(recambio.usuario || "")}\n`;
                    toml += `  mensaje = ${formatTomlValue(recambio.mensaje || "")}\n`;
                    toml += `  orden = ${recambio.orden || 0}\n`;
                    toml += '\n';
                });
            }
        });
    }
    
    return toml;
}

// ========================================
// VERIFICACIÓN DE PÁGINA
// ========================================

function verificarPagina() {
    const currentUrl = window.location.href;
    const urlPattern = /\/admin\/es\/workfile\/edit\/\d+/;
    return urlPattern.test(currentUrl);
}

function extraerIdOR() {
    const match = window.location.href.match(/\/edit\/(\d+)/);
    return match ? match[1] : null;
}

function extraerIdORDelBoton() {
    const botonLog = document.querySelector('button.showLog');
    return botonLog ? botonLog.getAttribute('workfile-id') : null;
}

/** Estado visible de la OR en la página de edición (badge superior). */
function extraerEstadoOR() {
    try {
        const badge = document.querySelector('span.badge');
        if (badge) {
            return badge.textContent.trim();
        }
    } catch (e) {
        console.warn('[ResumenORCAR] Error extrayendo estado OR:', e);
    }
    return '';
}

function extraerNumeroOR() {
    try {
        const workfileNorElement = document.querySelector('span.workfile__nor');
        if (workfileNorElement) {
            const textoCompleto = workfileNorElement.textContent.trim();
            if (textoCompleto.includes('#NOR: ')) {
                return textoCompleto.replace('#NOR: ', '').trim();
            }
            const match = textoCompleto.match(/[A-Z]{2}\d+/);
            if (match) {
                return match[0];
            }
            return textoCompleto;
        }

        const headers = document.querySelectorAll('h1, h2, h3, .page-title, .workfile-title');
        for (const header of headers) {
            const text = header.textContent || '';
            const match = text.match(/[A-Z]{2}\d+/);
            if (match) {
                return match[0];
            }
        }
    } catch (e) {
        console.warn('[ResumenORCAR] Error obteniendo número de OR:', e);
    }
    return null;
}

// ========================================
// INYECCIÓN DEL BOTÓN
// ========================================

function inyectarBoton() {
    const contenedor = document.querySelector('.d-flex.flex-row.align-items-center');
    
    if (!contenedor) {
        console.log('[ResumenORCAR] No se encontró el contenedor para inyectar el botón');
        return false;
    }
    
    if (document.querySelector('#btnResumenOR')) {
        return true;
    }
    
    const nuevoDiv = document.createElement('div');
    nuevoDiv.className = 'm-1';
    
    const boton = document.createElement('a');
    boton.id = 'btnResumenOR';
    boton.className = 'btn btn-success';
    boton.href = '#';
    boton.title = 'Generar resumen de OR con IA';
    boton.style.fontSize = '13px';
    boton.innerHTML = '<i class="fas fa-robot"></i> Resumen OR';
    
    boton.addEventListener('click', function(e) {
        e.preventDefault();
        iniciarExtraccionYResumen();
    });
    
    // Agregar estilos para el spinner
    const style = document.createElement('style');
    style.textContent = `
        .btn-spinner {
            display: inline-block;
            width: 12px;
            height: 12px;
            border: 2px solid transparent;
            border-top: 2px solid currentColor;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-left: 8px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .btn-loading {
            pointer-events: none;
            opacity: 0.7;
        }
    `;
    document.head.appendChild(style);
    
    nuevoDiv.appendChild(boton);
    contenedor.appendChild(nuevoDiv);
    
    console.log('[ResumenORCAR] Botón inyectado correctamente');
    return true;
}

// ========================================
// EXTRACCIÓN DE DATOS (Basado en PrepFacturaCAR)
// ========================================

function extraerActuacionesDelDOM() {
    const actuaciones = [];
    const elementosActuaciones = document.querySelectorAll('.action__item');
    
    console.log(`[ResumenORCAR] Encontradas ${elementosActuaciones.length} actuaciones en el DOM`);
    
    elementosActuaciones.forEach((elemento, index) => {
        try {
            const idAction = elemento.getAttribute('id-action');
            if (!idAction) return;
            
            const descripcionElement = elemento.querySelector('.action__description .content');
            const descripcion = descripcionElement ? descripcionElement.textContent.trim() : `Actuación ${index + 1}`;
            
            const selectPagador = elemento.querySelector('select.payment-type');
            let pagador = 'Sin especificar';
            
            if (selectPagador) {
                const valorSeleccionado = selectPagador.value;
                const opcionSeleccionada = selectPagador.querySelector(`option[value="${valorSeleccionado}"]`);
                if (opcionSeleccionada) {
                    pagador = opcionSeleccionada.textContent.trim();
                }
            }
            
            // Verificar warehouse ID
            const botonWarehouse = elemento.querySelector('button[title="Peticiones de almacén"]');
            let warehouseId = null;
            
            if (botonWarehouse) {
                const textarea = botonWarehouse.querySelector('textarea.actionWarehouseRequests');
                if (textarea && textarea.value) {
                    try {
                        const warehouseData = JSON.parse(textarea.value);
                        if (warehouseData && warehouseData.length > 0) {
                            warehouseId = warehouseData[0].id;
                        }
                    } catch (error) {
                        console.log(`[ResumenORCAR] Error parseando warehouse data:`, error);
                    }
                }
            }
            
            actuaciones.push({
                id: idAction,
                descripcion: descripcion,
                pagador: pagador,
                warehouseId: warehouseId,
                elemento: elemento
            });
            
        } catch (error) {
            console.log(`[ResumenORCAR] Error procesando actuación ${index + 1}:`, error.message);
        }
    });
    
    return actuaciones;
}

function extraerCSRFToken() {
    const csrfInput = document.querySelector('input#csrf_token');
    return csrfInput ? csrfInput.value : null;
}

async function obtenerFichajesActuacion(workfileId, actionId) {
    try {
        const csrfToken = extraerCSRFToken();
        if (!csrfToken) {
            return { success: false, error: 'CSRF token no encontrado' };
        }
        
        const payload = new URLSearchParams({
            workfile_id: workfileId,
            ref_id: actionId,
            source: '0',
            from_ajax: '1',
            csrf_token: csrfToken
        });
        
        const response = await fetch('https://www.cloudactivereception.com/admin/es/trackings/getWorkfileTrackings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: payload.toString()
        });

        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }

        const data = await response.json();
        
        if (data.found === "true" && data.items) {
            return { 
                success: true, 
                data: data.items,
                tiempoPlaneado: parseFloat(data.total_planned_time) || 0
            };
        } else {
            return { success: true, data: [], tiempoPlaneado: 0 };
        }
    } catch (error) {
        console.log(`[ResumenORCAR] Error obteniendo fichajes:`, error);
        return { success: false, error: error.message };
    }
}

async function obtenerComentariosActuacion(actionId) {
    try {
        const response = await fetch('https://www.cloudactivereception.com/admin/es/action/getActionComments', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: `action_id=${actionId}`
        });

        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }

        const data = await response.json();
        
        let comentarios = null;
        
        if (data.result?.found === "true" && data.result.workfile_comments) {
            comentarios = data.result.workfile_comments;
        } else if (data.data?.result?.found === "true" && data.data.result.workfile_comments) {
            comentarios = data.data.result.workfile_comments;
        } else if (data.data?.workfile_comments) {
            comentarios = data.data.workfile_comments;
        } else if (data.workfile_comments) {
            comentarios = data.workfile_comments;
        }
        
        if (comentarios) {
            return { success: true, comentarios: comentarios };
        }
        
        return { success: true, comentarios: [] };
    } catch (error) {
        console.log(`[ResumenORCAR] Error obteniendo comentarios:`, error);
        return { success: false, error: error.message };
    }
}

async function obtenerMensajesRecambio(warehouseId) {
    try {
        if (!warehouseId) {
            return { success: true, mensajes: [] };
        }
        
        const csrfToken = extraerCSRFToken();
        if (!csrfToken) {
            return { success: false, error: 'CSRF token no encontrado' };
        }
        
        const payload = new URLSearchParams({
            id: warehouseId,
            csrf_token: csrfToken
        });
        
        const response = await fetch('https://www.cloudactivereception.com/admin/es/procesor/warehouse_request_messages', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: payload.toString()
        });

        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }

        const data = await response.json();
        
        if (data && Array.isArray(data)) {
            const mensajesProcesados = data.map((mensaje, index) => {
                if (Array.isArray(mensaje) && mensaje.length >= 4) {
                    return {
                        fecha: mensaje[1] || '',
                        usuario: mensaje[2] || '',
                        mensaje: mensaje[3] || '',
                        orden: index
                    };
                }
                return null;
            }).filter(mensaje => mensaje !== null);
            
            return { success: true, mensajes: mensajesProcesados };
        } else if (data && typeof data === 'object' && 'recordsTotal' in data && data.data) {
            const dataArray = data.data;
            const mensajesProcesados = [];
            
            if (dataArray && Array.isArray(dataArray)) {
                for (let i = 0; i < dataArray.length; i++) {
                    if (dataArray[i] && Array.isArray(dataArray[i]) && dataArray[i].length >= 4) {
                        mensajesProcesados.push({
                            fecha: dataArray[i][1] || '',
                            usuario: dataArray[i][2] || '',
                            mensaje: dataArray[i][3] || '',
                            orden: i
                        });
                    }
                }
            }
            
            return { success: true, mensajes: mensajesProcesados };
        }
        
        return { success: true, mensajes: [] };
    } catch (error) {
        console.log(`[ResumenORCAR] Error obteniendo mensajes de recambio:`, error);
        return { success: false, error: error.message };
    }
}

function convertirHorasAFormato(horasDecimales) {
    const horas = Math.floor(horasDecimales);
    const minutos = Math.round((horasDecimales - horas) * 60);
    return `${horas.toString().padStart(2, '0')}:${minutos.toString().padStart(2, '0')}`;
}

function calcularTiempoTotal(fichajes) {
    let tiempoTotal = 0;
    
    fichajes.forEach(fichaje => {
        if (fichaje.diff_seconds) {
            const segundos = parseInt(fichaje.diff_seconds);
            if (!isNaN(segundos)) {
                tiempoTotal += segundos / 3600;
            }
        } else if (fichaje.duration) {
            const partes = fichaje.duration.split(':');
            if (partes.length === 3) {
                const horas = parseInt(partes[0]);
                const minutos = parseInt(partes[1]);
                const segundos = parseInt(partes[2]);
                tiempoTotal += horas + (minutos / 60) + (segundos / 3600);
            }
        }
    });
    
    return tiempoTotal;
}

function agruparFichajesPorMecanico(fichajes) {
    const fichajesPorMecanico = {};
    
    fichajes.forEach(fichaje => {
        const mecanico = fichaje.tracking_user_name || fichaje.user_name || 'Sin nombre';
        
        if (!fichajesPorMecanico[mecanico]) {
            fichajesPorMecanico[mecanico] = [];
        }
        fichajesPorMecanico[mecanico].push(fichaje);
    });
    
    return fichajesPorMecanico;
}

function procesarComentarios(comentarios) {
    const comentariosProcesados = {
        comentarios: [],
        causas: [],
        operaciones: []
    };
    
    if (!comentarios || !Array.isArray(comentarios)) {
        return comentariosProcesados;
    }
    
    comentarios.forEach((comentario) => {
        const tipo = comentario.type || '';
        const contenido = comentario.comment || '';
        const usuario = comentario.full_name || comentario.user_name || 'Sin nombre';
        const fecha = comentario.created || comentario.created_at || '';
        
        switch (tipo) {
            case '0':
                comentariosProcesados.comentarios.push({
                    tipo: 'Comentario',
                    contenido: contenido,
                    usuario: usuario,
                    fecha: fecha
                });
                break;
            case '1':
                comentariosProcesados.causas.push({
                    contenido: contenido,
                    usuario: usuario,
                    fecha: fecha
                });
                break;
            case '2':
                comentariosProcesados.operaciones.push({
                    contenido: contenido,
                    usuario: usuario,
                    fecha: fecha
                });
                break;
            default:
                comentariosProcesados.comentarios.push({
                    tipo: `Tipo ${tipo}`,
                    contenido: contenido,
                    usuario: usuario,
                    fecha: fecha
                });
        }
    });
    
    return comentariosProcesados;
}

// ========================================
// COMENTARIOS DE LA OR (INTERNOS Y EXTERNOS)
// ========================================

async function obtenerComentariosOR(workfileId) {
    try {
        console.log(`[ResumenORCAR] Obteniendo comentarios de OR ${workfileId}...`);
        
        const response = await fetch('https://www.cloudactivereception.com/admin/es/workfile/getWFComments', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: `workfile_id=${workfileId}`
        });

        if (!response.ok) {
            console.warn('[ResumenORCAR] Error en la petición de comentarios OR:', response.status);
            return { success: false, error: `HTTP ${response.status}` };
        }

        // Intentar parsear como JSON, incluso si el content-type no lo indica
        // (algunos servidores devuelven JSON con content-type incorrecto)
        let data;
        const contentType = response.headers.get('content-type') || '';
        const isJsonContentType = contentType.includes('application/json');
        
        try {
            if (isJsonContentType) {
                data = await response.json();
            } else {
                // Intentar parsear como texto primero y luego como JSON
                const text = await response.text();
                if (text.trim()) {
                    try {
                        data = JSON.parse(text);
                        console.log('[ResumenORCAR] Respuesta parseada como JSON (aunque content-type no lo indicaba)');
                    } catch (parseError) {
                        console.warn('[ResumenORCAR] Respuesta de comentarios OR no es JSON válido. Content-Type:', contentType);
                        console.warn('[ResumenORCAR] Primeros 200 caracteres de la respuesta:', text.substring(0, 200));
                        return { success: true, externos: [], internos: [] };
                    }
                } else {
                    console.warn('[ResumenORCAR] Respuesta de comentarios OR está vacía');
                    return { success: true, externos: [], internos: [] };
                }
            }
        } catch (error) {
            console.warn('[ResumenORCAR] Error parseando respuesta de comentarios OR:', error);
            return { success: true, externos: [], internos: [] };
        }
        
        console.log('[ResumenORCAR] Respuesta de comentarios OR:', data);

        // Extraer comentarios de la estructura de respuesta
        let comentarios = [];
        
        if (data && data.data && data.data.result && data.data.result.found === "true" && data.data.result.workfile_comments) {
            comentarios = Array.isArray(data.data.result.workfile_comments) ? data.data.result.workfile_comments : [];
        } else if (data && data.result && data.result.found === "true" && data.result.workfile_comments) {
            comentarios = Array.isArray(data.result.workfile_comments) ? data.result.workfile_comments : [];
        } else if (data && data.workfile_comments) {
            comentarios = Array.isArray(data.workfile_comments) ? data.workfile_comments : [];
        }

        // Separar comentarios externos (type=0) e internos (type=1)
        const externos = comentarios.filter(c => c.type == "0").map(c => ({
            contenido: c.comment || '',
            usuario: c.full_name || c.user_name || 'Sin nombre',
            fecha: c.created || ''
        }));
        
        const internos = comentarios.filter(c => c.type == "1").map(c => ({
            contenido: c.comment || '',
            usuario: c.full_name || c.user_name || 'Sin nombre',
            fecha: c.created || ''
        }));

        console.log(`[ResumenORCAR] Comentarios OR encontrados - Externos: ${externos.length}, Internos: ${internos.length}`);

        return {
            success: true,
            externos: externos,
            internos: internos,
            totalComentarios: comentarios.length
        };

    } catch (error) {
        console.error('[ResumenORCAR] Error obteniendo comentarios OR:', error);
        return { success: false, error: error.message, externos: [], internos: [] };
    }
}

// ========================================
// COMENTARIOS DEL VEHÍCULO
// ========================================

async function obtenerComentariosVehiculo() {
    try {
        console.log('[ResumenORCAR] Buscando comentarios del vehículo...');

        // Buscar el enlace a la matrícula con múltiples selectores
        let matriculaLink = document.querySelector('a[title="Ver matrícula"]');
        
        if (!matriculaLink) {
            matriculaLink = document.querySelector('a.vehicle-badge.truck');
        }
        
        if (!matriculaLink) {
            matriculaLink = document.querySelector('a[href*="vehicle"]');
        }

        if (!matriculaLink) {
            console.log('[ResumenORCAR] No se encontró enlace de matrícula');
            return { success: true, comentarios: null, fechaMatriculacion: null };
        }

        const matriculaUrl = matriculaLink.href;
        console.log('[ResumenORCAR] URL de matrícula:', matriculaUrl);

        // Hacer petición a la página de matrícula
        const response = await fetch(matriculaUrl, {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            console.warn('[ResumenORCAR] Error al obtener página de matrícula:', response.status);
            return { success: false, error: `HTTP ${response.status}`, comentarios: null, fechaMatriculacion: null };
        }

        const html = await response.text();

        // Parsear el HTML para extraer comentarios y fecha de matriculación
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        const commentsTextarea = doc.querySelector('textarea#comments');

        // Fecha de matriculación: input name="plate_date" id="plate_date" (formato DD/MM/YYYY o DD/MM/YYYY HH:mm)
        let fechaMatriculacion = null;
        const plateDateInput = doc.querySelector('input#plate_date') || doc.querySelector('input[name="plate_date"]');
        if (plateDateInput && plateDateInput.value) {
            fechaMatriculacion = plateDateInput.value.trim();
            // Normalizar a DD/MM/YYYY quitando la hora si viene "01/10/2019 00:00"
            if (fechaMatriculacion.includes(' ')) {
                fechaMatriculacion = fechaMatriculacion.split(' ')[0];
            }
            console.log('[ResumenORCAR] Fecha de matriculación:', fechaMatriculacion);
        }

        if (!commentsTextarea) {
            console.log('[ResumenORCAR] No se encontró textarea de comentarios del vehículo');
            return { success: true, comentarios: null, fechaMatriculacion };
        }

        const comentarios = commentsTextarea.value.trim();

        if (!comentarios) {
            console.log('[ResumenORCAR] Textarea de comentarios del vehículo está vacío');
            return { success: true, comentarios: null, fechaMatriculacion };
        }

        console.log('[ResumenORCAR] Comentarios del vehículo encontrados');
        return {
            success: true,
            comentarios: comentarios,
            fechaMatriculacion: fechaMatriculacion
        };

    } catch (error) {
        console.error('[ResumenORCAR] Error obteniendo comentarios del vehículo:', error);
        return { success: false, error: error.message, comentarios: null, fechaMatriculacion: null };
    }
}

// ========================================
// COMENTARIOS DEL CLIENTE
// ========================================

async function obtenerComentariosCliente() {
    try {
        console.log('[ResumenORCAR] Buscando comentarios del cliente...');

        // Buscar el enlace al cliente en la página
        let enlaceCliente = document.querySelector('a[href*="/admin/es/manage/clients/edit/"]');
        
        if (!enlaceCliente) {
            enlaceCliente = document.querySelector('a[href*="clients/edit"]');
        }
        
        if (!enlaceCliente) {
            enlaceCliente = document.querySelector('a.admin-clients-link');
        }

        if (!enlaceCliente) {
            console.log('[ResumenORCAR] No se encontró enlace al cliente');
            return { success: true, comentarios: null };
        }

        // Extraer el ID del cliente de la URL
        const idCliente = enlaceCliente.href.match(/clients\/edit\/(\d+)/)?.[1] || null;
        
        if (!idCliente) {
            console.log('[ResumenORCAR] No se pudo extraer el ID del cliente');
            return { success: true, comentarios: null };
        }

        const urlCliente = `https://www.cloudactivereception.com/admin/es/manage/clients/edit/${idCliente}`;
        console.log('[ResumenORCAR] URL del cliente:', urlCliente);

        // Hacer petición a la ficha del cliente
        const response = await fetch(urlCliente, {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            console.warn('[ResumenORCAR] Error al obtener página del cliente:', response.status);
            return { success: false, error: `HTTP ${response.status}` };
        }

        const html = await response.text();

        // Parsear el HTML para extraer el contenido del textarea
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        const commentsTextarea = doc.querySelector('textarea#comments');

        if (!commentsTextarea) {
            console.log('[ResumenORCAR] No se encontró textarea de comentarios del cliente');
            return { success: true, comentarios: null };
        }

        const comentarios = commentsTextarea.value.trim();

        if (!comentarios) {
            console.log('[ResumenORCAR] Textarea de comentarios del cliente está vacío');
            return { success: true, comentarios: null };
        }

        console.log('[ResumenORCAR] Comentarios del cliente encontrados');
        return {
            success: true,
            comentarios: comentarios
        };

    } catch (error) {
        console.error('[ResumenORCAR] Error obteniendo comentarios del cliente:', error);
        return { success: false, error: error.message, comentarios: null };
    }
}

// ========================================
// FUNCIÓN PRINCIPAL DE EXTRACCIÓN
// ========================================

async function extraerDatosOR() {
    const workfileId = extraerIdORDelBoton() || extraerIdOR();
    if (!workfileId) {
        throw new Error('No se pudo obtener el ID de la OR');
    }
    
    const orNumber = extraerNumeroOR() || workfileId;
    const estadoOR = extraerEstadoOR();
    
    console.log(`[ResumenORCAR] Extrayendo datos de OR: ${orNumber} (ID: ${workfileId})`);
    if (estadoOR) console.log(`[ResumenORCAR] Estado OR: ${estadoOR}`);
    
    // Obtener comentarios de la OR (externos e internos)
    console.log('[ResumenORCAR] Obteniendo comentarios de la OR...');
    const comentariosORResult = await obtenerComentariosOR(workfileId);
    const comentariosOR = {
        externos: comentariosORResult.success ? comentariosORResult.externos : [],
        internos: comentariosORResult.success ? comentariosORResult.internos : []
    };
    console.log(`[ResumenORCAR] Comentarios OR obtenidos - Externos: ${comentariosOR.externos.length}, Internos: ${comentariosOR.internos.length}`);
    
    // Obtener comentarios del vehículo
    console.log('[ResumenORCAR] Obteniendo comentarios del vehículo...');
    const comentariosVehiculoResult = await obtenerComentariosVehiculo();
    const comentariosVehiculo = comentariosVehiculoResult.success ? comentariosVehiculoResult.comentarios : null;
    const fechaMatriculacion = comentariosVehiculoResult.success ? comentariosVehiculoResult.fechaMatriculacion : null;
    console.log(`[ResumenORCAR] Comentarios vehículo: ${comentariosVehiculo ? 'Encontrados' : 'No encontrados'}`);
    if (fechaMatriculacion) console.log('[ResumenORCAR] Fecha matriculación:', fechaMatriculacion);
    
    // Obtener comentarios del cliente
    console.log('[ResumenORCAR] Obteniendo comentarios del cliente...');
    const comentariosClienteResult = await obtenerComentariosCliente();
    const comentariosCliente = comentariosClienteResult.success ? comentariosClienteResult.comentarios : null;
    console.log(`[ResumenORCAR] Comentarios cliente: ${comentariosCliente ? 'Encontrados' : 'No encontrados'}`);
    
    const actuaciones = extraerActuacionesDelDOM();
    if (actuaciones.length === 0) {
        throw new Error('No se encontraron actuaciones');
    }
    
    const datosCompletos = [];
    
    for (let i = 0; i < actuaciones.length; i++) {
        const actuacion = actuaciones[i];
        console.log(`[ResumenORCAR] Procesando actuación ${i + 1}/${actuaciones.length}`);
        
        const fichajesResult = await obtenerFichajesActuacion(workfileId, actuacion.id);
        const fichajes = fichajesResult.success ? fichajesResult.data : [];
        const tiempoPlaneado = fichajesResult.success ? fichajesResult.tiempoPlaneado : 0;
        
        const comentariosResult = await obtenerComentariosActuacion(actuacion.id);
        const comentarios = comentariosResult.success ? comentariosResult.comentarios : [];
        
        const recambioResult = await obtenerMensajesRecambio(actuacion.warehouseId);
        const mensajesRecambio = recambioResult.success ? recambioResult.mensajes : [];
        
        const tiempoTotal = calcularTiempoTotal(fichajes);
        const fichajesPorMecanico = agruparFichajesPorMecanico(fichajes);
        const comentariosProcesados = procesarComentarios(comentarios);
        
        // Calcular tiempo por mecánico
        const tiemposPorMecanico = {};
        Object.keys(fichajesPorMecanico).forEach(mecanico => {
            tiemposPorMecanico[mecanico] = calcularTiempoTotal(fichajesPorMecanico[mecanico]);
        });
        
        datosCompletos.push({
            id: actuacion.id,
            descripcion: actuacion.descripcion,
            pagador: actuacion.pagador,
            tiempoTotal: tiempoTotal,
            tiempoTotalFormato: convertirHorasAFormato(tiempoTotal),
            tiempoPlaneado: tiempoPlaneado,
            tiempoPlaneadoFormato: convertirHorasAFormato(tiempoPlaneado),
            tiemposPorMecanico: tiemposPorMecanico,
            comentarios: comentariosProcesados,
            recambios: mensajesRecambio
        });
        
        await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    const datosFinales = {
        orNumber: orNumber,
        workfileId: workfileId,
        estado: estadoOR,
        fechaExtraccion: new Date().toISOString(),
        fechaMatriculacion: fechaMatriculacion,
        comentariosVehiculo: comentariosVehiculo,
        comentariosCliente: comentariosCliente,
        comentariosOR: {
            externos: comentariosOR.externos,
            internos: comentariosOR.internos,
            resumen: {
                totalExternos: comentariosOR.externos.length,
                totalInternos: comentariosOR.internos.length
            }
        },
        actuaciones: datosCompletos,
        resumen: {
            totalActuaciones: datosCompletos.length,
            tiempoTotalOR: datosCompletos.reduce((total, act) => total + act.tiempoTotal, 0),
            tiempoTotalFormato: convertirHorasAFormato(datosCompletos.reduce((total, act) => total + act.tiempoTotal, 0)),
            totalComentariosExternos: comentariosOR.externos.length,
            totalComentariosInternos: comentariosOR.internos.length,
            tieneComentariosVehiculo: comentariosVehiculo !== null,
            tieneComentariosCliente: comentariosCliente !== null
        }
    };
    
    return datosFinales;
}

// ========================================
// GEMINI API - STREAMING
// ========================================

function geminiModelCandidates() {
    const seen = new Set();
    return [MODEL_VERSION, ...MODEL_FALLBACKS]
        .map((m) => String(m || '').trim())
        .filter((m) => {
            if (!m || seen.has(m)) return false;
            seen.add(m);
            return true;
        });
}

function esModeloGeminiNoDisponible(errorText) {
    const t = String(errorText || '').toLowerCase();
    return t.includes('no longer available') || t.includes('not found') || t.includes('not_found');
}

function debeProbarModeloGeminiFallback(status, errorText) {
    const t = String(errorText || '').toLowerCase();
    if (status === 404 && esModeloGeminiNoDisponible(errorText)) return true;
    if (status === 429 && (t.includes('free_tier') || t.includes('quota') || t.includes('rate limit') || t.includes('resource_exhausted'))) {
        return true;
    }
    if (status === 403 && !esErrorApiKeyInvalida(status, errorText)) return true;
    return false;
}

function esErrorApiKeyInvalida(status, errorText) {
    const t = String(errorText || '').toLowerCase();
    return (status === 400 || status === 401 || status === 403)
        && (t.includes('api_key_invalid') || t.includes('api key not valid') || t.includes('invalid api key'));
}

function formatearErrorGemini(error) {
    const msg = String(error?.message || error || '');
    const statusMatch = msg.match(/Error API \((\d+)\)/);
    const status = statusMatch ? Number(statusMatch[1]) : 0;

    let userMessage = "❌ **Error de conexión con la IA**\n\n";

    if (msg.includes('503') || msg.includes('overloaded')) {
        userMessage += "🔄 **Servidor saturado** - Por favor, espera unos segundos e intenta de nuevo.";
    } else if (status === 404 || esModeloGeminiNoDisponible(msg)) {
        userMessage += "⚠️ **Modelo no disponible** - No hay ningún modelo Gemini accesible con esta API Key.";
    } else if (esErrorApiKeyInvalida(status, msg)) {
        userMessage += "🔐 **Error de autenticación** - La API Key no es válida o fue revocada.";
    } else if (status === 403) {
        userMessage += "🚫 **Permisos insuficientes** - La API Key es válida pero no tiene acceso a este modelo. Revisa facturación o restricciones del proyecto en Google AI Studio.";
    } else if (status === 429 || msg.includes('quota') || msg.includes('rate limit') || msg.includes('resource_exhausted')) {
        userMessage += "⏳ **Cuota agotada** - Has superado el límite de uso. Espera unos minutos o revisa el plan en Google AI Studio.";
    } else {
        userMessage += `Detalles: ${msg}`;
    }

    return userMessage;
}

async function streamGeminiResponse(response, onChunk) {
    const reader = response.body.getReader();
    const decoder = new TextDecoder("utf-8");
    let buffer = "";
    let fullText = "";
    let lastProcessedIndex = 0;

    while (true) {
        const { done, value } = await reader.read();
        if (done) {
            console.log('[ResumenORCAR] Stream finalizado. Texto total:', fullText.length, 'caracteres');
            break;
        }

        const chunk = decoder.decode(value, { stream: true });
        buffer += chunk;

        let searchStart = lastProcessedIndex;
        let foundText = true;
        let newProcessedIndex = lastProcessedIndex;

        while (foundText) {
            foundText = false;

            const remainingBuffer = buffer.substring(searchStart);
            const textMatch = remainingBuffer.match(/"text"\s*:\s*"((?:[^"\\]|\\.)*)"/);

            if (textMatch) {
                let rawText = textMatch[1];
                try {
                    rawText = JSON.parse('"' + rawText + '"');
                } catch (e) { }

                const matchIndex = searchStart + remainingBuffer.indexOf(textMatch[0]);
                const matchEndIndex = matchIndex + textMatch[0].length;

                if (rawText && rawText.length > 0) {
                    const isNewText = !fullText.endsWith(rawText);

                    if (isNewText) {
                        fullText += rawText;
                        onChunk(rawText);
                        newProcessedIndex = matchEndIndex;
                        foundText = true;
                    }
                }

                searchStart = matchEndIndex;
            }
        }

        lastProcessedIndex = newProcessedIndex;

        if (buffer.length > 5000 && lastProcessedIndex > 1000) {
            buffer = buffer.substring(lastProcessedIndex);
            lastProcessedIndex = 0;
        }
    }

    return fullText;
}

async function callGeminiStream(userPrompt, onChunk) {
    const apiKey = await obtenerGeminiApiKey();
    if (!apiKey) {
        const errorMsg = "Error: API Key de Gemini no configurada o inválida en Drive (ResumenORCAR-config.json → gemini_api_key).";
        onChunk(errorMsg);
        return errorMsg;
    }

    let parts = [];
    if (typeof userPrompt === 'string') {
        parts = [{ text: userPrompt }];
    } else if (Array.isArray(userPrompt)) {
        parts = userPrompt;
    }

    const requestBody = {
        contents: [{ role: "user", parts: parts }],
        generationConfig: {
            temperature: 0.4,
            topK: 32,
            topP: 0.8,
            maxOutputTokens: 16384,
        }
    };

    const modelos = geminiModelCandidates();
    let lastError = null;

    for (const modelVersion of modelos) {
        const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/${modelVersion}:streamGenerateContent`;
        console.log('[ResumenORCAR] Iniciando llamada streaming a Gemini:', modelVersion);

        try {
            const response = await fetch(API_URL, {
                method: "POST",
                headers: geminiApiHeaders(apiKey, { "Content-Type": "application/json" }),
                body: JSON.stringify(requestBody)
            });

            if (!response.ok) {
                const errText = await response.text();
                console.error('[ResumenORCAR] Error API:', modelVersion, response.status, errText);
                lastError = new Error(`Error API (${response.status}): ${errText}`);
                if (debeProbarModeloGeminiFallback(response.status, errText)) {
                    console.warn('[ResumenORCAR] Probando modelo alternativo tras fallo de', modelVersion);
                    continue;
                }
                break;
            }

            return await streamGeminiResponse(response, onChunk);
        } catch (error) {
            lastError = error;
            const statusMatch = String(error.message || '').match(/Error API \((\d+)\)/);
            const status = statusMatch ? Number(statusMatch[1]) : 0;
            if (debeProbarModeloGeminiFallback(status, error.message)) {
                console.warn('[ResumenORCAR] Probando modelo alternativo tras excepción de', modelVersion);
                continue;
            }
            break;
        }
    }

    console.error('[ResumenORCAR] Error en streaming: ningún modelo disponible');
    const userMessage = formatearErrorGemini(lastError || new Error('Ningún modelo Gemini disponible'));
    onChunk(userMessage);
    return userMessage;
}

// ========================================
// SUBIDA DE ARCHIVOS A GEMINI
// ========================================

function inferirMimeType(file) {
    if (file.type) return file.type;
    const ext = (file.name || '').split('.').pop()?.toLowerCase();
    const mimeTypes = {
        jpg: 'image/jpeg',
        jpeg: 'image/jpeg',
        png: 'image/png',
        gif: 'image/gif',
        webp: 'image/webp',
        pdf: 'application/pdf',
        txt: 'text/plain',
        csv: 'text/csv',
        json: 'application/json'
    };
    return mimeTypes[ext] || 'application/octet-stream';
}

async function subirArchivoAGemini(file) {
    console.log('[ResumenORCAR] Subiendo archivo a Gemini:', file.name, file.type, file.size);
    const apiKey = await obtenerGeminiApiKey();
    if (!apiKey) {
        return { success: false, error: 'API Key de Gemini no configurada o inválida en Drive' };
    }
    
    const mimeType = inferirMimeType(file);
    const uploadUrl = 'https://generativelanguage.googleapis.com/upload/v1beta/files';
    
    const metadata = {
        file: {
            displayName: file.name,
            mimeType
        }
    };
    
    const formData = new FormData();
    formData.append('metadata', JSON.stringify(metadata));
    formData.append('file', file, file.name);
    
    try {
        const response = await fetch(uploadUrl, {
            method: 'POST',
            headers: geminiApiHeaders(apiKey),
            body: formData
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`${response.status} - ${errorText}`);
        }
        
        const result = await response.json();
        console.log('[ResumenORCAR] Archivo subido exitosamente:', result);
        
        return {
            success: true,
            fileUri: result.file.uri,
            mimeType: result.file.mimeType || mimeType,
            displayName: result.file.displayName || file.name
        };
    } catch (error) {
        console.error('[ResumenORCAR] Error subiendo archivo:', error);
        return { success: false, error: error.message };
    }
}

// ========================================
// INTERFAZ DE CHAT
// ========================================

// Variable para controlar si marked ya fue configurado
let markedConfigured = false;

/**
 * Preprocesa el texto markdown para normalizar tablas y otros elementos
 * antes de pasarlo a marked.js
 */
function preprocesarMarkdown(text) {
    if (!text) return '';
    
    // Asegurar que las tablas tengan líneas vacías antes y después
    // para que marked las detecte correctamente
    let procesado = text;
    
    // Detectar líneas de tabla (empiezan y terminan con |)
    const lineas = procesado.split('\n');
    const resultado = [];
    let enTabla = false;
    let tablaInicio = -1;
    
    for (let i = 0; i < lineas.length; i++) {
        const linea = lineas[i].trim();
        const esLineaTabla = linea.startsWith('|') && linea.endsWith('|');
        
        if (esLineaTabla && !enTabla) {
            // Inicio de tabla - añadir línea vacía antes si no la hay
            if (resultado.length > 0 && resultado[resultado.length - 1].trim() !== '') {
                resultado.push('');
            }
            enTabla = true;
            tablaInicio = i;
        }
        
        if (!esLineaTabla && enTabla) {
            // Fin de tabla - añadir línea vacía después
            resultado.push('');
            enTabla = false;
        }
        
        resultado.push(lineas[i]);
    }
    
    return resultado.join('\n');
}

function renderStreamingResponse(text) {
    if (!text) return '';
    
    // Preprocesar el markdown para normalizar tablas
    const textoPreprocesado = preprocesarMarkdown(text);
    
    // Usar marked.js para convertir markdown a HTML
    try {
        if (typeof marked !== 'undefined') {
            // Configurar marked solo una vez (API v15+)
            if (!markedConfigured) {
                // marked v15+ usa use() para configuración
                marked.use({
                    breaks: false,     // No convertir saltos de línea simples en <br> (interfiere con tablas)
                    gfm: true,         // GitHub Flavored Markdown (tablas, listas anidadas, etc.)
                    pedantic: false,   // No ser estricto con el formato
                    sanitize: false,   // No sanitizar HTML (confiamos en Gemini)
                    smartLists: true,   // Listas inteligentes
                    smartypants: false // No convertir comillas tipográficas
                });
                markedConfigured = true;
                console.log('[ResumenORCAR] Marked.js v15 configurado correctamente');
            }
            
            // Parsear markdown a HTML
            let html = marked.parse(textoPreprocesado);
            console.log('[ResumenORCAR] Markdown parseado, longitud HTML:', html.length);
            
            // Post-procesar para asegurar que las negritas se procesaron correctamente
            // Procesar cualquier ** que haya quedado sin convertir
            if (html.includes('**')) {
                console.log('[ResumenORCAR] Aplicando post-procesamiento para negritas sin convertir');
                // Procesar negritas que quedaron sin convertir (múltiples pasadas)
                let previousHtml = '';
                let iterations = 0;
                while (html !== previousHtml && html.includes('**') && iterations < 5) {
                    previousHtml = html;
                    html = html.replace(/\*\*([^*]+?)\*\*/gs, '<strong>$1</strong>');
                    iterations++;
                }
            }
            
            return html;
        } else {
            console.warn('[ResumenORCAR] marked.js no está disponible, usando fallback');
        }
    } catch (error) {
        console.warn('[ResumenORCAR] Error parseando markdown:', error);
    }
    
    // Fallback: conversión manual si marked no está disponible
    return convertirMarkdownManual(textoPreprocesado);
}

function convertirMarkdownManual(text) {
    if (!text) return '';
    
    let html = text;
    
    // IMPORTANTE: Procesar en el orden correcto para evitar conflictos
    
    // 1. Primero procesar negrita y cursiva combinadas (***texto***)
    html = html.replace(/\*\*\*([^*]+?)\*\*\*/g, '<strong><em>$1</em></strong>');
    
    // 2. Luego procesar negrita (**texto**) - debe ir antes de cursiva
    // Procesar múltiples veces para asegurar que se capturen todas las instancias
    // Usar regex que maneje espacios, saltos de línea y caracteres especiales
    let previousHtml = '';
    let iterations = 0;
    while (html !== previousHtml && iterations < 10) {
        previousHtml = html;
        // Regex mejorado: captura **texto** incluso con espacios, saltos de línea y dos puntos
        // Maneja casos como: **texto:**, * **texto**, etc.
        html = html.replace(/\*\*([^*]+?)\*\*/gs, '<strong>$1</strong>');
        iterations++;
    }
    
    // Post-procesamiento adicional: manejar casos específicos donde puede haber quedado sin procesar
    // Por ejemplo: "* **texto**" donde el primer * es de lista
    html = html.replace(/(<li[^>]*>.*?)\*\*([^*]+?)\*\*/gs, '$1<strong>$2</strong>');
    // Casos al inicio de línea después de espacios o tabulaciones
    html = html.replace(/(^|\s)\*\*([^*]+?)\*\*/gm, '$1<strong>$2</strong>');
    
    // 3. Después procesar cursiva simple (*texto*) - solo asteriscos simples
    // Usar un enfoque más seguro que evite procesar asteriscos que son parte de negritas ya procesadas
    // Primero intentar con lookbehind/lookahead (navegadores modernos)
    try {
        html = html.replace(/(?<!\*)\*([^*\n]+?)\*(?!\*)/g, '<em>$1</em>');
    } catch (e) {
        // Fallback para navegadores que no soportan lookbehind
        // Procesar cursivas que no están dentro de negritas ya procesadas
        html = html.replace(/([^*]|^)\*([^*\n]+?)\*([^*]|$)/g, '$1<em>$2</em>$3');
    }
    
    // 4. Tablas (básico) - después de negrita/cursiva para evitar conflictos
    const tablaRegex = /\|(.+)\|[\r\n]+\|[-:\s|]+\|[\r\n]+((?:\|.+\|[\r\n]*)+)/g;
    html = html.replace(tablaRegex, (match, header, rows) => {
        const headers = header.split('|').filter(h => h.trim()).map(h => `<th>${h.trim()}</th>`).join('');
        const rowsHtml = rows.trim().split('\n').map(row => {
            const cells = row.split('|').filter(c => c.trim()).map(c => `<td>${c.trim()}</td>`).join('');
            return `<tr>${cells}</tr>`;
        }).join('');
        return `<table><thead><tr>${headers}</tr></thead><tbody>${rowsHtml}</tbody></table>`;
    });
    
    // 5. Encabezados
    html = html.replace(/^####\s*(.*)$/gm, '<h4>$1</h4>');
    html = html.replace(/^###\s*(.*)$/gm, '<h3>$1</h3>');
    html = html.replace(/^##\s*(.*)$/gm, '<h2>$1</h2>');
    html = html.replace(/^#\s*(.*)$/gm, '<h1>$1</h1>');
    
    // 6. Listas anidadas (procesar de más profundo a menos profundo)
    // Nivel 3 (8 espacios o 2 tabs)
    html = html.replace(/^(?:        |\t\t)[-*]\s+(.*)$/gm, '<li class="level3">$1</li>');
    // Nivel 2 (4 espacios o 1 tab)
    html = html.replace(/^(?:    |\t)[-*]\s+(.*)$/gm, '<li class="level2">$1</li>');
    // Nivel 1 (sin indentación)
    html = html.replace(/^[-*]\s+(.*)$/gm, '<li class="level1">$1</li>');
    
    // 7. Envolver listas
    html = html.replace(/(<li class="level1">.*?<\/li>(\s*<li class="level[23]">.*?<\/li>)*)/gs, '<ul>$1</ul>');
    
    // 8. Saltos de línea al final
    html = html.replace(/\n\n/g, '</p><p>');
    html = html.replace(/\n/g, '<br>');
    
    return html;
}

function addMessage(container, text, type) {
    const div = document.createElement('div');
    div.className = `message ${type}`;
    
    if (type === 'system' || type === 'error') {
        div.innerHTML = `<span style="color:${type === 'error' ? '#c00' : '#666'};font-style:italic;font-size:0.9em;">${text}</span>`;
    } else {
        div.innerHTML = `<div class="bubble">${text}</div>`;
    }
    
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
}

function mostrarArchivoAdjunto(file) {
    const preview = document.getElementById('attachment-preview-resumen');
    if (preview) {
        preview.style.display = 'flex';
        preview.innerHTML = `
            <span>📎 ${file.name} (${(file.size / 1024).toFixed(1)} KB)</span>
            <button id="remove-attachment-resumen" style="margin-left:10px;background:none;border:none;cursor:pointer;color:#d32f2f;font-weight:bold;">✕</button>
        `;
        
        document.getElementById('remove-attachment-resumen').onclick = () => {
            archivoAdjuntoActual = null;
            preview.style.display = 'none';
            const fileInput = document.getElementById('file-input-resumen');
            if (fileInput) fileInput.value = '';
        };
    }
}

async function handleSend(inputText, messagesArea) {
    const userText = inputText.value.trim();
    if (!userText && !archivoAdjuntoActual) return;
    
    inputText.value = '';
    
    // Mostrar mensaje del usuario
    let mensajeUsuario = userText || '(Archivo adjunto)';
    if (archivoAdjuntoActual) {
        mensajeUsuario += `<br><br><div style="font-size:0.9em;color:#1976d2;background:#e3f2fd;padding:5px;border-radius:4px;display:inline-block;">📎 ${archivoAdjuntoActual.file.name}</div>`;
    }
    addMessage(messagesArea, mensajeUsuario, 'user');
    
    // Preparar contenido para Gemini
    let geminiContent = [];
    
    // Si hay archivo adjunto, subirlo primero
    if (archivoAdjuntoActual && archivoAdjuntoActual.file) {
        addMessage(messagesArea, "Subiendo archivo...", 'system');
        
        const uploadResult = await subirArchivoAGemini(archivoAdjuntoActual.file);
        
        if (uploadResult.success) {
            geminiContent.push({
                fileData: {
                    fileUri: uploadResult.fileUri,
                    mimeType: uploadResult.mimeType
                }
            });
            archivoAdjuntoActual.geminiData = uploadResult;
        } else {
            addMessage(messagesArea, `Error subiendo archivo: ${uploadResult.error}`, 'error');
        }
        
        // Limpiar preview
        const preview = document.getElementById('attachment-preview-resumen');
        if (preview) preview.style.display = 'none';
        archivoAdjuntoActual = null;
    }
    
    // Construir el prompt
    let prompt;
    if (conversationHistory.length === 0) {
        // Primera interacción después del análisis inicial
        prompt = window.construirPromptSeguimiento(datosORActual, userText);
    } else {
        prompt = userText;
    }
    
    geminiContent.push({ text: prompt });
    
    // Guardar en historial
    conversationHistory.push({ role: 'user', content: userText, attachment: archivoAdjuntoActual?.file?.name });
    
    // Crear burbuja de respuesta
    const aiMsgDiv = document.createElement('div');
    aiMsgDiv.className = 'message ai';
    aiMsgDiv.innerHTML = `<div class="bubble">Pensando...</div>`;
    messagesArea.appendChild(aiMsgDiv);
    const bubble = aiMsgDiv.querySelector('.bubble');
    
    let accumulatedText = "";
    await callGeminiStream(geminiContent, (chunk) => {
        accumulatedText += chunk;
        bubble.innerHTML = renderStreamingResponse(accumulatedText);
        messagesArea.scrollTop = messagesArea.scrollHeight;
    });
    
    // Guardar respuesta en historial
    conversationHistory.push({ role: 'model', content: accumulatedText });
}

// ========================================
// FUNCIÓN PRINCIPAL - EXTRACCIÓN Y RESUMEN
// ========================================

async function iniciarExtraccionYResumen() {
    if (isProcessing) {
        alert('Ya hay un proceso en curso');
        return;
    }
    
    isProcessing = true;
    conversationHistory = [];
    datosORActual = null;
    
    const boton = document.querySelector('#btnResumenOR');
    if (boton) {
        boton.classList.add('btn-loading');
        boton.innerHTML = '<i class="fas fa-robot"></i> Procesando...<span class="btn-spinner"></span>';
    }
    
    try {
        // Verificar que estamos en la página correcta
        if (!verificarPagina()) {
            throw new Error('No estamos en una página de edición de OR');
        }
        
        // IMPORTANTE: Abrir el Side Panel INMEDIATAMENTE (dentro del user gesture)
        // Chrome requiere que sidePanel.open() se llame en respuesta directa a un clic
        // Usamos chrome.runtime.sendMessage directo (sin await) para no perder el contexto de user gesture
        console.log('[ResumenORCAR] Abriendo Side Panel inmediatamente...');
        chrome.runtime.sendMessage({ action: 'openSidePanel' }, (response) => {
            if (chrome.runtime.lastError) {
                console.error('[ResumenORCAR] Error enviando mensaje openSidePanel:', chrome.runtime.lastError.message);
            } else {
                console.log('[ResumenORCAR] Mensaje openSidePanel enviado, respuesta:', response);
            }
        });
        
        // Extraer datos
        console.log('[ResumenORCAR] Iniciando extracción de datos...');
        const datosOR = await extraerDatosOR();
        datosORActual = datosOR;
        
        // Registrar acceso
        registrarAccesoLog(datosOR.orNumber);
        
        // Ofuscar nombres de usuarios antes de convertir a TOML
        console.log('[ResumenORCAR] Aplicando ofuscación de nombres de usuarios...');
        let datosORParaTOML = datosOR;
        if (typeof ofuscarDatosOR === 'function') {
            datosORParaTOML = ofuscarDatosOR(datosOR);
            console.log('[ResumenORCAR] Nombres ofuscados correctamente');
        } else {
            console.warn('[ResumenORCAR] Función ofuscarDatosOR no disponible, usando datos sin ofuscar');
        }
        
        // Convertir a TOML y guardar en Google Drive
        console.log('[ResumenORCAR] Generando TOML...');
        const tomlString = convertirDatosORaTOML(datosORParaTOML);
        const fechaArchivo = new Date().toISOString().split('T')[0];
        
        // Guardar en Google Drive
        console.log('[ResumenORCAR] Guardando TOML en Google Drive...');
        const nombreArchivo = `ResumenOR-${datosOR.orNumber}-${fechaArchivo}.toml`;
        console.log('[ResumenORCAR] Nombre del archivo:', nombreArchivo);
        console.log('[ResumenORCAR] Tamaño del contenido:', tomlString.length, 'caracteres');
        
        try {
            const resultadoDrive = await safeChromeRuntimeSendMessage({
                action: 'saveToDrive',
                data: {
                    filename: nombreArchivo,
                    content: tomlString,
                    type: 'text',
                    ext: 'toml'
                }
            });
            
            if (resultadoDrive && resultadoDrive.success) {
                console.log('[ResumenORCAR] ✅ Archivo guardado exitosamente en Drive:', resultadoDrive);
                if (resultadoDrive.data && resultadoDrive.data.fileId) {
                    console.log('[ResumenORCAR] ID del archivo en Drive:', resultadoDrive.data.fileId);
                    console.log('[ResumenORCAR] URL del archivo:', `https://drive.google.com/file/d/${resultadoDrive.data.fileId}/view`);
                }
            } else {
                console.error('[ResumenORCAR] ❌ Error guardando en Drive:', resultadoDrive);
                alert(`Error guardando en Drive: ${resultadoDrive?.error || 'Error desconocido'}`);
            }
        } catch (err) {
            console.error('[ResumenORCAR] ❌ Excepción guardando en Drive:', err);
            alert(`Error guardando en Drive: ${err.message || err}`);
        }
        
        console.log('[ResumenORCAR] TOML generado y guardado, enviando datos al Side Panel...');
        
        // Enviar datos al Side Panel (ya está abierto)
        await enviarDatosAlSidePanel(datosOR);
        
    } catch (error) {
        console.error('[ResumenORCAR] Error:', error);
        alert(`Error: ${error.message}`);
    } finally {
        isProcessing = false;
        
        if (boton) {
            boton.classList.remove('btn-loading');
            boton.innerHTML = '<i class="fas fa-robot"></i> Resumen OR';
        }
    }
}

async function enviarDatosAlSidePanel(datosOR) {
    try {
        console.log('[ResumenORCAR] Enviando datos de la OR al Side Panel...');
        await safeChromeRuntimeSendMessage({
            action: 'sendDataToSidePanel',
            data: { datosOR: datosOR }
        });
        console.log('[ResumenORCAR] Datos enviados al Side Panel correctamente');
    } catch (error) {
        console.error('[ResumenORCAR] Error enviando datos al Side Panel:', error);
    }
}

// ========================================
// ESTILOS CSS
// ========================================

const style = document.createElement('style');
style.textContent = `
    .message { margin-bottom: 10px; padding: 5px; }
    .message.user { text-align: right; }
    .message.ai { text-align: left; }
    .message.system { text-align: left; color: #666; font-size: 0.9em; font-style: italic; }
    .message.error { text-align: left; color: #c00; font-size: 0.9em; }
    .bubble { display: inline-block; padding: 10px 14px; border-radius: 12px; max-width: 90%; word-wrap: break-word; line-height: 1.5; text-align: left; }
    .message.user .bubble { background: #28a745; color: white; }
    .message.ai .bubble { background: #f8f9fa; color: #333; border: 1px solid #e9ecef; }
    
    /* Encabezados - apartados principales con más espacio */
    .message.ai .bubble h1 { font-size: 1.2em; margin: 1.5em 0 0.5em 0; font-weight: bold; color: #1a1a1a; border-bottom: 2px solid #28a745; padding-bottom: 0.3em; }
    .message.ai .bubble h1:first-child { margin-top: 0; }
    .message.ai .bubble h2 { font-size: 1.1em; margin: 1.3em 0 0.4em 0; font-weight: bold; color: #2c2c2c; border-bottom: 1px solid #ddd; padding-bottom: 0.2em; }
    .message.ai .bubble h2:first-child { margin-top: 0; }
    .message.ai .bubble h3 { font-size: 1.05em; margin: 1.2em 0 0.4em 0; font-weight: bold; color: #333; }
    .message.ai .bubble h3:first-child { margin-top: 0; }
    .message.ai .bubble h4 { font-size: 1em; margin: 1em 0 0.3em 0; font-weight: bold; color: #444; }
    .message.ai .bubble h4:first-child { margin-top: 0; }
    
    /* Puntos numerados dentro de apartados (1., 2., 3.) - más espacio antes */
    .message.ai .bubble ol > li { margin-top: 0.8em !important; padding-top: 0.3em !important; }
    .message.ai .bubble ol > li:first-child { margin-top: 0.3em !important; }
    
    /* Párrafos con negrita al inicio (subapartados) - más espacio */
    .message.ai .bubble p > strong:first-child { display: inline-block; margin-top: 0.5em; }
    
    /* Listas - espaciado mínimo con viñetas */
    .message.ai .bubble ul { margin: 0.2em 0; padding-left: 1.5em; line-height: 1.3; list-style-type: disc !important; }
    .message.ai .bubble ol { margin: 0.3em 0; padding-left: 1.5em; line-height: 1.3; list-style-type: decimal !important; }
    .message.ai .bubble li { margin: 0 !important; padding: 0 !important; line-height: 1.3 !important; display: list-item !important; }
    .message.ai .bubble ul li { margin: 0.1em 0 !important; } /* Viñetas internas sin mucho espacio */
    .message.ai .bubble ul ul { list-style-type: circle !important; margin: 0; padding-left: 1.2em; }
    .message.ai .bubble ul ul ul { list-style-type: square !important; }
    .message.ai .bubble ol ol, .message.ai .bubble ul ol, .message.ai .bubble ol ul { margin: 0; padding-left: 1.2em; }
    .message.ai .bubble p { margin: 0.2em 0; line-height: 1.2; }
    
    /* Tablas */
    .message.ai .bubble table { border-collapse: collapse; width: 100%; margin: 0.8em 0; font-size: 0.85em; overflow-x: auto; display: block; }
    .message.ai .bubble th, .message.ai .bubble td { border: 1px solid #ccc; padding: 6px 10px; text-align: left; vertical-align: top; }
    .message.ai .bubble th { background-color: #28a745; color: white; font-weight: bold; white-space: nowrap; }
    .message.ai .bubble td:nth-child(2), .message.ai .bubble td:nth-child(3) { text-align: center; } /* Centrar columnas numéricas */
    .message.ai .bubble tr:nth-child(even) { background-color: #f5f5f5; }
    .message.ai .bubble tr:hover { background-color: #e8f5e9; }
    .message.ai .bubble thead { position: sticky; top: 0; }
    .message.ai .bubble tbody tr:first-child td { border-top: 2px solid #28a745; }
    
    /* Código inline y bloques */
    .message.ai .bubble code { background: #e9ecef; padding: 2px 6px; border-radius: 4px; font-family: 'Consolas', 'Monaco', monospace; font-size: 0.9em; }
    .message.ai .bubble pre { background: #2d2d2d; color: #f8f8f2; padding: 12px; border-radius: 6px; overflow-x: auto; margin: 0.6em 0; }
    .message.ai .bubble pre code { background: none; padding: 0; color: inherit; }
    
    /* Negrita y cursiva */
    .message.ai .bubble strong, .message.ai .bubble b { font-weight: bold; color: #1a1a1a; }
    .message.ai .bubble em, .message.ai .bubble i { font-style: italic; }
    
    /* Blockquotes */
    .message.ai .bubble blockquote { border-left: 4px solid #28a745; margin: 0.6em 0; padding: 0.5em 1em; background: #f0f7f0; color: #555; }
    
    /* Separadores */
    .message.ai .bubble hr { border: none; border-top: 1px solid #ddd; margin: 1em 0; }
`;
document.head.appendChild(style);

// ========================================
// INICIALIZACIÓN
// ========================================

function inicializar() {
    if (verificarPagina()) {
        console.log('[ResumenORCAR] Inicializado en página de OR');
        
        if (!inyectarBoton()) {
            setTimeout(() => {
                inyectarBoton();
            }, 1000);
        }
        
        // Observer para detectar cambios en el DOM
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    mutation.addedNodes.forEach(node => {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            if (node.querySelector && node.querySelector('.d-flex.flex-row.align-items-center')) {
                                inyectarBoton();
                            }
                        }
                    });
                }
            });
        });
        
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }
}

// Ejecutar inicialización
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', inicializar);
} else {
    inicializar();
}

