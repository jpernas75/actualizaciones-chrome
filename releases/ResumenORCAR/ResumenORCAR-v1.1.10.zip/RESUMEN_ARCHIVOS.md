# Resumen: Archivos para el ZIP de Chrome Web Store

## INCLUIR EN EL ZIP (8 archivos + carpeta images)

| Archivo | Tamaño | Descripción |
|---------|--------|-------------|
| **manifest.json** | 1.13 KB | REQUERIDO - Configuracion de la extension |
| **background.js** | 12.48 KB | REQUERIDO - Service worker |
| **content.js** | 88.61 KB | REQUERIDO - Script principal |
| **marked.min.js** | 38.14 KB | REQUERIDO - Libreria Markdown |
| **coberturas_contratos.js** | 12.06 KB | REQUERIDO - Funciones de coberturas |
| **privacidad.js** | 11.09 KB | REQUERIDO - Funciones de privacidad |
| **gemini_prompt.js** | 8.1 KB | REQUERIDO - Prompts para Gemini |
| **images/** (carpeta) | - | REQUERIDO - Iconos (icon16.png, icon48.png, icon128.png) |

**Total aproximado:** ~171 KB (muy por debajo del limite de 10 MB)

---

## NO INCLUIR EN EL ZIP (9 archivos)

| Archivo | Tamaño | Razón |
|---------|--------|-------|
| **appscript.gs** | 15.99 KB | NO INCLUIR - Codigo de Google Apps Script (se despliega por separado) |
| **gemini_prompt - copia.js** | 4.58 KB | NO INCLUIR - Archivo de respaldo, no se usa |
| **CHROME_STORE_TEXTS.md** | 6.63 KB | NO INCLUIR - Documentacion (solo referencia) |
| **DESPLIEGUE-WEB-APP.md** | 4.29 KB | NO INCLUIR - Documentacion (solo referencia) |
| **FORMULARIO_CHROME_STORE.md** | 7.88 KB | NO INCLUIR - Documentacion (solo referencia) |
| **INSTRUCCIONES_PUBLICACION.md** | 6.3 KB | NO INCLUIR - Documentacion (solo referencia) |
| **MANIFEST_CORRECCIONES.md** | 2.17 KB | NO INCLUIR - Documentacion (solo referencia) |
| **PRIVACY_POLICY.md** | 4.16 KB | NO INCLUIR - Se aloja en sitio web publico (no en ZIP) |
| **ARCHIVOS_PARA_ZIP.md** | 4.19 KB | NO INCLUIR - Este archivo (solo referencia) |

---

## ESTRUCTURA FINAL DEL ZIP

```
ResumenORCAR-v1.0.0.zip
│
├── manifest.json
├── background.js
├── content.js
├── marked.min.js
├── coberturas_contratos.js
├── privacidad.js
├── gemini_prompt.js
│
└── images/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

**Total: 8 archivos + 1 carpeta con 3 iconos**

---

## IMPORTANTE

1. **NO crear carpeta dentro del ZIP**: Los archivos deben estar directamente en la raiz del ZIP, NO dentro de una carpeta "ResumenORCAR"

2. **appscript.gs NO va en el ZIP**: Este archivo es codigo de Google Apps Script que se despliega por separado en script.google.com. La extension Chrome solo llama a la URL del script desplegado.

3. **PRIVACY_POLICY.md**: Debe alojarse en un sitio web publico y proporcionar la URL en el formulario de Chrome Web Store.

---

## CHECKLIST ANTES DE CREAR EL ZIP

- [ ] manifest.json actualizado (ver MANIFEST_CORRECCIONES.md)
- [ ] Todos los 8 archivos .js listados están presentes
- [ ] La carpeta images/ contiene los 3 iconos
- [ ] NO hay archivos .md en el ZIP
- [ ] NO está incluido appscript.gs
- [ ] NO está incluido "gemini_prompt - copia.js"
- [ ] Los archivos están en la raíz del ZIP (no dentro de una carpeta)

---

## LISTO PARA CREAR EL ZIP

Una vez verificado el checklist, puedes crear el ZIP con estos 8 archivos + la carpeta images.
