// ========================================
// COBERTURAS DE CONTRATOS ELEMENTS - IVECO
// Anexo I - Coberturas Generales (Corrección)
// ========================================

const COBERTURAS_CONTRATOS = {
  "documento_referencia": {
    "titulo": "Anexo I - Coberturas Generales de Contratos Elements (Corrección)",
    "emisor": "IVECO España, S.L.",
    "grupo": "IVECO GROUP",
    "contacto": {
      "direccion": "Avenida de Aragón, 402, 28022 Madrid, España",
      "telefono": "913252802",
      "web": "www.iveco.es"
    }
  },
  "leyenda": {
    "V": "Incluido",
    "M": "Mantenimiento",
    "CC": "Cadena Cinemática",
    "ECC": "Extra Cadena Cinemática",
    "D": "Desgaste"
  },
  "coberturas_por_categoria": [
    {
      "categoria": "Mantenimiento",
      "componentes": [
        {
          "descripcion": "Operaciones en plazos temporales o kilométricos indicados en el Libro (M)",
          "planes_incluidos": ["S LIFE", "LIFE", "PLUS LIFE", "2XL LIFE", "3XL LIFE"]
        },
        {
          "descripcion": "Sustitución del Filtro DPF en plazos establecidos (M)",
          "planes_incluidos": ["S LIFE", "LIFE", "PLUS LIFE", "2XL LIFE", "3XL LIFE"]
        }
      ]
    },
    {
      "categoria": "Motor",
      "componentes": [
        {
          "descripcion": "Motor y sus componentes internos (CC)",
          "planes_incluidos": ["LIFE", "PLUS LIFE", "2XL LIFE", "3XL LIFE", "Xtended Life", "Xtended Plus Life", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Turbocompresor (CC)",
          "planes_incluidos": ["LIFE", "PLUS LIFE", "2XL LIFE", "3XL LIFE", "Xtended Life", "Xtended Plus Life", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Bomba de agua y bomba de aceite (CC)",
          "planes_incluidos": ["LIFE", "PLUS LIFE", "2XL LIFE", "3XL LIFE", "Xtended Life", "Xtended Plus Life", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Buje ventilador y rodamientos (CC)",
          "planes_incluidos": ["LIFE", "PLUS LIFE", "2XL LIFE", "3XL LIFE", "Xtended Life", "Xtended Plus Life", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Volante (CC)",
          "planes_incluidos": ["LIFE", "PLUS LIFE", "2XL LIFE", "3XL LIFE", "Xtended Life", "Xtended Plus Life", "Xtended Xtra Life"]
        }
      ]
    },
    {
      "categoria": "Sistema de inyección de combustible",
      "componentes": [
        {
          "descripcion": "Sistema de inyección e inyectores (CC)",
          "planes_incluidos": ["LIFE", "PLUS LIFE", "2XL LIFE", "3XL LIFE", "Xtended Life", "Xtended Plus Life", "Xtended Xtra Life"]
        }
      ]
    },
    {
      "categoria": "Caja de cambios",
      "componentes": [
        {
          "descripcion": "Caja de cambios (CC)",
          "planes_incluidos": ["LIFE", "PLUS LIFE", "2XL LIFE", "3XL LIFE", "Xtended Life", "Xtended Plus Life", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Centralita electrónica (CC)",
          "planes_incluidos": ["LIFE", "PLUS LIFE", "2XL LIFE", "3XL LIFE", "Xtended Life", "Xtended Plus Life", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Retardador hidráulico (CC)",
          "planes_incluidos": ["LIFE", "PLUS LIFE", "2XL LIFE", "3XL LIFE", "Xtended Life", "Xtended Plus Life", "Xtended Xtra Life"]
        }
      ]
    },
    {
      "categoria": "Transmisión",
      "componentes": [
        {
          "descripcion": "Eje de transmisión (CC)",
          "planes_incluidos": ["LIFE", "PLUS LIFE", "2XL LIFE", "3XL LIFE", "Xtended Life", "Xtended Plus Life", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Junta de cardán (CC)",
          "planes_incluidos": ["LIFE", "PLUS LIFE", "2XL LIFE", "3XL LIFE", "Xtended Life", "Xtended Plus Life", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Retardador electrónico (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        }
      ]
    },
    {
      "categoria": "Ejes",
      "componentes": [
        {
          "descripcion": "Eje motor, engranajes, diferencial, piñón y cubo (CC)",
          "planes_incluidos": ["LIFE", "PLUS LIFE", "2XL LIFE", "3XL LIFE", "Xtended Life", "Xtended Plus Life", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Ejes delanteros, ejes no motrices y Hi-Traction (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Unidad del secador (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        }
      ]
    },
    {
      "categoria": "Sistema de frenos",
      "componentes": [
        {
          "descripcion": "Cilindro, pinza, válvula y tubo flexible de freno (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Zapatas, pastillas, disco y tambor de freno (D)",
          "planes_incluidos": ["3XL LIFE"]
        }
      ]
    },
    {
      "categoria": "Embrague",
      "componentes": [
        {
          "descripcion": "Servo/Cilindro del embrague principal (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Placa accionada, embrague y disco de empuje (D)",
          "planes_incluidos": ["3XL LIFE"]
        }
      ]
    },
    {
      "categoria": "Bastidor / Suspensión / Dirección",
      "componentes": [
        {
          "descripcion": "Bomba de dirección y Centralita Electrónica (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Plus Life", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Juntas, travesaños, largueros, cojinetes, resorte y ballestas (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Sensores de suspensión neumática y válvulas niveladoras (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Fuelles de aire (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Amortiguadores (bastidor) (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        }
      ]
    },
    {
      "categoria": "Sistema de escape",
      "componentes": [
        {
          "descripcion": "Tornillos, abrazaderas y conectores del sistema de escape (ECC)",
          "planes_incluidos": ["PLUS LIFE", "2XL LIFE", "3XL LIFE", "Xtended Plus Life", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Silenciador, colector y tubo de escape (ECC)",
          "planes_incluidos": ["PLUS LIFE", "2XL LIFE", "3XL LIFE", "Xtended Plus Life", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Sistema de AdBlue y válvula AdBlue (ECC)",
          "planes_incluidos": ["PLUS LIFE", "2XL LIFE", "3XL LIFE", "Xtended Plus Life", "Xtended Xtra Life"]
        }
      ]
    },
    {
      "categoria": "Sistema eléctrico",
      "componentes": [
        {
          "descripcion": "Freno de escape (ECC)",
          "planes_incluidos": ["PLUS LIFE", "2XL LIFE", "3XL LIFE", "Xtended Plus Life", "Xtended Xtra Life"]
        },
        {
          "descripcion": "GPS, radio, IVECONNECT (fábrica) (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Centralita Electrónica (ECC)",
          "planes_incluidos": ["PLUS LIFE", "2XL LIFE", "3XL LIFE", "Xtended Plus Life", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Elevalunas y espejos eléctricos (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        }
      ]
    },
    {
      "categoria": "Otros equipos y componentes",
      "componentes": [
        {
          "descripcion": "Equipo de calefacción y aire acondicionado (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Calefactor adicional (si declarado en presupuesto) (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Tubos y tubos flexibles (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Acelerador / Pedal del gas (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Suspensión de la cabina de amortiguadores (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Compresor de aire (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Bomba de combustible (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Alternador / Motor de arranque (ECC)",
          "planes_incluidos": ["PLUS LIFE", "2XL LIFE", "3XL LIFE", "Xtended Plus Life", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Radiadores (intercooler, agua, aceite, aire) (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Tacógrafo (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        },
        {
          "descripcion": "Palanca del cambio (ECC)",
          "planes_incluidos": ["2XL LIFE", "3XL LIFE", "Xtended Xtra Life"]
        }
      ]
    }
  ]
};

/**
 * Genera un resumen legible de las coberturas para incluir en el prompt
 * @returns {string} - Texto con las coberturas formateadas
 */
function generarResumenCoberturas() {
  let resumen = `
=== INFORMACIÓN DE COBERTURAS DE CONTRATOS ELEMENTS (IVECO) ===
Documento: ${COBERTURAS_CONTRATOS.documento_referencia.titulo}
Emisor: ${COBERTURAS_CONTRATOS.documento_referencia.emisor} - ${COBERTURAS_CONTRATOS.documento_referencia.grupo}

LEYENDA DE COBERTURAS:
- V: Incluido
- M: Mantenimiento
- CC: Cadena Cinemática
- ECC: Extra Cadena Cinemática
- D: Desgaste

TIPOS DE CONTRATOS DISPONIBLES (de menor a mayor cobertura):
- S LIFE: Solo mantenimiento básico (operaciones periódicas y filtro DPF)
- LIFE: Mantenimiento + Cadena Cinemática (motor, caja cambios, transmisión, ejes)
- PLUS LIFE: M + CC + algunos ECC (escape, AdBlue, alternador, freno escape)
- 2XL LIFE: Cobertura extendida (casi todo ECC incluido)
- 3XL LIFE: Máxima cobertura (incluye desgastes: frenos, embrague)
- Xtended Life: Extensión para CC
- Xtended Plus Life: Extensión CC + algunos ECC
- Xtended Xtra Life: Extensión máxima (equivalente a 2XL/3XL)

MATRIZ DE COBERTURAS POR CATEGORÍA:
`;

  COBERTURAS_CONTRATOS.coberturas_por_categoria.forEach(cat => {
    resumen += `\n📌 ${cat.categoria.toUpperCase()}:\n`;
    cat.componentes.forEach(comp => {
      resumen += `   • ${comp.descripcion}\n`;
      resumen += `     ➜ Cubierto en: ${comp.planes_incluidos.join(', ')}\n`;
    });
  });

  resumen += `
NOTAS IMPORTANTES PARA FACTURACIÓN:
1. Si el vehículo tiene contrato M&R, verificar qué tipo de contrato es antes de facturar.
2. Las piezas de DESGASTE (D) como frenos y embrague SOLO están cubiertas en 3XL LIFE.
3. Los componentes ECC tienen cobertura variable según el plan (verificar siempre).
4. S LIFE solo cubre mantenimiento, NO cubre averías mecánicas.
5. Los contratos "Xtended" son extensiones de garantía, no contratos M&R completos.
6. Siempre verificar si la reparación entra en cobertura antes de facturar.
`;

  return resumen;
}

// Exponer globalmente
window.COBERTURAS_CONTRATOS = COBERTURAS_CONTRATOS;
window.generarResumenCoberturas = generarResumenCoberturas;
