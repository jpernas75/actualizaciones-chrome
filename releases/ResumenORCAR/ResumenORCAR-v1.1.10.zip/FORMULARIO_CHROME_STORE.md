# Formulario Chrome Web Store - Textos Listos para Copiar

## INFORMACION BASICA

### Nombre de la Extensión
```
ResumenORCAR
```

### Descripción Corta (132 caracteres máximo)
```
Genera resúmenes inteligentes de Órdenes de Reparación usando Inteligencia Artificial. Extrae y analiza datos de CloudActiveReception.
```
*(132 caracteres - dentro del límite)*

### Categoría
```
Productividad
```

### Idioma Principal
```
Español (España)
```

---

## DESCRIPCION COMPLETA

Copia y pega este texto completo en el campo de descripción:

```
ResumenORCAR es una extensión de Chrome diseñada para profesionales del sector automotriz que utilizan CloudActiveReception. Utiliza Inteligencia Artificial (Google Gemini) para generar resúmenes detallados y análisis inteligentes de las Órdenes de Reparación (OR).

CARACTERISTICAS PRINCIPALES

- Generacion Automatica de Resumenes
- Extrae automaticamente toda la informacion relevante de las OR
- Analiza actuaciones, tiempos de trabajo, comentarios y recambios
- Genera resumenes estructurados y faciles de leer

- Analisis con Inteligencia Artificial
- Utiliza Google Gemini AI para analisis profundos
- Identifica patrones y tendencias en los datos
- Proporciona insights y recomendaciones

- Chat Interactivo con IA
- Interfaz de chat integrada para hacer preguntas sobre la OR
- Respuestas en tiempo real con analisis detallados
- Soporte para adjuntar archivos (PDF, imagenes, documentos)

- Extraccion Completa de Datos
- Informacion de actuaciones y tiempos por mecanico
- Comentarios externos e internos de la OR
- Comentarios del vehiculo y del cliente
- Historial de recambios y peticiones de almacen
- Fechas de matriculacion y datos del vehiculo

- Almacenamiento en Google Drive
- Guarda automaticamente los resumenes en formato TOML
- Almacena las conversaciones con la IA en formato JSON
- Organizacion automatica por fecha y numero de OR

- Privacidad y Seguridad
- Los datos se procesan localmente en tu navegador
- La API Key se almacena de forma segura en Chrome
- No se envian datos a servidores externos excepto Google Gemini API
- Control total sobre que archivos se guardan en Google Drive

FORMATO DE SALIDA

Los resúmenes se generan en formato TOML (Tom's Obvious, Minimal Language), un formato legible y estructurado que incluye:

- Informacion basica de la OR (numero, fecha, vehiculo)
- Resumen de actuaciones con tiempos detallados
- Comentarios organizados por tipo (externos, internos, causas, operaciones)
- Informacion de recambios y peticiones de almacen
- Metadatos y estadisticas de la OR

CASOS DE USO

- Analisis rapido de OR antes de reuniones
- Generacion de informes para clientes
- Identificacion de patrones en reparaciones
- Documentacion estructurada de trabajos realizados
- Analisis de tiempos y eficiencia del taller

REQUISITOS

- Chrome 114 o superior
- Cuenta de Google con acceso a Google Drive
- API Key de Google Gemini (se configura en la extensión)
- Acceso a CloudActiveReception con permisos de edición de OR

INSTALACION Y CONFIGURACION

1. Instala la extension desde Chrome Web Store
2. Configura tu API Key de Google Gemini (se puede obtener desde Google AI Studio)
3. Asegurate de tener acceso a Google Drive
4. Navega a una pagina de edicion de OR en CloudActiveReception
5. Haz clic en el boton "Resumen OR" para comenzar

NOTAS IMPORTANTES

- Esta extension esta disenada especificamente para CloudActiveReception
- Requiere permisos para acceder a las paginas de edicion de OR
- Los datos se procesan segun las politicas de privacidad de Google Gemini
- El usuario es responsable de mantener segura su API Key

Desarrollado por INTURASA para mejorar la productividad y el analisis en talleres automotrices.
```

---

## DECLARACION DE USO DE DATOS

### ¿Recopila datos del usuario?
```
Sí
```

### Tipo de datos recopilados
```
Informacion de uso (cuando se usa la extension)
Datos de sesion (cookie CAR_SESSION para identificar usuario)
```

### ¿Cómo se utilizan los datos?
```
Los datos extraídos de las OR se envían a la API de Google Gemini para generar resúmenes y análisis con Inteligencia Artificial. Los resúmenes generados y las conversaciones se guardan en Google Drive del usuario o de la organización. El usuario controla completamente qué archivos se guardan y dónde se almacenan.
```

### ¿Se venden los datos?
```
No
```

### ¿Se comparten los datos con terceros?
```
Sí, con Google Gemini API para procesamiento con Inteligencia Artificial según las políticas de privacidad de Google.
```

---

## EXPLICACION DE PERMISOS

### activeTab
```
NOTA: Este permiso fue eliminado porque no se usa. La extension usa content_scripts que se ejecutan automaticamente y ya tienen acceso al DOM de la pagina. El permiso activeTab solo es necesario cuando se accede a la pestaña desde un popup o boton de accion, lo cual NO aplica a esta extension.
```

### storage
```
Almacena la API Key de Google Gemini AI localmente en el navegador para no tener que introducirla cada vez que se usa la extensión.
```

### scripting
```
NOTA: Este permiso fue eliminado porque no se usa. Los scripts se inyectan automaticamente mediante content_scripts en el manifest.json, no mediante chrome.scripting API.
```

### cookies
```
Lee la cookie de sesión CAR_SESSION para identificar al usuario que realiza la operación y registrar accesos en los archivos de Google Drive.
```

### Host Permission: cloudactivereception.com
```
Necesario para acceder a las paginas de edicion de Ordenes de Reparacion en CloudActiveReception y extraer la informacion necesaria para generar los resumenes.
```

### Host Permission: generativelanguage.googleapis.com
```
Necesario para enviar los datos extraidos de las OR a la API de Google Gemini y recibir los analisis y resumenes generados con Inteligencia Artificial.
```

### Host Permission: script.google.com
```
Necesario para guardar y leer archivos en Google Drive mediante Google Apps Script. Los resumenes generados y las conversaciones se almacenan automaticamente en Google Drive.
```

---

## INFORMACION DE CONTACTO

### Desarrollador
```
INTURASA
```

### Sitio Web
```
https://www.inturasa.com
```

### Email de Soporte
```
support@inturasa.com
```
*(O proporciona una URL de página de soporte si la tienes)*

### URL de Política de Privacidad
```
[URL donde hayas alojado el archivo PRIVACY_POLICY.md]
```
**Ejemplo:** `https://www.inturasa.com/privacy/resumenorcar`

---

## CAPTURAS DE PANTALLA

**Requisitos:**
- Mínimo: 1 captura
- Máximo: 5 capturas
- Tamaño: 1280x800 o 640x400 píxeles
- Formato: PNG o JPEG

**Sugerencias de contenido:**
1. Botón "Resumen OR" visible en la página de edición de OR
2. Ventana de chat con análisis generado por IA
3. Ejemplo de resumen mostrando datos estructurados
4. Interfaz de chat con preguntas y respuestas

---

## CHECKLIST ANTES DE ENVIAR

- [ ] Manifest.json actualizado (ver MANIFEST_CORRECCIONES.md)
- [ ] Archivo ZIP creado con todos los archivos necesarios
- [ ] Política de privacidad alojada en URL pública accesible
- [ ] Al menos 1 captura de pantalla preparada
- [ ] Todos los textos copiados correctamente
- [ ] Cuenta de desarrollador creada ($5 USD pagados)
- [ ] Extensión probada en modo de incógnito
- [ ] Todos los permisos justificados con explicaciones claras
- [ ] URL de política de privacidad verificada y accesible

---

## NOTAS IMPORTANTES

1. **Tiempo de revision**: Puede tardar de 1 a 7 dias habiles
2. **Si es rechazada**: Revisa los comentarios y corrige los problemas
3. **Actualizaciones**: Tambien pasan por revision pero suelen ser mas rapidas
4. **Manten actualizada**: La politica de privacidad si cambias como se manejan los datos

---

**¡Buena suerte con la publicacion!**
