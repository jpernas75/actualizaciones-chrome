# Actualizador de ResumenORCAR para equipos cliente (instalacion descomprimida).
#
# Chrome no auto-actualiza extensiones cargadas descomprimidas, asi que este
# script hace el trabajo:
#   1. Lee la version y la URL del ZIP desde updates.xml (GitHub Pages, publico).
#   2. Si hay version nueva, descarga el ZIP directamente (sin token: el ZIP
#      vive en el repo publico actualizaciones-chrome, no en la Release privada).
#   3. Reemplaza el contenido de ESTA carpeta (con backup previo en %TEMP%).
#   4. La propia extension detecta el cambio en disco y se recarga sola
#      (ver update-checker.js); si por lo que sea no lo hace, basta con
#      recargarla a mano en chrome://extensions.
#
# Pensado para ejecutarse solo (sin ventana, sin intervencion) via una tarea
# programada — ver instalar-actualizacion-automatica.ps1 — con -Silencioso.
#
# Uso:
#   .\actualizar.ps1                 # comprueba y actualiza si hay version nueva
#   .\actualizar.ps1 -SoloComprobar  # solo informa, no toca nada
#   .\actualizar.ps1 -Forzar         # reinstala aunque la version sea la misma
#   .\actualizar.ps1 -Silencioso     # sin salida por consola, todo va al log

param(
    [switch]$SoloComprobar,
    [switch]$Forzar,
    [switch]$Silencioso
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

$PackageName   = 'ResumenORCAR'
$ExtensionId   = 'fgcoccfmoihgnjlcmnoloobalhdlilcc'
$UpdatesXmlUrl = 'https://jpernas75.github.io/actualizaciones-chrome/updates.xml'

$InstallDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogFile = Join-Path $InstallDir 'actualizar.log'

function Write-Paso {
    param([string]$Texto)
    $linea = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $Texto"
    Add-Content -Path $LogFile -Value $linea -ErrorAction SilentlyContinue
    if (-not $Silencioso) {
        Write-Host "[$PackageName] $Texto"
    }
}

try {
    # --- Version instalada (manifest.json de esta carpeta) ---
    $manifestPath = Join-Path $InstallDir 'manifest.json'
    if (-not (Test-Path $manifestPath)) {
        throw "No se encontro manifest.json en $InstallDir. Ejecuta este script desde la carpeta de la extension."
    }
    $localVersion = (Get-Content $manifestPath -Raw | ConvertFrom-Json).version
    Write-Paso "Version instalada: $localVersion"

    # --- Version remota + URL publica del ZIP (updates.xml, sin autenticacion) ---
    Write-Paso "Consultando $UpdatesXmlUrl ..."
    $xmlResp = Invoke-WebRequest -Uri $UpdatesXmlUrl -UseBasicParsing
    [xml]$updatesXml = $xmlResp.Content
    $app = $updatesXml.gupdate.app | Where-Object { $_.appid -eq $ExtensionId }
    if (-not $app) {
        throw "El ID $ExtensionId no aparece en updates.xml. Revisa actualizaciones-chrome/extensions.json."
    }
    $remoteVersion = $app.updatecheck.version
    $zipUrl = $app.updatecheck.codebase
    Write-Paso "Version publicada: $remoteVersion"

    $hayNueva = [version]$remoteVersion -gt [version]$localVersion
    if (-not $hayNueva -and -not $Forzar) {
        Write-Paso 'Ya tienes la ultima version. Nada que hacer.'
        return
    }
    if ($SoloComprobar) {
        if ($hayNueva) {
            Write-Paso "HAY VERSION NUEVA ($remoteVersion). Ejecuta .\actualizar.ps1 para instalarla."
        }
        return
    }

    # --- Descargar el ZIP (publico, sin token) ---
    $workDir = Join-Path $env:TEMP ("$PackageName-update-" + (Get-Date -Format 'yyyyMMdd_HHmmss'))
    New-Item -ItemType Directory -Force -Path $workDir | Out-Null
    $zipName = Split-Path -Leaf $zipUrl
    $zipPath = Join-Path $workDir $zipName

    Write-Paso "Descargando $zipUrl ..."
    Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing

    # --- Extraer y validar ---
    $stagingDir = Join-Path $workDir 'staging'
    Expand-Archive -Path $zipPath -DestinationPath $stagingDir -Force
    $stagingManifest = Join-Path $stagingDir 'manifest.json'
    if (-not (Test-Path $stagingManifest)) {
        throw "El ZIP descargado no contiene manifest.json ($zipPath)."
    }
    $stagingVersion = (Get-Content $stagingManifest -Raw | ConvertFrom-Json).version
    if ($stagingVersion -ne $remoteVersion) {
        throw "El ZIP contiene la version $stagingVersion pero updates.xml anuncia $remoteVersion."
    }

    # --- Backup e instalacion ---
    $backupDir = Join-Path $env:TEMP ("$PackageName-backup-v$localVersion-" + (Get-Date -Format 'yyyyMMdd_HHmmss'))
    Write-Paso "Backup de la version actual en $backupDir"
    Copy-Item -Path $InstallDir -Destination $backupDir -Recurse

    Write-Paso "Instalando $remoteVersion en $InstallDir ..."
    # /XF excluye el log de la sincronizacion: el ZIP no lo trae y /MIR lo borraria.
    robocopy $stagingDir $InstallDir /MIR /XF actualizar.log /NFL /NDL /NJH /NJS | Out-Null
    if ($LASTEXITCODE -ge 8) {
        throw "robocopy fallo con codigo $LASTEXITCODE. La version anterior esta en $backupDir."
    }

    Remove-Item -Recurse -Force $workDir -ErrorAction SilentlyContinue

    Write-Paso "Actualizado a $remoteVersion. La extension se recargara sola en Chrome (o al reiniciarlo)."
}
catch {
    Write-Paso "ERROR: $($_.Exception.Message)"
    if (-not $Silencioso) { throw }
}
