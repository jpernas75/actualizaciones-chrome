# Archivos para el ZIP de Chrome Web Store

## ARCHIVOS QUE SI DEBEN INCLUIRSE

### Archivos Principales (segun manifest.json)
- **manifest.json** - Archivo de configuracion de la extension
- **background.js** - Service worker que maneja las peticiones a Google Drive
- **content.js** - Script principal que se inyecta en las paginas de CloudActiveReception

### Scripts de Contenido (content_scripts en manifest.json)
- **marked.min.js** - Libreria para convertir Markdown a HTML
- **coberturas_contratos.js** - Funciones relacionadas con coberturas y contratos
- **privacidad.js** - Funciones de privacidad/ofuscacion de datos
- **gemini_prompt.js** - Funciones para construir prompts para Gemini AI

### Iconos (icons en manifest.json)
- **images/icon16.png** - Icono 16x16 pixeles
- **images/icon48.png** - Icono 48x48 pixeles
- **images/icon128.png** - Icono 128x128 pixeles

---

## ARCHIVOS QUE NO DEBEN INCLUIRSE

### Archivos de Documentacion (.md)
- **CHROME_STORE_TEXTS.md** - Solo para referencia, no se incluye en la extension
- **DESPLIEGUE-WEB-APP.md** - Documentacion sobre Google Apps Script
- **FORMULARIO_CHROME_STORE.md** - Textos para el formulario de publicacion
- **INSTRUCCIONES_PUBLICACION.md** - Instrucciones de publicacion
- **MANIFEST_CORRECCIONES.md** - Referencia para corregir manifest.json
- **PRIVACY_POLICY.md** - Se aloja por separado en un sitio web publico
- **ARCHIVOS_PARA_ZIP.md** - Este mismo archivo (solo referencia)

### Archivos de Codigo No Utilizados
- **appscript.gs** - Codigo de Google Apps Script que se despliega por separado en Google Apps Script, NO forma parte de la extension Chrome
- **gemini_prompt - copia.js** - Archivo de respaldo/copia, no se usa

---

## ESTRUCTURA DEL ZIP

El ZIP debe tener esta estructura (archivos directamente en la raiz, NO dentro de una carpeta):

```
ResumenORCAR-v1.0.0.zip
├── manifest.json
├── background.js
├── content.js
├── marked.min.js
├── coberturas_contratos.js
├── privacidad.js
├── gemini_prompt.js
└── images/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

**IMPORTANTE:** 
- NO crear una carpeta "ResumenORCAR" dentro del ZIP
- Los archivos deben estar directamente en la raiz del ZIP
- La carpeta `images/` debe estar incluida con sus 3 iconos

---

## VERIFICACION

Antes de crear el ZIP, verifica que:

1. El manifest.json esta actualizado (ver MANIFEST_CORRECCIONES.md)
2. Todos los archivos .js listados existen y estan presentes
3. Los 3 iconos estan en la carpeta images/
4. No hay archivos .md en el ZIP
5. No esta incluido appscript.gs
6. No esta incluido "gemini_prompt - copia.js"

---

## COMANDO PARA CREAR EL ZIP (Windows PowerShell)

```powershell
# Navegar a la carpeta ResumenORCAR
cd "c:\Users\juanpa.inturasa\Desktop\CursorAi\ResumenORCAR"

# Crear ZIP excluyendo archivos .md y archivos no necesarios
Compress-Archive -Path manifest.json,background.js,content.js,marked.min.js,coberturas_contratos.js,privacidad.js,gemini_prompt.js,images -DestinationPath "ResumenORCAR-v1.0.0.zip" -Force
```

O manualmente:
1. Selecciona estos archivos y carpetas:
   - manifest.json
   - background.js
   - content.js
   - marked.min.js
   - coberturas_contratos.js
   - privacidad.js
   - gemini_prompt.js
   - images/ (carpeta completa)
2. Clic derecho → Enviar a → Carpeta comprimida (en ZIP)
3. Renombra el ZIP a: `ResumenORCAR-v1.0.0.zip`

---

## NOTAS IMPORTANTES

- **appscript.gs**: Este archivo es codigo de Google Apps Script que se despliega por separado en Google Apps Script (script.google.com). NO forma parte de la extension Chrome y NO debe incluirse en el ZIP.

- **Archivos .md**: Son solo documentacion y referencias. La politica de privacidad (PRIVACY_POLICY.md) debe alojarse en un sitio web publico y proporcionar la URL en el formulario de Chrome Web Store.

- **Tamaño del ZIP**: Debe ser menor a 10 MB para Chrome Web Store (tu extension probablemente sera mucho mas pequena).
