# Correccion del Rechazo - ResumenORCAR

## Motivo del Rechazo

La extension fue rechazada por Chrome Web Store con el siguiente motivo:

**Infraccion:** "Solicitar pero no usar los permisos que se indican a continuacion: `activeTab`"

**ID de referencia:** Purple Potassium

**Fecha:** 9 de febrero de 2026

## Solucion

### Paso 1: Eliminar el permiso `activeTab` del manifest.json

El permiso `activeTab` debe ser ELIMINADO porque:

1. La extension NO tiene un popup (action) ni un boton de accion en la barra de herramientas
2. Los scripts se ejecutan automaticamente mediante `content_scripts` que ya tienen acceso completo al DOM de la pagina
3. El permiso `activeTab` solo es necesario cuando:
   - Tienes un popup que necesita acceder al contenido de la pestaña activa
   - Tienes un boton de accion que ejecuta codigo que necesita acceso a la pestaña
   - Usas `chrome.tabs.executeScript()` desde un popup o background script
4. NINGUNO de estos casos aplica a esta extension

### Paso 2: Actualizar manifest.json

Abre el archivo `manifest.json` y elimina `"activeTab"` del array de `permissions`.

**Antes:**
```json
"permissions": [
    "activeTab",  // <-- ELIMINAR ESTA LINEA
    "storage",
    "cookies"
],
```

**Despues:**
```json
"permissions": [
    "storage",
    "cookies"
],
```

### Paso 3: Verificar que todos los permisos se usan

Asegurate de que todos los permisos restantes se usan activamente:

- **storage**: ✅ Se usa para almacenar la API Key (`chrome.storage.local`)
- **cookies**: ✅ Se usa para leer la cookie CAR_SESSION (`chrome.cookies.get()`)

### Paso 4: Crear nuevo ZIP

1. Actualiza el manifest.json eliminando `activeTab`
2. Crea un nuevo ZIP con los archivos actualizados
3. Sube el nuevo ZIP a Chrome Web Store
4. Envialo para revision nuevamente

## Archivos Actualizados

- ✅ manifest.json (eliminar `activeTab` de permissions)
- ✅ MANIFEST_CORRECCIONES.md (actualizado con la correccion)
- ✅ FORMULARIO_CHROME_STORE.md (actualizado explicacion de permisos)
- ✅ CHROME_STORE_TEXTS.md (actualizado explicacion de permisos)
- ✅ INSTRUCCIONES_PUBLICACION.md (actualizado explicacion de permisos)

## Checklist Antes de Reenviar

- [ ] manifest.json actualizado (sin permiso `activeTab`)
- [ ] Todos los permisos restantes se usan activamente
- [ ] Nuevo ZIP creado con los archivos actualizados
- [ ] ZIP subido a Chrome Web Store
- [ ] Informacion del listado actualizada si es necesario

## Notas Importantes

- El permiso `activeTab` NO es necesario cuando se usan `content_scripts` declarados en el manifest
- `content_scripts` se ejecutan automaticamente en las paginas que coinciden con los patrones especificados y ya tienen acceso completo al DOM
- `activeTab` solo es necesario para acceder a la pestaña desde un popup o boton de accion, lo cual NO aplica a esta extension

## Permisos Finales

La extension solo necesita estos permisos:

- **storage**: Para almacenar la API Key localmente
- **cookies**: Para leer la cookie de sesion CAR_SESSION
- **host_permissions**: Para acceder a los dominios necesarios (cloudactivereception.com, generativelanguage.googleapis.com, script.google.com)

Todos estos permisos se usan activamente en el codigo.

---

## Rechazo 2: "Could not load javascript 'marked.min.js' for script" (Marzo 2026)

**ID de referencia:** Yellow Magnesium  
**Tipo:** Spam y posicion en Chrome Web Store  
**Infraccion:** No ofrecer las funciones anunciadas (paquete invalido: no se pudo cargar `marked.min.js` para el script).

### Solucion aplicada

1. **Quitar `marked.min.js` de `content_scripts` en manifest.json**  
   El validador de Chrome Web Store no cargaba correctamente el archivo como script de contenido. Se elimino del array `content_scripts.js`.

2. **Incluir la libreria marked dentro de content.js**  
   El contenido de `marked.min.js` se ha anadido al inicio de `content.js`. Asi el content script ya no depende de un archivo externo y la funcion de Markdown sigue disponible.

3. **Archivos que siguen incluyendo marked.min.js**  
   El archivo `marked.min.js` **sigue siendo necesario** en el ZIP porque `sidepanel.html` lo carga con `<script src="marked.min.js"></script>`. Incluyelo en el paquete para la Chrome Web Store.

### Checklist para reenvio

- [x] manifest.json sin `marked.min.js` en `content_scripts.js`
- [x] content.js con la libreria marked incluida al inicio
- [ ] Nuevo ZIP con: manifest.json, background.js, content.js, **marked.min.js**, coberturas_contratos.js, privacidad.js, gemini_prompt.js, sidepanel.html, sidepanel.js, popup.html, popup.js, images/
- [ ] Probar la extension en local antes de subir
- [ ] Subir y enviar a revision
