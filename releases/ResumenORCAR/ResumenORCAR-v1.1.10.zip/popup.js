// Popup script para ResumenORCAR
document.addEventListener('DOMContentLoaded', function() {
    const btnClausula = document.getElementById('btn-clausula-privacidad');
    const modalClausula = document.getElementById('modal-clausula');
    const modalClose = document.getElementById('modal-close');

    function openModalClausula() {
        modalClausula.classList.remove('hidden');
    }

    function closeModalClausula() {
        modalClausula.classList.add('hidden');
    }

    btnClausula.addEventListener('click', openModalClausula);
    modalClose.addEventListener('click', closeModalClausula);
    modalClausula.addEventListener('click', (e) => {
        if (e.target === modalClausula) closeModalClausula();
    });

    // Banner de nueva version (estado escrito por update-checker.js)
    chrome.storage.local.get('updateInfo', ({ updateInfo }) => {
        if (updateInfo && updateInfo.available) {
            document.getElementById('update-remote-version').textContent = updateInfo.remoteVersion;
            document.getElementById('update-local-version').textContent = updateInfo.localVersion;
            document.getElementById('update-banner').classList.remove('hidden');
        }
    });
});
