// ========================================
// UPDATE CHECKER - ResumenORCAR
// ========================================
// Chrome ignora update_url en extensiones cargadas descomprimidas, asi que la
// actualizacion real la hace una tarea programada en segundo plano que corre
// actualizar.ps1 (ver instalar-actualizacion-automatica.ps1): descarga el ZIP
// publico (sin token) y reemplaza los ficheros de esta carpeta en disco.
//
// Este script hace dos cosas en cada comprobacion periodica:
//   1. Detecta si esos ficheros ya cambiaron en disco (comparando el manifest
//      que hay en memoria con el que hay en disco AHORA MISMO) y, si es asi,
//      llama a chrome.runtime.reload() para que la extension recargue sola,
//      sin que el usuario tenga que ir a chrome://extensions.
//   2. Si la tarea programada no existe o aun no ha corrido, comprueba
//      updates.xml (GitHub Pages, publico) y avisa con un badge, como respaldo.

const UPDATE_XML_URL = 'https://jpernas75.github.io/actualizaciones-chrome/updates.xml';
const UPDATE_CHECK_ALARM = 'resumenorcar-update-check';
const UPDATE_CHECK_PERIOD_MINUTES = 360; // 6 horas

function compareExtensionVersions(a, b) {
    const pa = String(a).split('.').map(Number);
    const pb = String(b).split('.').map(Number);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
        const na = pa[i] || 0;
        const nb = pb[i] || 0;
        if (na !== nb) return na - nb;
    }
    return 0;
}

// Si actualizar.ps1 ya reemplazo los ficheros en disco (via tarea programada)
// mientras Chrome seguia cargado con la version anterior en memoria, esto lo
// detecta y recarga la extension sola. chrome.runtime.getURL() + fetch lee el
// fichero tal cual esta en disco ahora, no el que se cargo al arrancar.
async function reloadIfFilesOnDiskChanged() {
    try {
        const url = chrome.runtime.getURL('manifest.json') + '?t=' + Date.now();
        const res = await fetch(url, { cache: 'no-store' });
        const diskManifest = await res.json();
        const loadedVersion = chrome.runtime.getManifest().version;

        if (compareExtensionVersions(diskManifest.version, loadedVersion) > 0) {
            console.log('[ResumenORCAR][Update] Ficheros en disco ya actualizados a',
                diskManifest.version, '(version cargada:', loadedVersion + '). Recargando...');
            chrome.runtime.reload();
            return true;
        }
    } catch (e) {
        console.warn('[ResumenORCAR][Update] Error comprobando version en disco:', e);
    }
    return false;
}

async function checkForExtensionUpdate() {
    try {
        const res = await fetch(UPDATE_XML_URL, { cache: 'no-store' });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const xml = await res.text();

        // El service worker MV3 no tiene DOMParser: el updates.xml generado por
        // generar-updates-xml.js es plano y estable, se extrae con regex.
        const id = chrome.runtime.id;
        const match = xml.match(new RegExp(
            "<app\\s+appid='" + id + "'>\\s*<updatecheck[^>]*version='([^']+)'"
        ));
        if (!match) {
            console.log('[ResumenORCAR][Update] Este ID no aparece en updates.xml:', id);
            return;
        }

        const remoteVersion = match[1];
        const localVersion = chrome.runtime.getManifest().version;
        const available = compareExtensionVersions(remoteVersion, localVersion) > 0;

        await chrome.storage.local.set({
            updateInfo: {
                available: available,
                remoteVersion: remoteVersion,
                localVersion: localVersion,
                checkedAt: Date.now()
            }
        });

        if (available) {
            // Aviso de respaldo por si la tarea programada de actualizar.ps1 no
            // esta instalada o todavia no ha corrido en este equipo.
            chrome.action.setBadgeText({ text: '↑' });
            chrome.action.setBadgeBackgroundColor({ color: '#dc2626' });
            chrome.action.setTitle({
                title: 'ResumenORCAR ' + localVersion + ' — nueva version ' + remoteVersion +
                    ' disponible. Se instalara sola en segundo plano; si tarda, ejecuta actualizar.bat.'
            });
            console.log('[ResumenORCAR][Update] Nueva version disponible:', remoteVersion, '(instalada:', localVersion + ')');
        } else {
            chrome.action.setBadgeText({ text: '' });
            chrome.action.setTitle({ title: 'ResumenORCAR' });
        }
    } catch (e) {
        console.warn('[ResumenORCAR][Update] Error comprobando actualizaciones:', e);
    }
}

async function runUpdateCycle() {
    const reloaded = await reloadIfFilesOnDiskChanged();
    if (reloaded) return; // chrome.runtime.reload() ya reinicia el service worker
    await checkForExtensionUpdate();
}

chrome.runtime.onInstalled.addListener(() => {
    chrome.alarms.create(UPDATE_CHECK_ALARM, {
        periodInMinutes: UPDATE_CHECK_PERIOD_MINUTES,
        delayInMinutes: 1
    });
    runUpdateCycle();
});

chrome.runtime.onStartup.addListener(() => {
    runUpdateCycle();
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === UPDATE_CHECK_ALARM) {
        runUpdateCycle();
    }
});
