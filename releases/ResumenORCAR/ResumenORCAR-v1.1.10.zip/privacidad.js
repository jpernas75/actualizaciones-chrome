// ========================================
// MÓDULO DE PRIVACIDAD Y OFUSCACIÓN DE DATOS
// ResumenORCAR
// ========================================

/**
 * Ofusca una matrícula sustituyendo TODOS los dígitos por X (tantas X como dígitos)
 * Formatos comunes: 1234ABC, ABC1234, 1234-ABC, ABC-1234, E-1234-ABC
 * @param {string} texto - Texto que puede contener matrículas
 * @returns {string} - Texto con matrículas ofuscadas
 */
function ofuscarMatriculas(texto) {
    if (!texto || typeof texto !== 'string') return texto;
    
    // Patrones de matrículas: sustituir cada dígito por X (tantas X como dígitos)
    // Nuevo formato español: 1234 ABC o 1234ABC -> XXXX ABC
    texto = texto.replace(/\b(\d+)[\s-]?([A-Z]{2,3})\b/gi, (m) => m.replace(/\d/g, 'X'));
    // Formato antiguo/provincia: ABC-1234, M-1234-AB
    texto = texto.replace(/\b([A-Z]{1,2})[\s-]?(\d+)[\s-]?([A-Z]{2,3})\b/gi, (m) => m.replace(/\d/g, 'X'));
    // Letras-dígitos: ABC1234
    texto = texto.replace(/\b([A-Z]{2,3})(\d+)\b/gi, (m) => m.replace(/\d/g, 'X'));
    
    return texto;
}

/**
 * Ofusca un número VIN (17 caracteres) sustituyendo los 13 últimos por X (13 X)
 * @param {string} texto - Texto que puede contener VINs
 * @returns {string} - Texto con VINs ofuscados
 */
function ofuscarVIN(texto) {
    if (!texto || typeof texto !== 'string') return texto;
    
    // VIN: 17 caracteres alfanuméricos (sin I, O, Q)
    // Formato: ZCFM62AV80C497392 -> ZCFM + 13 X = ZCFMXXXXXXXXXXXXX
    const vinRegex = /\b([A-HJ-NPR-Z0-9]{4})([A-HJ-NPR-Z0-9]{13})\b/gi;
    return texto.replace(vinRegex, (_, inicio, resto) => inicio + 'X'.repeat(resto.length));
}

/**
 * Ofusca números de teléfono sustituyendo TODOS los dígitos por X (tantas X como dígitos)
 * @param {string} texto - Texto que puede contener teléfonos
 * @returns {string} - Texto con teléfonos ofuscados
 */
function ofuscarTelefonos(texto) {
    if (!texto || typeof texto !== 'string') return texto;
    
    // Teléfonos: sustituir todos los dígitos por X, manteniendo espacios/guiones/puntos
    // +34 612 345 678 -> +XX XXX XXX XXX
    // 612345678 -> XXXXXXXXX
    texto = texto.replace(/(\+?\d{1,3})([\s.-]?)(\d{3})([\s.-]?)(\d{3})([\s.-]?)(\d{2,4})/g, (m) => m.replace(/\d/g, 'X'));
    
    // Móviles/fijos sin prefijo: 612 345 678, 91 234 56 78
    texto = texto.replace(/\b(\d{2,3})[\s.-]?(\d{3})[\s.-]?(\d{2,4})\b/g, (m) => m.replace(/\d/g, 'X'));
    
    // Secuencias de 6+ dígitos (números de teléfono)
    texto = texto.replace(/\b\d{6,}\b/g, (m) => 'X'.repeat(m.length));
    
    return texto;
}

/**
 * Ofusca direcciones de email: parte local por X (tantas como caracteres), dominio por Y (manteniendo el ".")
 * @param {string} texto - Texto que puede contener emails
 * @returns {string} - Texto con emails ofuscados
 */
function ofuscarEmails(texto) {
    if (!texto || typeof texto !== 'string') return texto;
    
    // Email: usuario@dominio.com -> XXXXXXX@YYYYYY.YYY
    // Parte local: tantas X como caracteres tenga
    // Dominio: Y por cada carácter, pero se conserva el "."
    const emailRegex = /([a-zA-Z0-9._%+-]+)@([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/gi;
    return texto.replace(emailRegex, (_, local, dominio) => {
        const localOfuscado = 'X'.repeat(local.length);
        const dominioOfuscado = dominio.replace(/[^.]/g, 'Y'); // Sustituir todo excepto el punto por Y
        return localOfuscado + '@' + dominioOfuscado;
    });
}

/**
 * Convierte un nombre completo a sus iniciales
 * @param {string} nombre - Nombre completo (ej: "Juan Pedro García López")
 * @returns {string} - Iniciales (ej: "J.P.G.L.")
 */
function nombreAIniciales(nombre) {
    if (!nombre || typeof nombre !== 'string') return nombre;
    
    // Limpiar y dividir por espacios
    const palabras = nombre.trim().split(/\s+/);
    
    // Si solo tiene una palabra corta, probablemente ya son iniciales
    if (palabras.length === 1 && palabras[0].length <= 4) {
        return nombre;
    }
    
    // Convertir a iniciales
    const iniciales = palabras
        .filter(p => p.length > 0)
        .map(p => p.charAt(0).toUpperCase())
        .join('.');
    
    return iniciales + '.';
}

/**
 * Detecta si un texto parece ser un nombre de persona (2+ palabras con mayúscula inicial)
 * Solo se usa para comentarios internos/externos y texto de actuaciones
 * @param {string} texto - Texto a evaluar
 * @returns {boolean}
 */
function pareceNombrePersona(texto) {
    if (!texto || typeof texto !== 'string') return false;
    
    texto = texto.trim();
    if (texto.length < 3 || texto.length > 50) return false;
    if (/\d/.test(texto)) return false;
    if (/[^a-záéíóúüñA-ZÁÉÍÓÚÜÑ\s\-'.]/.test(texto)) return false;
    
    const palabras = texto.split(/\s+/);
    if (palabras.length >= 2) {
        const palabrasConMayuscula = palabras.filter(p => /^[A-ZÁÉÍÓÚÜÑ]/.test(p));
        if (palabrasConMayuscula.length >= 2) return true;
    }
    
    return false;
}

/**
 * Busca nombres en un texto (2+ palabras con mayúscula) y los sustituye por iniciales.
 * Solo para comentarios internos/externos y texto de actuaciones.
 * @param {string} texto - Texto donde buscar nombres
 * @returns {string} - Texto con nombres sustituidos por iniciales
 */
function ofuscarNombresEnTexto(texto) {
    if (!texto || typeof texto !== 'string') return texto;
    
    // Buscar secuencias de 2-5 palabras que empiezan con mayúscula (posibles nombres)
    const regex = /\b([A-ZÁÉÍÓÚÜÑ][a-záéíóúüñ]+(?:\s+[A-ZÁÉÍÓÚÜÑ][a-záéíóúüñ]+){1,4})\b/g;
    return texto.replace(regex, (match) => pareceNombrePersona(match) ? nombreAIniciales(match) : match);
}

/**
 * Ofusca nombres de personas en un objeto, convirtiéndolos a iniciales
 * @param {*} obj - Objeto a procesar
 * @param {string[]} camposNombres - Lista de nombres de campos que contienen nombres de personas
 * @returns {*} - Objeto con nombres ofuscados
 */
function ofuscarNombresEnObjeto(obj, camposNombres = []) {
    // Campos que típicamente contienen nombres de personas (solo por nombre de campo, sin heurística)
    const camposConNombres = [
        'mecanico', 'mecánico', 'operario', 'tecnico', 'técnico', 'responsable',
        'empleado', 'trabajador', 'nombre', 'personal', 'usuario', 'asignado',
        'solicitante', 'receptor', 'creador', 'modificador', 'autor',
        'tracking_user_name', 'user_name', 'full_name', 'nombre_completo',
        'nombre_usuario', 'usuario_nombre', 'nombre_tecnico', 'nombre_mecanico',
        'nombre_operario', 'nombre_responsable', 'nombre_personal',
        ...camposNombres
    ];
    
    // Comentarios internos/externos y texto de actuaciones: buscar nombres en texto libre
    const camposDondeBuscarNombresEnTexto = [
        'contenido', 'descripcion', 'actuaciones', 'description'
    ];
    
    // Campos que son objetos donde las claves son nombres (ej: tiemposPorMecanico)
    const camposConClavesNombres = [
        'tiempospormecanico', 'tiempos_por_mecanico', 'tiemposPorMecanico',
        'fichajespormecanico', 'fichajes_por_mecanico', 'fichajesPorMecanico'
    ];
    
    if (obj === null || obj === undefined) return obj;
    
    if (typeof obj === 'string') return obj;
    
    if (Array.isArray(obj)) return obj.map(item => ofuscarNombresEnObjeto(item, camposNombres));
    
    if (typeof obj === 'object') {
        const resultado = {};
        for (const [key, value] of Object.entries(obj)) {
            const keyLower = key.toLowerCase();
            
            if (camposConClavesNombres.some(campo => keyLower.includes(campo)) && 
                typeof value === 'object' && value !== null && !Array.isArray(value)) {
                const nuevoObjeto = {};
                for (const [nombreMecanico, tiempo] of Object.entries(value)) {
                    nuevoObjeto[nombreAIniciales(nombreMecanico)] = tiempo;
                }
                resultado[key] = nuevoObjeto;
            }
            // Comentarios/actuaciones: buscar nombres en texto (heurística 2+ mayúsculas)
            else if (camposDondeBuscarNombresEnTexto.some(campo => keyLower.includes(campo))) {
                if (typeof value === 'string') {
                    resultado[key] = ofuscarNombresEnTexto(value);
                } else if (Array.isArray(value)) {
                    resultado[key] = value.map(v => typeof v === 'string' ? ofuscarNombresEnTexto(v) : ofuscarNombresEnObjeto(v, camposNombres));
                } else {
                    resultado[key] = ofuscarNombresEnObjeto(value, camposNombres);
                }
            }
            // Campos con nombres explícitos (mecánico, operario, etc.): convertir valor completo
            else if (typeof value === 'string' && camposConNombres.some(campo => keyLower.includes(campo))) {
                resultado[key] = nombreAIniciales(value);
            } else {
                resultado[key] = ofuscarNombresEnObjeto(value, camposNombres);
            }
        }
        return resultado;
    }
    
    return obj;
}

/**
 * Detecta si un texto es un formato de fecha (nunca ofuscar)
 */
function pareceFormatoFecha(texto) {
    if (!texto || typeof texto !== 'string') return false;
    const t = texto.trim();
    if (t.length < 6 || t.length > 32) return false;
    if (/^\d{1,4}[\/\-\.]\d{1,2}[\/\-\.]\d{1,4}([\sT]\d{1,2}:\d{2}(:\d{2})?)?/.test(t)) return true;
    if (/^\d{4}[\/\-\.]\d{1,2}[\/\-\.]\d{1,2}/.test(t)) return true;
    if (/^\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4}/.test(t)) return true;
    return false;
}

/**
 * Aplica todas las ofuscaciones a un texto (excepto si es formato de fecha)
 * @param {string} texto - Texto a ofuscar
 * @returns {string} - Texto ofuscado
 */
function ofuscarTexto(texto) {
    if (!texto || typeof texto !== 'string') return texto;
    if (pareceFormatoFecha(texto)) return texto;

    let resultado = texto;
    resultado = ofuscarVIN(resultado);
    resultado = ofuscarMatriculas(resultado);
    resultado = ofuscarTelefonos(resultado);
    resultado = ofuscarEmails(resultado);

    return resultado;
}

/**
 * Aplica ofuscación selectiva: NO OR, numero, kilometros. En actuaciones SÓLO description. Nunca fechas.
 */
function ofuscarHistoricoSelectivo(obj) {
    if (obj === null || obj === undefined) return obj;

    const camposSinOfuscar = ['or', 'or_numero', 'numero', 'numeros', 'kilometros', 'llegada', 'entrega', 'orid', 'generatedat', 'total', 'ors', 'fecha_recepcion', 'fecha_entrega', 'tracking_time'];
    const esCampoProtegido = (key) => camposSinOfuscar.includes(String(key).toLowerCase());

    if (typeof obj === 'string') return obj;
    if (Array.isArray(obj)) return obj.map((item) => ofuscarHistoricoSelectivo(item));

    if (typeof obj === 'object') {
        const resultado = {};
        for (const [key, value] of Object.entries(obj)) {
            const keyLower = key.toLowerCase();
            if (esCampoProtegido(key)) {
                resultado[key] = value;
            } else if ((keyLower === 'actuaciones' || keyLower === 'actions') && Array.isArray(value)) {
                resultado[key] = value.map((act) => {
                    const acc = { ...act };
                    if ('descripcion' in acc && typeof acc.descripcion === 'string') {
                        if (!pareceFormatoFecha(acc.descripcion)) {
                            acc.descripcion = ofuscarNombresEnTexto(ofuscarTexto(acc.descripcion));
                        }
                    }
                    return acc;
                });
            } else if (keyLower === 'vehiculo' && typeof value === 'object') {
                resultado[key] = value;
            } else {
                resultado[key] = ofuscarHistoricoSelectivo(value);
            }
        }
        return resultado;
    }
    return obj;
}

/**
 * Aplica ofuscaciones recursivamente (excepto fechas)
 */
function ofuscarObjetoRecursivo(obj) {
    if (obj === null || obj === undefined) return obj;

    if (typeof obj === 'string') {
        if (pareceFormatoFecha(obj)) return obj;
        return ofuscarTexto(obj);
    }
    if (Array.isArray(obj)) return obj.map(item => ofuscarObjetoRecursivo(item));

    if (typeof obj === 'object') {
        const resultado = {};
        for (const [key, value] of Object.entries(obj)) {
            resultado[key] = ofuscarObjetoRecursivo(value);
        }
        return resultado;
    }
    return obj;
}

/**
 * Función principal: ofusca con criterio selectivo.
 * NO ofuscar: OR, numero, kilometros, fechas. En actuaciones SÓLO description.
 * @param {Object} datosOR - Datos de la OR a ofuscar
 * @returns {Object} - Datos ofuscados (copia profunda)
 */
function ofuscarDatosOR(datosOR) {
    if (!datosOR) return datosOR;

    console.log('[ResumenORCAR] Aplicando ofuscación selectiva para privacidad...');

    let datosOfuscados = JSON.parse(JSON.stringify(datosOR));
    datosOfuscados = ofuscarHistoricoSelectivo(datosOfuscados);

    console.log('[ResumenORCAR] Ofuscación completada');

    return datosOfuscados;
}

// Exponer funciones globalmente
window.ofuscarDatosOR = ofuscarDatosOR;
window.ofuscarMatriculas = ofuscarMatriculas;
window.ofuscarVIN = ofuscarVIN;
window.ofuscarTelefonos = ofuscarTelefonos;
window.ofuscarEmails = ofuscarEmails;
window.nombreAIniciales = nombreAIniciales;
window.ofuscarTexto = ofuscarTexto;
window.ofuscarNombresEnTexto = ofuscarNombresEnTexto;

