# Política de Privacidad - ResumenORCAR

**Última actualización:** 5 de febrero de 2026

## 1. Información General

ResumenORCAR es una extensión de Chrome desarrollada por INTURASA que permite generar resúmenes inteligentes de Órdenes de Reparación (OR) utilizando Inteligencia Artificial.

## 2. Datos que Recopilamos

### 2.1 Datos de la Sesión
- La extensión accede a cookies de sesión (`CAR_SESSION`) únicamente para identificar al usuario que realiza la operación en el sistema CloudActiveReception.
- Esta información se utiliza exclusivamente para registrar accesos en archivos de Google Drive.

### 2.2 Datos de las Órdenes de Reparación
- La extensión extrae información de las páginas de edición de OR en CloudActiveReception, incluyendo:
  - Número de OR y datos básicos
  - Actuaciones realizadas
  - Tiempos de trabajo
  - Comentarios (externos e internos)
  - Información de vehículos y clientes
  - Datos de recambios

### 2.3 Datos Almacenados Localmente
- La extensión almacena la API Key de Gemini AI en el almacenamiento local de Chrome (`chrome.storage.local`).
- Esta clave se utiliza únicamente para realizar consultas a la API de Google Gemini.

## 3. Uso de los Datos

### 3.1 Procesamiento con IA
- Los datos extraídos de las OR se envían a la API de Google Gemini para generar resúmenes y análisis.
- Los datos se procesan según las políticas de privacidad de Google Gemini.

### 3.2 Almacenamiento en Google Drive
- Los resúmenes generados y las conversaciones se guardan en Google Drive del usuario o de la organización.
- El usuario controla completamente qué archivos se guardan y dónde se almacenan.

## 4. Permisos Requeridos

### 4.1 storage
- Permite almacenar la API Key de Gemini AI localmente en el navegador.

### 4.2 cookies
- Permite leer la cookie de sesión `CAR_SESSION` para identificar al usuario.

### 4.5 host_permissions
- **cloudactivereception.com**: Para acceder a las páginas de edición de OR y extraer información.
- **generativelanguage.googleapis.com**: Para enviar datos a la API de Google Gemini y generar resúmenes.
- **script.google.com**: Para guardar y leer archivos en Google Drive mediante Google Apps Script.

## 5. Compartir Datos

- **No vendemos ni compartimos datos con terceros** excepto:
  - Google Gemini API: Los datos de las OR se envían a esta API para procesamiento con IA.
  - Google Drive: Los archivos generados se guardan en Google Drive según la configuración del usuario.

## 6. Seguridad

- La API Key de Gemini se almacena localmente en el navegador del usuario.
- Las comunicaciones con las APIs externas se realizan mediante HTTPS.
- Los datos no se transmiten a servidores de INTURASA.

## 7. Retención de Datos

- Los datos almacenados localmente (API Key) permanecen en el navegador hasta que el usuario desinstale la extensión o borre los datos del navegador.
- Los archivos guardados en Google Drive permanecen según las políticas de Google Drive y el control del usuario.

## 8. Derechos del Usuario

Los usuarios pueden:
- Desinstalar la extensión en cualquier momento.
- Eliminar los datos almacenados localmente desde la configuración de Chrome.
- Controlar qué archivos se guardan en Google Drive.
- Revocar el acceso a Google Drive desde la configuración de Google.

## 9. Cambios en la Política de Privacidad

Nos reservamos el derecho de actualizar esta política de privacidad. Los cambios se publicarán en esta página con la fecha de última actualización.

## 10. Contacto

Para preguntas sobre esta política de privacidad, contacte con:
- **Desarrollador:** INTURASA
- **Sitio web:** https://www.inturasa.com

---

**Nota importante:** Esta extensión está diseñada para uso interno en organizaciones que utilizan CloudActiveReception. El uso de la extensión implica el consentimiento para procesar datos según se describe en esta política.
