# ResumenORCAR – Acceso al archivo de configuración en Drive (cualquier usuario)

## Por qué solo funciona con “tu” sesión

La extensión **no** usa la sesión de Chrome del usuario para leer en Drive. Usa un **Google Apps Script** desplegado como Web App que hace las peticiones a Drive por ti.

El comportamiento depende de **cómo está desplegada** esa Web App:

| Configuración | Comportamiento |
|---------------|----------------|
| **Execute as: User accessing the web app** | El script se ejecuta como “el usuario que accede”. En una extensión, eso suele ser la cuenta con la que está iniciada sesión en Chrome. Si otro usuario usa la extensión, el script corre como ese otro usuario y **no ve la carpeta/archivo de tu Drive**. |
| **Execute as: Me** | El script **siempre** se ejecuta con la cuenta del **propietario del proyecto** (quien desplegó la app). Drive accede al Drive de ese propietario. **Cualquier** usuario que llame a la URL (con o sin tu sesión) verá los archivos de esa cuenta. |

Si “solo funciona con tu sesión”, casi seguro la Web App está en **Execute as: User accessing the web app**. Eso es lo que provoca el fallo. Si el JSON se guarda en el Drive de quien tiene la sesión en Chrome (y no en la carpeta IACAR), es por el mismo motivo: usar **Execute as: Me**.

## Qué hacer para que cualquier usuario acceda al JSON de API Key

Tienes que **re-desplegar** la Web App del Apps Script con esta configuración:

1. Abre el proyecto en [Google Apps Script](https://script.google.com) (el que usa la URL que está en `background.js` como `GOOGLE_SCRIPT_URL`).
2. Menú **Implementar** → **Gestionar implementaciones**.
3. Abre la implementación existente (o crea una nueva).
4. En **Configuración**:
   - **Quién tiene acceso:** elige **“Cualquier persona”** (o “Cualquier persona, incluso anónimos” si quieres que no pida login).
   - **Ejecutar como:** elige **“Yo”** (la cuenta con la que está creado el proyecto y donde está la carpeta de Drive con `ResumenORCAR-config.json`).
5. Guarda y, si te lo pide, **crea una nueva versión** (por ejemplo “Para acceso desde cualquier usuario”).
6. La URL de la Web App (`GOOGLE_SCRIPT_URL`) no suele cambiar al re-desplegar; si cambia, actualiza `background.js` con la nueva URL.

Después de esto, **cualquier usuario** con la extensión instalada (con cualquier sesión de Chrome) podrá leer el archivo `ResumenORCAR-config.json` de **tu** Drive, porque el script siempre se ejecuta como **tu** cuenta.

## Si ya está “Ejecutar como: Yo” y sigue fallando

1. **Comprueba que la extensión usa la URL correcta**  
   Cada implementación tiene su **propia URL**. Si tienes varias (p. ej. "con .toml", "Sin API-KEY", "Sin título"), la extensión puede estar llamando a una que sigue en "Ejecutar como: usuario que accede".
   - En GAS: **Implementar** → **Gestionar implementaciones** → abre la que tiene "Ejecutar como: Yo".
   - Copia la **URL** que aparece ahí.
   - En la extensión, abre `ResumenORCAR/background.js` y sustituye el valor de `GOOGLE_SCRIPT_URL` por esa URL exacta.
   - Recarga la extensión en `chrome://extensions`.

2. **Mira el error real en la consola**  
   Con los últimos cambios, cuando falle la lectura verás:
   - En la **consola del Service Worker** (en `chrome://extensions` → ResumenORCAR → "Inspeccionar vistas: service worker"): `[ResumenORCAR][Drive] Lectura fallida: ...` y la respuesta del script.
   - En la **consola de la página** (F12 en la pestaña de CAR): `[ResumenORCAR] Drive devolvió error: ...` o `[ResumenORCAR] Drive: ...`.
   Así sabrás si el script responde "No se encontró archivo", "Falta folderId", etc.

3. **Comprueba que el archivo existe**  
   En el Drive de la cuenta con la que está "Ejecutar como: Yo", en la carpeta cuyo ID está en `DRIVE_FOLDER_ID` (y en el script como `FOLDER_ID`), debe existir exactamente el archivo `ResumenORCAR-config.json` con una propiedad `gemini_api_key`.

## Resumen

- **Es normal** que falle si la Web App está en “Execute as: User” y otro usuario usa la extensión.
- **Solución:** Re-desplegar la Web App con **Execute as: Me** y **Who has access: Anyone**.
- La extensión ya envía siempre `apiKey` en la petición de lectura; no depende de la sesión del navegador para esa llamada.
