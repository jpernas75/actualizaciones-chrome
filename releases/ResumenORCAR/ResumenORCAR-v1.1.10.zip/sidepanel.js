// ========================================
// SIDE PANEL SCRIPT - ResumenORCAR
// ========================================
// Maneja la interfaz de chat dentro del Side Panel nativo de Chrome

console.log('[ResumenORCAR][SidePanel] Script cargado');

const EXT_VERSION = (typeof chrome !== 'undefined' && chrome.runtime?.getManifest)
    ? chrome.runtime.getManifest().version
    : '';

// --- Configuración ---
let GEMINI_API_KEY = null;
const MODEL_VERSION = 'gemini-3.1-pro-preview';
const MODEL_FALLBACKS = ['gemini-3-pro-preview', 'gemini-2.5-flash'];
const CONFIG_FILE_NAME = 'ResumenORCAR-config.json';

// --- Estado Global ---
let isProcessing = false;
let conversationHistory = [];
let datosORActual = null;
let archivoAdjuntoActual = null;

// ========================================
// API KEY - CARGA DINÁMICA
// ========================================

async function obtenerApiKeyDesdeStorage() {
    return new Promise((resolve) => {
        try {
            chrome.storage.local.get(['gemini_api_key'], (result) => {
                if (chrome.runtime.lastError) {
                    console.warn('[ResumenORCAR][SidePanel] Error leyendo Storage:', chrome.runtime.lastError);
                    resolve(null);
                } else {
                    resolve(result.gemini_api_key || null);
                }
            });
        } catch (error) {
            console.warn('[ResumenORCAR][SidePanel] Error en obtenerApiKeyDesdeStorage:', error);
            resolve(null);
        }
    });
}

function isValidApiKey(value) {
    if (!value || typeof value !== 'string') return false;
    const trimmed = value.trim();
    if (!trimmed || trimmed === 'YOUR_API_KEY' || trimmed === 'YOUR_GEMINI_API_KEY') return false;
    // Standard key (legacy AIza...)
    if (/^AIza[0-9A-Za-z\-_]{20,}$/.test(trimmed)) return true;
    // Auth key (AI Studio desde 2026, prefijo AQ.)
    if (/^AQ\.[A-Za-z0-9_\-.]{20,}$/.test(trimmed)) return true;
    return false;
}

function describirFormatoApiKey(value) {
    if (!value) return 'vacía';
    const t = String(value).trim();
    if (t.startsWith('sk-')) {
        return 'formato OpenAI (sk-...); ponla en openai_api_key, no en gemini_api_key';
    }
    if (t.startsWith('AIza') || t.startsWith('AQ.')) {
        return 'empieza por ' + (t.startsWith('AQ.') ? 'AQ.' : 'AIza') + ' pero no cumple el patrón esperado';
    }
    return 'formato no reconocido para Gemini (debe ser AIza... o AQ....)';
}

function geminiApiHeaders(apiKey, extra = {}) {
    return { ...extra, 'x-goog-api-key': apiKey };
}

async function limpiarApiKeyEnStorage() {
    GEMINI_API_KEY = null;
    return new Promise((resolve) => {
        chrome.storage.local.remove(['gemini_api_key'], () => resolve(!chrome.runtime.lastError));
    });
}

async function guardarApiKeyEnStorage(apiKey) {
    return new Promise((resolve) => {
        try {
            chrome.storage.local.set({ gemini_api_key: apiKey }, () => {
                if (chrome.runtime.lastError) {
                    console.warn('[ResumenORCAR][SidePanel] Error guardando en Storage:', chrome.runtime.lastError);
                    resolve(false);
                } else {
                    console.log('[ResumenORCAR][SidePanel] API Key guardada en Storage');
                    resolve(true);
                }
            });
        } catch (error) {
            console.warn('[ResumenORCAR][SidePanel] Error en guardarApiKeyEnStorage:', error);
            resolve(false);
        }
    });
}

async function obtenerApiKeyDesdeDrive() {
    try {
        console.log('[ResumenORCAR][SidePanel] Buscando API key en Drive, archivo:', CONFIG_FILE_NAME);
        const resultado = await safeChromeRuntimeSendMessage({
            action: 'readFromDrive',
            data: { name: CONFIG_FILE_NAME, match: 'exact', as: 'text' }
        });

        console.log('[ResumenORCAR][SidePanel] Respuesta de Drive:', resultado?.success ? 'ok' : 'error',
            resultado?.data?.name || '', resultado?.data?.updated || '');

        if (resultado && resultado.success && resultado.data && resultado.data.content) {
            let content = resultado.data.content;
            // Limpiar BOM y espacios si es string
            if (typeof content === 'string') {
                content = content.replace(/^\uFEFF/, '').trim();
                try { content = JSON.parse(content); } catch(e) {
                    console.warn('[ResumenORCAR][SidePanel] Error parseando content (1er intento):', e.message);
                }
            }
            if (typeof content === 'string') {
                content = content.replace(/^\uFEFF/, '').trim();
                try { content = JSON.parse(content); } catch(e) {
                    console.warn('[ResumenORCAR][SidePanel] Error parseando content (2do intento):', e.message);
                }
            }
            const config = (typeof content === 'object') ? content : null;
            console.log('[ResumenORCAR][SidePanel] Config parseada:', config ? 'OK' : 'null', 'tiene api_key:', !!(config && config.gemini_api_key));
            if (config && config.gemini_api_key) {
                return String(config.gemini_api_key).trim();
            }
        }
        if (resultado && !resultado.success) {
            const errMsg = resultado.data?.error || resultado.error;
            console.warn('[ResumenORCAR][SidePanel] Drive devolvió error:', errMsg);
        } else if (resultado?.data?.ok === false && resultado.data?.error) {
            console.warn('[ResumenORCAR][SidePanel] Drive:', resultado.data.error);
        } else {
            console.warn('[ResumenORCAR][SidePanel] Drive: respuesta inesperada o sin contenido');
        }
    } catch (error) {
        console.warn('[ResumenORCAR][SidePanel] Error obteniendo API key desde Drive:', error);
    }
    return null;
}

async function sincronizarGeminiApiKeyDesdeDrive() {
    const keyDrive = await obtenerApiKeyDesdeDrive();
    if (!keyDrive) {
        return { ok: false, reason: 'drive_missing' };
    }

    const normalized = String(keyDrive).trim();
    if (!isValidApiKey(normalized)) {
        const hint = describirFormatoApiKey(normalized);
        console.error('[ResumenORCAR][SidePanel] gemini_api_key en Drive no válida para Gemini:', hint);
        const keyStorage = await obtenerApiKeyDesdeStorage();
        if (keyStorage) {
            await limpiarApiKeyEnStorage();
            console.warn('[ResumenORCAR][SidePanel] Caché local borrada para no usar una key antigua');
        }
        return { ok: false, reason: 'drive_invalid_format', hint };
    }

    const keyStorage = await obtenerApiKeyDesdeStorage();
    if (keyStorage !== normalized) {
        if (keyStorage) {
            console.log('[ResumenORCAR][SidePanel] API Key actualizada desde Drive (sustituye caché antigua)');
            console.log('[ResumenORCAR][SidePanel] Antes:', keyStorage.substring(0, 8) + '... → Ahora:', normalized.substring(0, 8) + '...');
        } else {
            console.log('[ResumenORCAR][SidePanel] API Key cargada desde Drive (' + normalized.substring(0, 8) + '...)');
        }
        await guardarApiKeyEnStorage(normalized);
    } else {
        console.log('[ResumenORCAR][SidePanel] API Key en Drive = Storage (' + normalized.substring(0, 8) + '...)');
    }
    GEMINI_API_KEY = normalized;
    return { ok: true };
}

async function obtenerGeminiApiKey() {
    if (GEMINI_API_KEY && isValidApiKey(GEMINI_API_KEY)) {
        return GEMINI_API_KEY;
    }

    console.log('[ResumenORCAR][SidePanel] === Buscando API Key (Drive es la fuente de verdad) ===');
    const sync = await sincronizarGeminiApiKeyDesdeDrive();
    if (sync.ok) {
        return GEMINI_API_KEY;
    }

    if (sync.reason === 'drive_invalid_format') {
        console.error('[ResumenORCAR][SidePanel] Corrige gemini_api_key en ResumenORCAR-config.json (Drive):', sync.hint);
        return null;
    }

    const keyStorage = await obtenerApiKeyDesdeStorage();
    if (isValidApiKey(keyStorage)) {
        GEMINI_API_KEY = String(keyStorage).trim();
        console.warn('[ResumenORCAR][SidePanel] API Key desde Storage (Drive sin key válida)');
        return GEMINI_API_KEY;
    }

    console.error('[ResumenORCAR][SidePanel] ❌ API Key no encontrada en Drive ni Storage');
    return null;
}

// ========================================
// UTILIDADES
// ========================================

function safeChromeRuntimeSendMessage(message, maxRetries = 3) {
    return new Promise((resolve, reject) => {
        let attempt = 0;
        function send() {
            attempt++;
            try {
                if (!chrome.runtime?.id) {
                    throw new Error("Contexto de extensión invalido");
                }
                chrome.runtime.sendMessage(message, (response) => {
                    const lastError = chrome.runtime.lastError;
                    if (lastError) {
                        if (lastError.message.includes("Receiving end does not exist") && attempt < maxRetries) {
                            setTimeout(send, 250 * attempt);
                        } else {
                            reject(new Error(lastError.message));
                        }
                    } else {
                        resolve(response);
                    }
                });
            } catch (error) {
                if (attempt < maxRetries) setTimeout(send, 250 * attempt);
                else reject(error);
            }
        }
        send();
    });
}

// ========================================
// GEMINI API - STREAMING
// ========================================

/**
 * Convierte el historial de conversación al formato multi-turn de Gemini API
 * @param {Array} history - Array de conversationHistory
 * @param {Array} newParts - Parts del nuevo mensaje del usuario
 * @returns {Array} - Array de contents para Gemini API
 */
function buildGeminiContents(history, newParts) {
    const contents = [];
    
    for (const msg of history) {
        const text = msg.content || msg.text;
        if (!text) continue;
        
        if (msg.role === 'user') {
            contents.push({
                role: 'user',
                parts: [{ text: text }]
            });
        } else if (msg.role === 'model') {
            contents.push({
                role: 'model',
                parts: [{ text: text }]
            });
        }
    }
    
    contents.push({
        role: 'user',
        parts: newParts
    });
    
    return contents;
}

function geminiModelCandidates() {
    const seen = new Set();
    return [MODEL_VERSION, ...MODEL_FALLBACKS]
        .map((m) => String(m || '').trim())
        .filter((m) => {
            if (!m || seen.has(m)) return false;
            seen.add(m);
            return true;
        });
}

function esModeloGeminiNoDisponible(errorText) {
    const t = String(errorText || '').toLowerCase();
    return t.includes('no longer available') || t.includes('not found') || t.includes('not_found');
}

function debeProbarModeloGeminiFallback(status, errorText) {
    const t = String(errorText || '').toLowerCase();
    if (status === 404 && esModeloGeminiNoDisponible(errorText)) return true;
    if (status === 429 && (t.includes('free_tier') || t.includes('quota') || t.includes('rate limit') || t.includes('resource_exhausted'))) {
        return true;
    }
    if (status === 403 && !esErrorApiKeyInvalida(status, errorText)) return true;
    return false;
}

function esErrorApiKeyInvalida(status, errorText) {
    const t = String(errorText || '').toLowerCase();
    return (status === 400 || status === 401 || status === 403)
        && (t.includes('api_key_invalid') || t.includes('api key not valid') || t.includes('invalid api key'));
}

function formatearErrorGemini(error) {
    const msg = String(error?.message || error || '');
    const statusMatch = msg.match(/Error API \((\d+)\)/);
    const status = statusMatch ? Number(statusMatch[1]) : 0;

    let userMessage = "❌ **Error de conexión con la IA**\n\n";

    if (msg.includes('503') || msg.includes('overloaded')) {
        userMessage += "🔄 **Servidor saturado** - Por favor, espera unos segundos e intenta de nuevo.";
    } else if (status === 404 || esModeloGeminiNoDisponible(msg)) {
        userMessage += "⚠️ **Modelo no disponible** - No hay ningún modelo Gemini accesible con esta API Key.";
    } else if (esErrorApiKeyInvalida(status, msg)) {
        userMessage += "🔐 **Error de autenticación** - La API Key no es válida o fue revocada.";
    } else if (status === 403) {
        userMessage += "🚫 **Permisos insuficientes** - La API Key es válida pero no tiene acceso a este modelo. Revisa facturación o restricciones del proyecto en Google AI Studio.";
    } else if (status === 429 || msg.includes('quota') || msg.includes('rate limit') || msg.includes('resource_exhausted')) {
        userMessage += "⏳ **Cuota agotada** - Has superado el límite de uso. Espera unos minutos o revisa el plan en Google AI Studio.";
    } else {
        userMessage += `Detalles: ${msg}`;
    }

    return userMessage;
}

async function streamGeminiResponse(response, onChunk) {
    const reader = response.body.getReader();
    const decoder = new TextDecoder("utf-8");
    let buffer = "";
    let fullText = "";
    let lastProcessedIndex = 0;

    while (true) {
        const { done, value } = await reader.read();
        if (done) {
            console.log('[ResumenORCAR][SidePanel] Stream finalizado. Texto total:', fullText.length, 'caracteres');
            break;
        }

        const chunk = decoder.decode(value, { stream: true });
        buffer += chunk;

        let searchStart = lastProcessedIndex;
        let foundText = true;
        let newProcessedIndex = lastProcessedIndex;

        while (foundText) {
            foundText = false;

            const remainingBuffer = buffer.substring(searchStart);
            const textMatch = remainingBuffer.match(/"text"\s*:\s*"((?:[^"\\]|\\.)*)"/);

            if (textMatch) {
                let rawText = textMatch[1];
                try {
                    rawText = JSON.parse('"' + rawText + '"');
                } catch (e) { }

                const matchIndex = searchStart + remainingBuffer.indexOf(textMatch[0]);
                const matchEndIndex = matchIndex + textMatch[0].length;

                if (rawText && rawText.length > 0) {
                    const isNewText = !fullText.endsWith(rawText);

                    if (isNewText) {
                        fullText += rawText;
                        onChunk(rawText);
                        newProcessedIndex = matchEndIndex;
                        foundText = true;
                    }
                }

                searchStart = matchEndIndex;
            }
        }

        lastProcessedIndex = newProcessedIndex;

        if (buffer.length > 5000 && lastProcessedIndex > 1000) {
            buffer = buffer.substring(lastProcessedIndex);
            lastProcessedIndex = 0;
        }
    }

    return fullText;
}

async function callGeminiStream(userPrompt, onChunk, history = null) {
    const apiKey = await obtenerGeminiApiKey();
    if (!apiKey) {
        const errorMsg = "Error: API Key de Gemini no configurada o inválida en Drive (ResumenORCAR-config.json → gemini_api_key).";
        onChunk(errorMsg);
        return errorMsg;
    }

    let parts = [];
    if (typeof userPrompt === 'string') {
        parts = [{ text: userPrompt }];
    } else if (Array.isArray(userPrompt)) {
        parts = userPrompt;
    }

    let contents;
    if (history && history.length > 0) {
        contents = buildGeminiContents(history, parts);
        console.log('[ResumenORCAR][SidePanel] Multi-turn: enviando', contents.length, 'mensajes en la conversación');
    } else {
        contents = [{ role: "user", parts: parts }];
    }

    const requestBody = {
        contents: contents,
        generationConfig: {
            temperature: 0.4,
            topK: 32,
            topP: 0.8,
            maxOutputTokens: 16384,
        }
    };

    const modelos = geminiModelCandidates();
    let lastError = null;

    for (const modelVersion of modelos) {
        const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/${modelVersion}:streamGenerateContent`;
        console.log('[ResumenORCAR][SidePanel] Iniciando llamada streaming a Gemini:', modelVersion);

        try {
            const response = await fetch(API_URL, {
                method: "POST",
                headers: geminiApiHeaders(apiKey, { "Content-Type": "application/json" }),
                body: JSON.stringify(requestBody)
            });

            if (!response.ok) {
                const errText = await response.text();
                console.error('[ResumenORCAR][SidePanel] Error API:', modelVersion, response.status, errText);
                lastError = new Error(`Error API (${response.status}): ${errText}`);
                if (debeProbarModeloGeminiFallback(response.status, errText)) {
                    console.warn('[ResumenORCAR][SidePanel] Probando modelo alternativo tras fallo de', modelVersion);
                    continue;
                }
                break;
            }

            return await streamGeminiResponse(response, onChunk);
        } catch (error) {
            lastError = error;
            const statusMatch = String(error.message || '').match(/Error API \((\d+)\)/);
            const status = statusMatch ? Number(statusMatch[1]) : 0;
            if (debeProbarModeloGeminiFallback(status, error.message)) {
                console.warn('[ResumenORCAR][SidePanel] Probando modelo alternativo tras excepción de', modelVersion);
                continue;
            }
            break;
        }
    }

    console.error('[ResumenORCAR][SidePanel] Error en streaming: ningún modelo disponible');
    const userMessage = formatearErrorGemini(lastError || new Error('Ningún modelo Gemini disponible'));
    onChunk(userMessage);
    return userMessage;
}

// ========================================
// SUBIDA DE ARCHIVOS A GEMINI
// ========================================

function inferirMimeType(file) {
    if (file.type) return file.type;
    const ext = (file.name || '').split('.').pop()?.toLowerCase();
    const mimeTypes = {
        jpg: 'image/jpeg',
        jpeg: 'image/jpeg',
        png: 'image/png',
        gif: 'image/gif',
        webp: 'image/webp',
        pdf: 'application/pdf',
        txt: 'text/plain',
        csv: 'text/csv',
        json: 'application/json'
    };
    return mimeTypes[ext] || 'application/octet-stream';
}

async function subirArchivoAGemini(file) {
    console.log('[ResumenORCAR][SidePanel] Subiendo archivo a Gemini:', file.name, file.type, file.size);
    const apiKey = await obtenerGeminiApiKey();
    if (!apiKey) {
        return { success: false, error: 'API Key de Gemini no configurada o inválida en Drive' };
    }
    
    const mimeType = inferirMimeType(file);
    const uploadUrl = 'https://generativelanguage.googleapis.com/upload/v1beta/files';
    
    const metadata = {
        file: {
            displayName: file.name,
            mimeType
        }
    };
    
    const formData = new FormData();
    // String JSON, no Blob: si va como Blob Gemini lo cuenta como segundo archivo
    formData.append('metadata', JSON.stringify(metadata));
    formData.append('file', file, file.name);
    
    try {
        const response = await fetch(uploadUrl, {
            method: 'POST',
            headers: geminiApiHeaders(apiKey),
            body: formData
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`${response.status} - ${errorText}`);
        }
        
        const result = await response.json();
        console.log('[ResumenORCAR][SidePanel] Archivo subido exitosamente:', result);
        
        return {
            success: true,
            fileUri: result.file.uri,
            mimeType: result.file.mimeType || mimeType,
            displayName: result.file.displayName || file.name
        };
    } catch (error) {
        console.error('[ResumenORCAR][SidePanel] Error subiendo archivo:', error);
        return { success: false, error: error.message };
    }
}

// ========================================
// RENDERIZADO MARKDOWN
// ========================================

let markedConfigured = false;

function preprocesarMarkdown(text) {
    if (!text) return '';
    
    let procesado = text;
    const lineas = procesado.split('\n');
    const resultado = [];
    let enTabla = false;
    
    for (let i = 0; i < lineas.length; i++) {
        const linea = lineas[i].trim();
        const esLineaTabla = linea.startsWith('|') && linea.endsWith('|');
        
        if (esLineaTabla && !enTabla) {
            if (resultado.length > 0 && resultado[resultado.length - 1].trim() !== '') {
                resultado.push('');
            }
            enTabla = true;
        }
        
        if (!esLineaTabla && enTabla) {
            resultado.push('');
            enTabla = false;
        }
        
        resultado.push(lineas[i]);
    }
    
    return resultado.join('\n');
}

function renderStreamingResponse(text) {
    if (!text) return '';
    
    const textoPreprocesado = preprocesarMarkdown(text);
    
    try {
        if (typeof marked !== 'undefined') {
            if (!markedConfigured) {
                marked.use({
                    breaks: false,
                    gfm: true,
                    pedantic: false,
                    sanitize: false,
                    smartLists: true,
                    smartypants: false
                });
                markedConfigured = true;
                console.log('[ResumenORCAR][SidePanel] Marked.js configurado correctamente');
            }
            
            let html = marked.parse(textoPreprocesado);
            
            if (html.includes('**')) {
                let previousHtml = '';
                let iterations = 0;
                while (html !== previousHtml && html.includes('**') && iterations < 5) {
                    previousHtml = html;
                    html = html.replace(/\*\*([^*]+?)\*\*/gs, '<strong>$1</strong>');
                    iterations++;
                }
            }
            
            return html;
        } else {
            console.warn('[ResumenORCAR][SidePanel] marked.js no está disponible, usando fallback');
        }
    } catch (error) {
        console.warn('[ResumenORCAR][SidePanel] Error parseando markdown:', error);
    }
    
    return convertirMarkdownManual(textoPreprocesado);
}

function convertirMarkdownManual(text) {
    if (!text) return '';
    
    let html = text;
    
    html = html.replace(/\*\*\*([^*]+?)\*\*\*/g, '<strong><em>$1</em></strong>');
    
    let previousHtml = '';
    let iterations = 0;
    while (html !== previousHtml && iterations < 10) {
        previousHtml = html;
        html = html.replace(/\*\*([^*]+?)\*\*/gs, '<strong>$1</strong>');
        iterations++;
    }
    
    html = html.replace(/(<li[^>]*>.*?)\*\*([^*]+?)\*\*/gs, '$1<strong>$2</strong>');
    html = html.replace(/(^|\s)\*\*([^*]+?)\*\*/gm, '$1<strong>$2</strong>');
    
    try {
        html = html.replace(/(?<!\*)\*([^*\n]+?)\*(?!\*)/g, '<em>$1</em>');
    } catch (e) {
        html = html.replace(/([^*]|^)\*([^*\n]+?)\*([^*]|$)/g, '$1<em>$2</em>$3');
    }
    
    const tablaRegex = /\|(.+)\|[\r\n]+\|[-:\s|]+\|[\r\n]+((?:\|.+\|[\r\n]*)+)/g;
    html = html.replace(tablaRegex, (match, header, rows) => {
        const headers = header.split('|').filter(h => h.trim()).map(h => `<th>${h.trim()}</th>`).join('');
        const rowsHtml = rows.trim().split('\n').map(row => {
            const cells = row.split('|').filter(c => c.trim()).map(c => `<td>${c.trim()}</td>`).join('');
            return `<tr>${cells}</tr>`;
        }).join('');
        return `<table><thead><tr>${headers}</tr></thead><tbody>${rowsHtml}</tbody></table>`;
    });
    
    html = html.replace(/^####\s*(.*)$/gm, '<h4>$1</h4>');
    html = html.replace(/^###\s*(.*)$/gm, '<h3>$1</h3>');
    html = html.replace(/^##\s*(.*)$/gm, '<h2>$1</h2>');
    html = html.replace(/^#\s*(.*)$/gm, '<h1>$1</h1>');
    
    html = html.replace(/^(?:        |\t\t)[-*]\s+(.*)$/gm, '<li class="level3">$1</li>');
    html = html.replace(/^(?:    |\t)[-*]\s+(.*)$/gm, '<li class="level2">$1</li>');
    html = html.replace(/^[-*]\s+(.*)$/gm, '<li class="level1">$1</li>');
    
    html = html.replace(/(<li class="level1">.*?<\/li>(\s*<li class="level[23]">.*?<\/li>)*)/gs, '<ul>$1</ul>');
    
    html = html.replace(/\n\n/g, '</p><p>');
    html = html.replace(/\n/g, '<br>');
    
    return html;
}

// ========================================
// INTERFAZ DE CHAT
// ========================================

function addMessage(container, text, type) {
    const div = document.createElement('div');
    div.className = `message ${type}`;
    
    if (type === 'system' || type === 'error') {
        div.innerHTML = `<span style="color:${type === 'error' ? '#c00' : '#666'};font-style:italic;font-size:0.9em;">${text}</span>`;
    } else {
        div.innerHTML = `<div class="bubble">${text}</div>`;
    }
    
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
}

function mostrarArchivoAdjunto(file) {
    const preview = document.getElementById('attachment-preview-resumen');
    const btnAttach = document.getElementById('btn-attach-resumen');
    if (btnAttach) btnAttach.classList.add('has-files');
    if (preview) {
        preview.style.display = 'flex';
        preview.innerHTML = `
            <span>📎 ${file.name} (${(file.size / 1024).toFixed(1)} KB)</span>
            <button id="remove-attachment-resumen" style="margin-left:10px;background:none;border:none;cursor:pointer;color:#d32f2f;font-weight:bold;">✕</button>
        `;
        
        document.getElementById('remove-attachment-resumen').onclick = () => {
            archivoAdjuntoActual = null;
            preview.style.display = 'none';
            if (btnAttach) btnAttach.classList.remove('has-files');
            const fileInput = document.getElementById('file-input-resumen');
            if (fileInput) fileInput.value = '';
        };
    }
}

async function handleSend(inputText, messagesArea) {
    const userText = inputText.value.trim();
    if (!userText && !archivoAdjuntoActual) return;
    
    inputText.value = '';
    
    let mensajeUsuario = userText || '(Archivo adjunto)';
    if (archivoAdjuntoActual) {
        mensajeUsuario += `<br><br><div style="font-size:0.9em;color:#1976d2;background:#e3f2fd;padding:5px;border-radius:4px;display:inline-block;">📎 ${archivoAdjuntoActual.file.name}</div>`;
    }
    addMessage(messagesArea, mensajeUsuario, 'user');
    
    let geminiContent = [];
    
    if (archivoAdjuntoActual && archivoAdjuntoActual.file) {
        addMessage(messagesArea, "Subiendo archivo...", 'system');
        
        const uploadResult = await subirArchivoAGemini(archivoAdjuntoActual.file);
        
        if (uploadResult.success) {
            geminiContent.push({
                fileData: {
                    fileUri: uploadResult.fileUri,
                    mimeType: uploadResult.mimeType
                }
            });
            archivoAdjuntoActual.geminiData = uploadResult;
        } else {
            addMessage(messagesArea, `Error subiendo archivo: ${uploadResult.error}`, 'error');
            inputText.focus();
            return;
        }

        const preview = document.getElementById('attachment-preview-resumen');
        const btnAttach = document.getElementById('btn-attach-resumen');
        if (preview) preview.style.display = 'none';
        if (btnAttach) btnAttach.classList.remove('has-files');
        archivoAdjuntoActual = null;
    }
    
    let prompt;
    if (conversationHistory.length === 0) {
        prompt = window.construirPromptSeguimiento(datosORActual, userText);
    } else {
        prompt = userText;
    }
    
    geminiContent.push({ text: prompt });
    
    // Guardar el mensaje del usuario en el historial ANTES de llamar a Gemini
    conversationHistory.push({ role: 'user', content: prompt, attachment: archivoAdjuntoActual?.file?.name });
    
    const aiMsgDiv = document.createElement('div');
    aiMsgDiv.className = 'message ai';
    aiMsgDiv.innerHTML = `<div class="bubble">Pensando...</div>`;
    messagesArea.appendChild(aiMsgDiv);
    const bubble = aiMsgDiv.querySelector('.bubble');
    
    // Pasar el historial previo (sin el último mensaje user que ya va en geminiContent)
    const historyForGemini = conversationHistory.slice(0, -1);
    
    let accumulatedText = "";
    await callGeminiStream(geminiContent, (chunk) => {
        accumulatedText += chunk;
        bubble.innerHTML = renderStreamingResponse(accumulatedText);
        messagesArea.scrollTop = messagesArea.scrollHeight;
    }, historyForGemini);
    
    conversationHistory.push({ role: 'model', content: accumulatedText });
    
    guardarChatEnDrive();
}

// ========================================
// GUARDAR CHAT EN DRIVE
// ========================================

async function guardarChatEnDrive() {
    if (!datosORActual || conversationHistory.length === 0) return;
    
    try {
        const fechaChat = new Date().toISOString().split('T')[0];
        const filenameChat = `ResumenOR-${datosORActual.orNumber}-chat-${fechaChat}.json`;
        
        const chatContent = {
            or: datosORActual.orNumber,
            fecha: fechaChat,
            estadoOr: datosORActual.estado || null,
            conversacion: conversationHistory,
            datosOR: datosORActual,
            totalMensajes: conversationHistory.length
        };
        
        console.log('[ResumenORCAR][SidePanel] Guardando chat en Drive:', filenameChat);
        await safeChromeRuntimeSendMessage({
            action: 'saveToDrive',
            data: { filename: filenameChat, content: JSON.stringify(chatContent), type: 'json', ext: 'json' }
        });
        console.log('[ResumenORCAR][SidePanel] Chat guardado exitosamente');
    } catch (err) {
        console.error('[ResumenORCAR][SidePanel] Error guardando chat:', err);
    }
}

// ========================================
// INICIALIZACIÓN DEL CHAT
// ========================================

function esEstadoVehiculoEntregado(estado) {
    if (!estado || typeof estado !== 'string') return false;
    const normalizado = estado.trim().toLowerCase();
    return normalizado.includes('vehículo entregado') || normalizado.includes('vehiculo entregado');
}

/** ¿Preguntar si regenerar? Si al guardar (o ahora, en chats antiguos) no estaba entregada. */
function debePreguntarRegenerarResumen(chatData, datosOR) {
    const estadoGuardado = (chatData?.estadoOr || chatData?.datosOR?.estado || '').trim();
    if (estadoGuardado) {
        return !esEstadoVehiculoEntregado(estadoGuardado);
    }
    const estadoActual = (datosOR?.estado || '').trim();
    return !esEstadoVehiculoEntregado(estadoActual);
}

function renderizarMensajesChat(conversacionArray, messagesArea) {
    conversacionArray.forEach(msg => {
        const role = msg.role;
        const text = msg.content || msg.text;

        if (role === 'user') {
            if (msg.isSystemPrompt) {
                const displayText = msg.displayText || '📋 Análisis inicial de la OR';
                addMessage(messagesArea, displayText, 'user');
            } else {
                let mensajeHtml = text;
                if (msg.attachment) {
                    mensajeHtml += `<br><br><div style="font-size:0.9em;color:#1976d2;background:#e3f2fd;padding:5px;border-radius:4px;display:inline-block;">📎 ${msg.attachment}</div>`;
                }
                addMessage(messagesArea, mensajeHtml, 'user');
            }
        } else if (role === 'model') {
            const aiDiv = document.createElement('div');
            aiDiv.className = 'message ai';
            aiDiv.innerHTML = `<div class="bubble">${renderStreamingResponse(text)}</div>`;
            messagesArea.appendChild(aiDiv);
        }
    });
    messagesArea.scrollTop = messagesArea.scrollHeight;
}

function restaurarChatPrevio(conversacionArray, messagesArea, inputText) {
    conversationHistory = conversacionArray;
    renderizarMensajesChat(conversacionArray, messagesArea);
    addMessage(messagesArea, 'Chat previo restaurado. Puedes continuar la conversación.', 'system');
    inputText.focus();
}

function mostrarPromptResumenIncompleto(messagesArea, chatData, fechaFormateada, conversacionArray, inputText) {
    const estadoRef = (chatData?.estadoOr || chatData?.datosOR?.estado || datosORActual?.estado || 'desconocido').trim();
    const estadoActual = (datosORActual?.estado || '').trim();
    let detalleEstado = `«${estadoRef}»`;
    if (estadoActual && estadoActual !== estadoRef) {
        detalleEstado += ` (ahora: «${estadoActual}»)`;
    }

    const promptDiv = document.createElement('div');
    promptDiv.className = 'message system resumen-previo-prompt-wrap';
    promptDiv.innerHTML = `
        <div class="resumen-previo-prompt">
            <p>Se encontró un resumen del <strong>${fechaFormateada}</strong>. En ese momento la OR estaba en estado ${detalleEstado} y <strong>no estaba entregada</strong>, por lo que el resumen puede estar incompleto.</p>
            <p>¿Qué deseas hacer?</p>
            <div class="resumen-previo-actions">
                <button type="button" class="btn-usar-previo">Usar resumen anterior</button>
                <button type="button" class="btn-nuevo-resumen">Generar nuevo resumen</button>
            </div>
        </div>
    `;
    messagesArea.appendChild(promptDiv);
    messagesArea.scrollTop = messagesArea.scrollHeight;

    promptDiv.querySelector('.btn-usar-previo').onclick = () => {
        promptDiv.remove();
        addMessage(messagesArea, 'Cargando resumen anterior...', 'system');
        restaurarChatPrevio(conversacionArray, messagesArea, inputText);
    };

    promptDiv.querySelector('.btn-nuevo-resumen').onclick = () => {
        promptDiv.remove();
        addMessage(messagesArea, 'Generando nuevo resumen con los datos actuales de la OR...', 'system');
        iniciarAnalisisNuevo(messagesArea, inputText);
    };

    inputText.focus();
}

async function iniciarAnalisisNuevo(messagesArea, inputText) {
    const promptInicial = window.construirMensajeInicial(datosORActual);

    const aiMsgDiv = document.createElement('div');
    aiMsgDiv.className = 'message ai';
    aiMsgDiv.innerHTML = `<div class="bubble">Analizando la OR...</div>`;
    messagesArea.appendChild(aiMsgDiv);
    const bubble = aiMsgDiv.querySelector('.bubble');

    let accumulatedText = '';
    await callGeminiStream(promptInicial, (chunk) => {
        accumulatedText += chunk;
        bubble.innerHTML = renderStreamingResponse(accumulatedText);
        messagesArea.scrollTop = messagesArea.scrollHeight;
    });

    conversationHistory.push({
        role: 'user',
        content: promptInicial,
        isSystemPrompt: true,
        displayText: '📋 Análisis inicial de la OR'
    });
    conversationHistory.push({ role: 'model', content: accumulatedText });

    guardarChatEnDrive();
    inputText.focus();
}

async function inicializarChat(datosOR) {
    console.log('[ResumenORCAR][SidePanel] Inicializando chat para OR:', datosOR.orNumber);
    await sincronizarGeminiApiKeyDesdeDrive();
    
    if (datosORActual && conversationHistory.length > 0) {
        await guardarChatEnDrive();
    }
    
    conversationHistory = [];
    datosORActual = datosOR;
    archivoAdjuntoActual = null;
    
    document.getElementById('chat-title').textContent = `Resumen OR - ${datosOR.orNumber}`;
    document.getElementById('loading-indicator').style.display = 'none';
    
    const chatContainer = document.getElementById('chat-container');
    chatContainer.style.display = 'flex';
    
    const messagesArea = document.getElementById('messages-area');
    messagesArea.innerHTML = '';
    
    const inputText = document.getElementById('input-text-resumen');
    
    // --- BUSCAR CHAT PREVIO ---
    addMessage(messagesArea, "Buscando conversaciones previas...", 'system');
    
    try {
        const chatPrefix = `ResumenOR-${datosOR.orNumber}-chat-`;
        const listChatResult = await safeChromeRuntimeSendMessage({ action: 'listDriveFiles', data: { prefix: chatPrefix, limit: 10 } });
        
        if (listChatResult?.success && listChatResult?.data?.files?.length > 0) {
            const chatFiles = listChatResult.data.files;
            chatFiles.sort((a, b) => new Date(b.updated || 0) - new Date(a.updated || 0));
            
            const latestChatFile = chatFiles[0];
            console.log('[ResumenORCAR][SidePanel] Chat previo encontrado:', latestChatFile.name);
            
            const readChatResult = await safeChromeRuntimeSendMessage({ action: 'readFromDrive', data: { name: latestChatFile.name } });
            
            if (readChatResult?.success && readChatResult?.data?.content) {
                try {
                    let chatData = readChatResult.data.content;
                    if (typeof chatData === 'string') {
                        chatData = JSON.parse(chatData);
                    }
                    if (typeof chatData === 'string') {
                        chatData = JSON.parse(chatData);
                    }
                    
                    const fechaMatch = latestChatFile.name.match(/(\d{4})-(\d{2})-(\d{2})/);
                    const fechaFormateada = fechaMatch ? `${fechaMatch[3]}/${fechaMatch[2]}/${fechaMatch[1]}` : latestChatFile.name;
                    
                    const conversacionArray = chatData?.conversacion;
                    
                    if (conversacionArray && Array.isArray(conversacionArray)) {
                        if (debePreguntarRegenerarResumen(chatData, datosOR)) {
                            addMessage(messagesArea, `Chat previo encontrado (${fechaFormateada}).`, 'system');
                            mostrarPromptResumenIncompleto(messagesArea, chatData, fechaFormateada, conversacionArray, inputText);
                            return;
                        }

                        addMessage(messagesArea, `Chat previo encontrado (${fechaFormateada}). Cargando...`, 'system');
                        restaurarChatPrevio(conversacionArray, messagesArea, inputText);
                        return;
                    }
                } catch (parseErr) {
                    console.error('[ResumenORCAR][SidePanel] Error parseando chat:', parseErr);
                }
            }
        }
    } catch (e) {
        console.warn('[ResumenORCAR][SidePanel] Error buscando chat previo:', e);
    }
    
    // Si no hay chat previo, iniciar análisis con IA
    addMessage(messagesArea, "No hay chat previo. Iniciando análisis con IA...", 'system');
    await iniciarAnalisisNuevo(messagesArea, inputText);
}

// ========================================
// EVENT LISTENERS & INICIALIZACIÓN
// ========================================

document.addEventListener('DOMContentLoaded', () => {
    GEMINI_API_KEY = null;
    sincronizarGeminiApiKeyDesdeDrive().catch((e) => {
        console.warn('[ResumenORCAR][SidePanel] No se pudo sincronizar API key al abrir:', e);
    });

    const versionEl = document.getElementById('extension-version');
    if (versionEl && EXT_VERSION) {
        versionEl.textContent = `v${EXT_VERSION}`;
    }

    const fileInput = document.getElementById('file-input-resumen');
    const btnAttach = document.getElementById('btn-attach-resumen');
    const inputText = document.getElementById('input-text-resumen');
    const btnSend = document.getElementById('btn-send-resumen');
    const messagesArea = document.getElementById('messages-area');
    
    btnAttach.onclick = () => fileInput.click();
    
    fileInput.onchange = (e) => {
        const file = e.target.files[0];
        if (file) {
            if (file.size > 20 * 1024 * 1024) {
                alert('El archivo es demasiado grande (máx 20MB)');
                fileInput.value = '';
                return;
            }
            archivoAdjuntoActual = { file: file };
            mostrarArchivoAdjunto(file);
        }
    };
    
    btnSend.onclick = () => handleSend(inputText, messagesArea);
    inputText.onkeypress = (e) => { if (e.key === 'Enter') handleSend(inputText, messagesArea); };
    
    // Intentar obtener datos del background (pueden no estar listos aún)
    // Los datos llegarán vía mensaje 'sidePanelDataReady' cuando estén listos
    safeChromeRuntimeSendMessage({ action: 'getSidePanelData' })
        .then((response) => {
            if (response?.success && response.data) {
                console.log('[ResumenORCAR][SidePanel] Datos obtenidos en carga inicial');
                inicializarChat(response.data);
            } else {
                console.log('[ResumenORCAR][SidePanel] Datos aún no disponibles, esperando mensaje...');
            }
        })
        .catch((e) => {
            console.log('[ResumenORCAR][SidePanel] Esperando datos...', e);
        });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'sidePanelDataReady' && request.datosOR) {
        inicializarChat(request.datosOR);
        sendResponse({ success: true });
        return true;
    }
});

window.addEventListener('beforeunload', () => {
    guardarChatEnDrive();
});
