/***************************************
 * ChatGPT → Google Drive Webhook (GAS)
 * Guarda y lee prediagnósticos en Drive
 * Versión: Optimizada (Soporte TOML y Limpieza)
 * Basado en fuente: appscript.gs
 ***************************************/

// ======================
// CONFIGURACIÓN
// ======================
// Carpeta IACAR: https://drive.google.com/drive/folders/1ZGZr-EvgkRxi7ji8LQqh2ADYedYQcPAn
const FOLDER_ID = '1ZGZr-EvgkRxi7ji8LQqh2ADYedYQcPAn'; 
const DEFAULT_PREFIX = 'prediagnostico'; // [cite: 2]

// ======================
// HELPERS DE CONFIG
// ======================
function getProp_(k, fallback) {
  try {
    const v = PropertiesService.getScriptProperties().getProperty(k); // [cite: 3]
    if (v && String(v).trim() !== '') return String(v).trim(); // [cite: 3]
  } catch (_) {}
  return fallback || ''; // [cite: 4]
}

function getFolderId_(p) {
  if (p && p.folderId && String(p.folderId).trim()) {
    return String(p.folderId).trim(); // [cite: 5]
  }
  const prop = getProp_('FOLDER_ID', ''); // [cite: 5]
  if (prop) return prop; // [cite: 5]
  return FOLDER_ID; // [cite: 6]
}

// ======================
// UTILIDADES
// ======================
function nowStamp_() {
  const tz = Session.getScriptTimeZone() || 'Europe/Madrid'; // [cite: 7]
  const d = new Date(Utilities.formatDate(new Date(), tz, "yyyy-MM-dd'T'HH:mm:ss")); // [cite: 7]
  const y = d.getFullYear(); // [cite: 7]
  const m = ('0' + (d.getMonth() + 1)).slice(-2); // [cite: 8]
  const day = ('0' + d.getDate()).slice(-2); // [cite: 8]
  const hh = ('0' + d.getHours()).slice(-2); // [cite: 8]
  const mm = ('0' + d.getMinutes()).slice(-2); // [cite: 9]
  const ss = ('0' + d.getSeconds()).slice(-2); // [cite: 9]
  return `${y}${m}${day}-${hh}${mm}${ss}`; // [cite: 9]
}

function asJson_(obj){ return JSON.stringify(obj, null, 2); } // [cite: 10]

function getFolder_(p) {
  const id = getFolderId_(p); // [cite: 11]
  if (!id) throw new Error('FOLDER_ID no configurado.'); // [cite: 11]
  const folder = DriveApp.getFolderById(id);
  // Asegurar que el script corre como el propietario de la carpeta (despliegue "Ejecutar como: Yo")
  try {
    const ownerEmail = folder.getOwner().getEmail();
    const runAsEmail = Session.getEffectiveUser().getEmail();
    if (ownerEmail !== runAsEmail) {
      throw new Error(
        'La aplicación debe desplegarse con "Ejecutar como: Yo" (no "usuario que accede"). ' +
        'Usuario actual: ' + runAsEmail + ', Propietario carpeta: ' + ownerEmail + '. ' +
        'En Implementar → Gestionar implementaciones, edita y elige "Yo".'
      );
    }
  } catch (e) {
    if (e.message && e.message.indexOf('La aplicación debe desplegarse') === 0) throw e;
    // Si getOwner falla (ej. carpeta compartida), no bloquear
  }
  return folder;
}

function respond_(payload, e){
  const cb = e && e.parameter && e.parameter.callback; // [cite: 12]
  const text = cb ? `${cb}(${asJson_(payload)});` : asJson_(payload); // [cite: 12]
  const out = ContentService.createTextOutput(text); // [cite: 12]
  out.setMimeType(cb ? ContentService.MimeType.JAVASCRIPT : ContentService.MimeType.JSON); // [cite: 12]
  return out; // [cite: 13]
}

function readParams_(e){
  let body = {};
  try{
    if (e && e.postData && typeof e.postData.contents === 'string'){
      const raw = e.postData.contents; // [cite: 14]
      try { body = JSON.parse(raw || '{}'); } // [cite: 14]
      catch (_){
        body = e.parameter || {}; // [cite: 15]
        if (!body || Object.keys(body).length === 0) body = { content: raw }; // [cite: 15]
        if (body.json){ try{ body = JSON.parse(body.json); } catch(_){ } } // [cite: 16]
      }
    } else {
      body = e && e.parameter ? e.parameter : {}; // [cite: 17]
      if (body && body.json){ try{ body = JSON.parse(body.json); } catch(_){ } } // [cite: 18]
    }
    const params = (e && e.parameter) ? e.parameter : {}; // [cite: 19]
    if (params && typeof params === 'object'){
      Object.keys(params).forEach((k) => { if (body[k] === undefined) body[k] = params[k]; }); // [cite: 20]
    }
    if (body && body.filename && !body.name) body.name = body.filename; // [cite: 21]
  } catch (err){
    const error = new Error('No se pudo parsear el cuerpo de la petición.'); // [cite: 22]
    error.cause = err; // [cite: 22]
    throw error;
  }
  return body || {}; // [cite: 23]
}

function buildFilename_({ name, prefix, ext }) {
  if (name && String(name).trim()) {
    const base = String(name).trim(); // [cite: 24]
    if (base.includes('.')) return base; // [cite: 24]
    if (ext) return `${base}.${String(ext).replace(/^\./, '')}`; // [cite: 24]
    return base;
  }
  const base = `${(prefix || DEFAULT_PREFIX)}-${nowStamp_()}`; // [cite: 25]
  if (ext) {
    const cleanExt = String(ext).replace(/^\./, ''); // [cite: 26]
    if (!base.toLowerCase().endsWith('.' + cleanExt.toLowerCase())) {
      return `${base}.${cleanExt}`; // [cite: 26]
    }
  }
  return base; // [cite: 27]
}

function createOrUpdateFileInFolder_(blob, filename, type, p){
  blob.setName(filename); // [cite: 28]
  const folder = getFolder_(p); // [cite: 28]
  
  // Limpieza: si ya existe, se elimina para asegurar que el nuevo contenido se escriba bien
  const it = folder.getFilesByName(filename);
  while (it.hasNext()) {
    try { it.next().setTrashed(true); } catch(_){ }
  }
  
  return folder.createFile(blob); // [cite: 41]
}

function makeBlob_({ type, content, mimeType, base64 }){
  if (base64 === true || base64 === 'true'){
    const bytes = Utilities.base64Decode(String(content || '')); // [cite: 42]
    const mt = mimeType || 'application/octet-stream'; // [cite: 42]
    return Utilities.newBlob(bytes, mt); // [cite: 42]
  }
  switch ((type || '').toLowerCase()){
    case 'json': return Utilities.newBlob(asJson_(content), 'application/json'); // [cite: 43]
    case 'html': return Utilities.newBlob(String(content || ''), 'text/html'); // [cite: 43]
    case 'markdown':
    case 'md':   return Utilities.newBlob(String(content || ''), 'text/markdown'); // [cite: 44]
    case 'toml': // Soporte explícito para TOML 
    case 'text':
    case 'txt':
    case '':     return Utilities.newBlob(String(content || ''), 'text/plain'); // 
    default:     return Utilities.newBlob(String(content || ''), mimeType || 'text/plain'); // [cite: 46]
  }
}

function makePdfFromHtml_(htmlString){
  const html = HtmlService.createHtmlOutput(String(htmlString || '')); // [cite: 47]
  return html.getBlob().getAs('application/pdf'); // [cite: 47]
}

function startsWithCI_(str, pref) {
  if (!pref) return true; // [cite: 47]
  return String(str).toLowerCase().startsWith(String(pref).toLowerCase()); // [cite: 47]
}

// ======================
// LÓGICA: SAVE / READ / DELETE
// ======================
function handleSave_(p){
  const t    = (p.type || 'text').toLowerCase(); // [cite: 48]
  const desc = p.description ? String(p.description) : ''; // [cite: 48]
  let ext = p.ext; // [cite: 49]
  if (!ext){
    if (t === 'json') ext = 'json'; // [cite: 50]
    else if (t === 'html') ext = 'html'; // [cite: 50]
    else if (t === 'toml') ext = 'toml';
    else if (t === 'markdown' || t === 'md') ext = 'md'; // [cite: 51]
    else if (t === 'pdf') ext = 'pdf'; // [cite: 51]
    else ext = 'txt'; // [cite: 51]
  }
  
  let blob;
  if (t === 'pdf'){ blob = makePdfFromHtml_(p.content || ''); } // [cite: 52]
  else { blob = makeBlob_({ type: t, content: p.content, mimeType: p.mimeType, base64: p.base64 }); } // [cite: 53]

  const providedName = String((p.name || p.filename || '')).trim(); // [cite: 54]
  const filename = providedName
    ? (providedName.toLowerCase().includes('.') ? providedName : `${providedName}.${ext}`) // [cite: 55]
    : buildFilename_({ name: '', prefix: p.prefix, ext }); // [cite: 55]

  // Sustitución explícita: eliminar iguales y crear nuevo [cite: 56]
  try {
    const folder = getFolder_(p);
    const it = folder.getFilesByName(filename);
    while (it.hasNext()) { try { it.next().setTrashed(true); } catch(_){ } } // [cite: 57]
  } catch(_){ }
  
  const file = createOrUpdateFileInFolder_(blob, filename, t, p); // [cite: 58]
  if (desc) file.setDescription(desc); // [cite: 58]

  return {
    ok: true, fileId: file.getId(), name: file.getName(), url: file.getUrl(),
    mimeType: file.getMimeType(), size: file.getSize(), createdUtc: new Date().toISOString(),
    folderId: getFolderId_(p)
  }; // [cite: 59]
}

function handleRead_(p){
  const id   = (p.id || p.fileId || '').toString().trim(); // [cite: 63]
  const name = (p.name || '').toString().trim(); // [cite: 63]
  const match = (p.match || 'exact').toLowerCase(); // [cite: 64]
  const as   = (p.as || 'text').toLowerCase(); // [cite: 65]
  const charset = p.charset || 'UTF-8'; // [cite: 65]

  if (!id && !name) {
    const err = new Error('Falta el parámetro "id" o "name".'); // [cite: 66]
    err.status = 400; throw err;
  }

  let file;
  try {
    if (id) {
      file = DriveApp.getFileById(id); // [cite: 67]
    } else {
      const folder = getFolder_(p);
      let it;
      if (match === 'exact') {
        it = folder.getFilesByName(name); // [cite: 69]
        if (it.hasNext()) file = it.next();
      }
      if (!file) {
        const files = folder.getFiles(); // [cite: 70]
        while (files.hasNext()) {
          const f = files.next();
          const n = f.getName();
          if ((match === 'prefix' && n.startsWith(name)) ||
              (match === 'contains' && n.indexOf(name) !== -1) ||
              (match !== 'exact' && n === name)) {
            file = f; break; // [cite: 72]
          }
        }
      }
      if (!file) throw new Error(`No se encontró archivo con name="${name}"`); // [cite: 73]
    }
  } catch (e) {
    const err = new Error(e.message); // [cite: 74]
    err.status = 404; throw err;
  }

  const mimeType = file.getMimeType();
  if (mimeType === 'application/vnd.google-apps.spreadsheet' || mimeType === MimeType.GOOGLE_SHEETS) {
    try {
      const values = SpreadsheetApp.open(file).getSheets()[0].getDataRange().getValues(); // [cite: 77]
      let csvContent = values.map(row => row.map(cell => {
        const cellValue = cell === null || cell === undefined ? '' : String(cell);
        return (cellValue.includes(',') || cellValue.includes('"') || cellValue.includes('\n'))
          ? '"' + cellValue.replace(/"/g, '""') + '"' : cellValue;
      }).join(',')).join('\n'); // [cite: 81, 88]

      if (as === 'base64') {
        return { ok: true, id: file.getId(), name: file.getName(), mimeType, size: file.getSize(), url: file.getUrl(), updated: file.getLastUpdated(), base64: Utilities.base64Encode(Utilities.newBlob(csvContent).getBytes()), data: values }; // [cite: 83]
      }
      return { ok: true, id: file.getId(), name: file.getName(), mimeType, size: file.getSize(), url: file.getUrl(), updated: file.getLastUpdated(), content: csvContent, data: values }; // [cite: 89]
    } catch (e) { console.log('[GAS] Error leyendo Sheet: ' + e.message); }
  }

  const blob = file.getBlob(); // [cite: 92]
  let content, b64;
  if (as === 'base64') { b64 = Utilities.base64Encode(blob.getBytes()); } // [cite: 93]
  else { try { content = blob.getDataAsString(charset); } catch (_){ content = blob.getDataAsString('UTF-8'); } } // [cite: 94]

  return { ok: true, id: file.getId(), name: file.getName(), mimeType, size: file.getSize(), url: file.getUrl(), updated: file.getLastUpdated(), content: as === 'base64' ? undefined : content, base64: as === 'base64' ? b64 : undefined, folderId: getFolderId_(p) }; // [cite: 97]
}

function handleDelete_(p){
  const id   = (p.id || p.fileId || '').toString().trim(); // [cite: 98]
  const name = (p.name || '').toString().trim(); // [cite: 98]
  const match = (p.match || 'exact').toLowerCase(); // [cite: 99]
  const result = { ok: true, deleted: 0, items: [] }; // [cite: 100]

  function trashOrRemove_(file){
    try {
      file.setTrashed(true); // [cite: 102]
      result.deleted++;
      result.items.push({ id: file.getId(), name: file.getName() }); // [cite: 103]
    } catch (e) { if (!result.errors) result.errors = []; result.errors.push({ id: file.getId(), name: file.getName(), error: e.message }); }
  }

  if (id) {
    try { trashOrRemove_(DriveApp.getFileById(id)); return result; }
    catch (e) { const err = new Error('No encontrado: ' + id); err.status = 404; throw err; } // [cite: 106]
  }

  if (!name) { throw new Error('Falta id o name'); } // [cite: 107]
  const folder = getFolder_(p);
  if (match === 'exact') {
    const it = folder.getFilesByName(name);
    while (it.hasNext()) { trashOrRemove_(it.next()); } // [cite: 109]
    return result;
  }
  const files = folder.getFiles();
  while (files.hasNext()) {
    const f = files.next();
    if ((match === 'prefix' && f.getName().startsWith(name)) || (match === 'contains' && f.getName().indexOf(name) !== -1)) { trashOrRemove_(f); } // [cite: 112]
  }
  return result;
}

function normalizeSheetRows_(content) {
  let rows = content;
  if (typeof rows === 'string') {
    try {
      rows = JSON.parse(rows);
    } catch (e) {
      throw new Error('content JSON invalido');
    }
  }
  if (!Array.isArray(rows) || rows.length === 0) {
    return [];
  }
  if (!Array.isArray(rows[0])) {
    rows = [rows];
  }
  return rows.map(function(row) {
    if (!Array.isArray(row)) {
      return [String(row == null ? '' : row)];
    }
    return row.map(function(cell) {
      return cell == null ? '' : String(cell);
    });
  });
}

function openFichajeSheet_(p) {
  const fileId = (p.id || p.fileId || '').toString().trim();
  let file;
  if (fileId) {
    file = DriveApp.getFileById(fileId);
  } else {
    const filename = (p.name || p.filename || '').toString().trim();
    if (!filename) throw new Error('Falta nombre archivo o fileId');
    const folder = getFolder_(p);
    const files = folder.getFilesByName(filename);
    if (!files.hasNext()) throw new Error('No encontrado: ' + filename);
    file = files.next();
  }
  if (file.getMimeType() !== MimeType.GOOGLE_SHEETS) throw new Error('No es Sheet');
  return { file: file, sheet: SpreadsheetApp.open(file).getSheets()[0] };
}

function handleAppendRows_(p) {
  const opened = openFichajeSheet_(p);
  const rows = normalizeSheetRows_(p.content);
  if (rows.length === 0) {
    return { ok: true, message: 'Sin filas', count: 0, filename: opened.file.getName(), fileId: opened.file.getId(), folderId: getFolderId_(p) };
  }
  rows.forEach(function(row) {
    opened.sheet.appendRow(row);
  });
  return { ok: true, message: 'Filas anadidas', count: rows.length, filename: opened.file.getName(), fileId: opened.file.getId(), folderId: getFolderId_(p) };
}

function handleAppendRow_(p) {
  const opened = openFichajeSheet_(p);
  const rows = normalizeSheetRows_(p.content);
  if (rows.length === 0) throw new Error('Fila vacia');
  opened.sheet.appendRow(rows[0]);
  return { ok: true, message: 'Fila anadida', filename: opened.file.getName(), fileId: opened.file.getId(), folderId: getFolderId_(p) };
}

// ======================
// ENDPOINTS
// ======================
function doPost(e){
  try{
    const p = readParams_(e); // [cite: 128]
    const action = (p.action || 'save').toLowerCase(); // [cite: 129]
    if (action === 'save' || action === 'create') return respond_(handleSave_(p), e); // [cite: 129]
    if (action === 'read') return respond_(handleRead_(p), e); // [cite: 130]
    if (action === 'delete') return respond_(handleDelete_(p), e); // [cite: 130]
    if (action === 'appendrow') return respond_(handleAppendRow_(p), e); // [cite: 131]
    if (action === 'appendrows') return respond_(handleAppendRows_(p), e);
    if (action === 'ping') return respond_({ ok:true, pong:true, time:new Date().toISOString() }, e); // [cite: 131]
    if (action === 'list'){
      const limit = Math.min(Number(p.limit || 20), 100);
      const prefix = (p.prefix || '').toString().trim();
      const folder = getFolder_(p);
      const files = folder.getFiles();
      const arr = [];
      let n=0;
      while (files.hasNext()){
        const f = files.next();
        if (!prefix || f.getName().startsWith(prefix)) {
          arr.push({ id:f.getId(), name:f.getName(), url:f.getUrl(), updated:f.getLastUpdated(), size:f.getSize(), mimeType:f.getMimeType() }); // [cite: 138]
          if (++n >= limit) break;
        }
      }
      return respond_({ ok:true, count:arr.length, files:arr, prefix: prefix || null, folderId: getFolderId_(p) }, e); // [cite: 140]
    }
    throw new Error('Acción no reconocida');
  } catch(err){ return respond_({ ok:false, error: err.message }, e); } // [cite: 143]
}

function doGet(e){ return doPost(e); } // [cite: 144]

function testPermissions() {
  console.log("Comprobando permisos...");
  const folder = getFolder_({}); // [cite: 162]
  console.log("Acceso Drive OK. Carpeta: " + folder.getName()); // [cite: 163]
  const ss = SpreadsheetApp.create("Temp_Permision_Test"); // [cite: 164]
  console.log("Acceso Sheets OK. ID: " + ss.getId());
  DriveApp.getFileById(ss.getId()).setTrashed(true); //
  console.log("Permisos verificados correctamente.");
}