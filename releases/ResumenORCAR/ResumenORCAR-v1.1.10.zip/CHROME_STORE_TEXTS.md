# Textos para Chrome Web Store - ResumenORCAR

## 1. Nombre de la Extensión
**ResumenORCAR**

## 2. Descripción Corta (132 caracteres máximo)
```
Genera resúmenes inteligentes de Órdenes de Reparación usando Inteligencia Artificial. Extrae y analiza datos de CloudActiveReception.
```

## 3. Descripción Completa (máximo 16,000 caracteres)

```
ResumenORCAR es una extensión de Chrome diseñada para profesionales del sector automotriz que utilizan CloudActiveReception. Utiliza Inteligencia Artificial (Google Gemini) para generar resúmenes detallados y análisis inteligentes de las Órdenes de Reparación (OR).

CARACTERISTICAS PRINCIPALES

- Generacion Automatica de Resumenes
- Extrae automaticamente toda la informacion relevante de las OR
- Analiza actuaciones, tiempos de trabajo, comentarios y recambios
- Genera resumenes estructurados y faciles de leer

- Analisis con Inteligencia Artificial
- Utiliza Google Gemini AI para analisis profundos
- Identifica patrones y tendencias en los datos
- Proporciona insights y recomendaciones

- Chat Interactivo con IA
- Interfaz de chat integrada para hacer preguntas sobre la OR
- Respuestas en tiempo real con analisis detallados
- Soporte para adjuntar archivos (PDF, imagenes, documentos)

- Extraccion Completa de Datos
- Información de actuaciones y tiempos por mecánico
- Comentarios externos e internos de la OR
- Comentarios del vehículo y del cliente
- Historial de recambios y peticiones de almacén
- Fechas de matriculación y datos del vehículo

- Almacenamiento en Google Drive
- Guarda automaticamente los resumenes en formato TOML
- Almacena las conversaciones con la IA en formato JSON
- Organizacion automatica por fecha y numero de OR

- Privacidad y Seguridad
- Los datos se procesan localmente en tu navegador
- La API Key se almacena de forma segura en Chrome
- No se envian datos a servidores externos excepto Google Gemini API
- Control total sobre que archivos se guardan en Google Drive

FORMATO DE SALIDA

Los resúmenes se generan en formato TOML (Tom's Obvious, Minimal Language), un formato legible y estructurado que incluye:

- Información básica de la OR (número, fecha, vehículo)
- Resumen de actuaciones con tiempos detallados
- Comentarios organizados por tipo (externos, internos, causas, operaciones)
- Información de recambios y peticiones de almacén
- Metadatos y estadísticas de la OR

CASOS DE USO

- Analisis rapido de OR antes de reuniones
- Generacion de informes para clientes
- Identificacion de patrones en reparaciones
- Documentacion estructurada de trabajos realizados
- Analisis de tiempos y eficiencia del taller

REQUISITOS

- Chrome 114 o superior
- Cuenta de Google con acceso a Google Drive
- API Key de Google Gemini (se configura en la extension)
- Acceso a CloudActiveReception con permisos de edicion de OR

INSTALACION Y CONFIGURACION

1. Instala la extensión desde Chrome Web Store
2. Configura tu API Key de Google Gemini (se puede obtener desde Google AI Studio)
3. Asegúrate de tener acceso a Google Drive
4. Navega a una página de edición de OR en CloudActiveReception
5. Haz clic en el botón "Resumen OR" para comenzar

NOTAS IMPORTANTES

- Esta extension esta disenada especificamente para CloudActiveReception
- Requiere permisos para acceder a las paginas de edicion de OR
- Los datos se procesan segun las politicas de privacidad de Google Gemini
- El usuario es responsable de mantener segura su API Key

Desarrollado por INTURASA para mejorar la productividad y el análisis en talleres automotrices.
```

## 4. Categoría
**Productividad**

## 5. Idioma Principal
**Español (España)**

## 6. Capturas de Pantalla

Necesitarás proporcionar al menos 1 captura de pantalla (máximo 5) con los siguientes requisitos:
- Tamaño: 1280x800 o 640x400 píxeles
- Formato: PNG o JPEG
- Mostrar la extensión en uso

**Sugerencias de capturas:**
1. Botón "Resumen OR" en la página de edición de OR
2. Ventana de chat con análisis generado por IA
3. Ejemplo de resumen TOML guardado en Drive
4. Interfaz de chat con preguntas y respuestas

## 7. Iconos

Los iconos ya están incluidos en la carpeta `images/`:
- icon16.png (16x16)
- icon48.png (48x48)
- icon128.png (128x128)

## 8. Declaración de Uso de Datos

### 8.1 ¿Recopila datos del usuario?
**Sí**

### 8.2 Tipo de datos recopilados
- Información de uso (cuando se usa la extensión)
- Datos de sesión (cookie CAR_SESSION para identificar usuario)

### 8.3 ¿Cómo se utilizan los datos?
- Los datos se utilizan para generar resúmenes con IA
- Los datos se almacenan en Google Drive del usuario
- No se comparten con terceros excepto Google Gemini API

### 8.4 ¿Se venden los datos?
**No**

### 8.5 ¿Se comparten los datos con terceros?
**Sí, con Google Gemini API** (para procesamiento con IA)

## 9. Permisos Explicados (manifest actual)

**Permisos en manifest (solo los necesarios):**
```json
"permissions": ["storage", "cookies", "sidePanel"],
"host_permissions": [
  "https://www.cloudactivereception.com/*",
  "https://generativelanguage.googleapis.com/*",
  "https://script.google.com/*"
]
```

### storage
Se usa `chrome.storage.local` en sidepanel.js y content.js para guardar la API Key de Gemini y no pedirla cada vez.

### cookies
Se usa `chrome.cookies.get` en background.js para leer la cookie de sesión (cloudactivereception.com) e identificar al usuario.

### sidePanel
Se usa `chrome.sidePanel.open` en background.js para abrir el panel lateral cuando el usuario pide el resumen de la OR.

### Permisos eliminados (no se usaban)
- **activeTab**: No se usa en el código. La extensión usa content_scripts en las URLs declaradas en `matches`; no hay acceso desde popup/action a la pestaña activa que requiera este permiso.

### Host Permissions
- **cloudactivereception.com**: Páginas de edición de OR, fetch a getWorkfileTrackings, getActionComments, warehouse_request_messages, getWFComments, etc. (content.js, background.js).
- **generativelanguage.googleapis.com**: Llamadas a la API de Google Gemini (streamGenerateContent, upload de archivos) desde sidepanel.js y content.js.
- **script.google.com**: Guardar y leer archivos en Google Drive mediante Apps Script (background.js).

## 10. URL de Política de Privacidad

Necesitarás alojar el archivo `PRIVACY_POLICY.md` en un sitio web accesible públicamente y proporcionar la URL.

**Ejemplo:** `https://www.inturasa.com/privacy/resumenorcar`

## 11. Información Adicional

### Versión
**1.0.0**

### Desarrollador
**INTURASA**
- Sitio web: https://www.inturasa.com

### Precio
**Gratis**

### Soporte
Proporciona una URL de soporte (puede ser un email o página web):
**support@inturasa.com** o **https://www.inturasa.com/support**

---

## CHECKLIST ANTES DE PUBLICAR

- [ ] Manifest.json corregido y validado
- [ ] Política de privacidad alojada en URL pública
- [ ] Capturas de pantalla preparadas (mínimo 1, máximo 5)
- [ ] Iconos en formato correcto (16, 48, 128)
- [ ] Extensión probada en modo de incógnito
- [ ] Todos los permisos justificados
- [ ] Descripción sin errores ortográficos
- [ ] Versión actualizada si es necesario
- [ ] Archivo ZIP de la extensión listo para subir
