// ========================================
// BACKGROUND SCRIPT - ResumenORCAR
// ========================================
// Maneja las peticiones a Google Drive desde el content script
//
// Aviso de nuevas versiones (badge en el icono): ver update-checker.js
importScripts('update-checker.js');
//
// ID de implementación de la Web App (Implementar → Gestionar implementaciones).
// Debe ser la que tiene "Ejecutar como: Yo" y "Cualquier usuario".
const GOOGLE_SCRIPT_DEPLOYMENT_ID = 'AKfycbzkn-cpJBOoi5L4CAuE9OfpB3wWc-KyJ9DDnfHZVAGB3-TSfjc9lo3VuTKEbtJ4YSctXA';
const GOOGLE_SCRIPT_URL = `https://script.google.com/macros/s/${GOOGLE_SCRIPT_DEPLOYMENT_ID}/exec`;
const API_KEY = '123456789';
// Carpeta IACAR en Drive: https://drive.google.com/drive/folders/1ZGZr-EvgkRxi7ji8LQqh2ADYedYQcPAn
const DRIVE_FOLDER_ID = '1ZGZr-EvgkRxi7ji8LQqh2ADYedYQcPAn';

/**
 * Guarda un archivo en Google Drive
 * @param {Object} data - Datos del archivo (filename, content)
 * @param {Function} sendResponse - Función para enviar respuesta al content script
 */
async function handleSaveToDrive(data, sendResponse) {
    try {
        console.log(`[ResumenORCAR][Drive] ===== INICIO DE GUARDADO =====`);
        console.log(`[ResumenORCAR][Drive] Archivo: ${data.filename}`);
        console.log(`[ResumenORCAR][Drive] Tipo: ${data.type || 'json'}, Ext: ${data.ext || 'json'}`);
        console.log(`[ResumenORCAR][Drive] Folder ID: ${DRIVE_FOLDER_ID}`);
        console.log(`[ResumenORCAR][Drive] Tamaño contenido: ${data.content?.length || 0} caracteres`);

        const requestData = {
            apiKey: API_KEY,
            name: data.filename,
            filename: data.filename,
            content: data.content,
            type: data.type || 'text',
            ext: data.ext || 'txt',
            folderId: DRIVE_FOLDER_ID
        };
        
        console.log(`[ResumenORCAR][Drive] Datos a enviar:`, {
            filename: requestData.filename,
            type: requestData.type,
            ext: requestData.ext,
            folderId: requestData.folderId,
            contentLength: requestData.content?.length || 0
        });

        let response;

        // Si es JSON y el contenido es un objeto, enviar como JSON
        if ((requestData.type || '').toLowerCase() === 'json' && typeof requestData.content === 'object') {
            const jsonBody = JSON.stringify({
                action: 'save',
                apiKey: API_KEY,
                name: requestData.name,
                filename: requestData.filename,
                type: 'json',
                ext: requestData.ext || 'json',
                content: requestData.content,
                folderId: DRIVE_FOLDER_ID
            });

            console.log('[ResumenORCAR][Drive] Enviando como JSON (objeto)');

            response = await fetch(GOOGLE_SCRIPT_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: jsonBody
            });
        } else {
            // Para otros tipos o contenido string, usar form-urlencoded
            console.log('[ResumenORCAR][Drive] Enviando como form-urlencoded');

            const formBody = new URLSearchParams({
                apiKey: API_KEY,
                name: requestData.name || '',
                filename: requestData.filename || '',
                content: requestData.content || '',
                type: requestData.type || 'text',
                ext: requestData.ext || 'txt',
                action: 'save',
                folderId: DRIVE_FOLDER_ID
            }).toString();

            response = await fetch(GOOGLE_SCRIPT_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                },
                body: formBody
            });
        }

        if (!response.ok) {
            const errorText = await response.text().catch(() => 'No se pudo leer el texto de error');
            throw new Error(`HTTP ${response.status}: ${response.statusText} - ${errorText}`);
        }

        const responseText = await response.text();
        console.log(`[ResumenORCAR][Drive] Respuesta texto cruda:`, responseText.substring(0, 500));
        
        let result;
        try {
            result = JSON.parse(responseText);
        } catch (parseError) {
            console.error(`[ResumenORCAR][Drive] Error parseando JSON:`, parseError);
            console.error(`[ResumenORCAR][Drive] Texto completo:`, responseText);
            result = { ok: false, error: `Invalid JSON: ${parseError.message}` };
        }

        console.log(`[ResumenORCAR][Drive] Respuesta del servidor:`, result);
        
        if (result && result.ok) {
            console.log(`[ResumenORCAR][Drive] ✅ Archivo guardado exitosamente: ${data.filename}`);
            if (result.fileId) {
                console.log(`[ResumenORCAR][Drive] ID del archivo: ${result.fileId}`);
                console.log(`[ResumenORCAR][Drive] URL: https://drive.google.com/file/d/${result.fileId}/view`);
            }
            if (result.folderId) {
                console.log(`[ResumenORCAR][Drive] Carpeta destino: ${result.folderId}`);
            }
            sendResponse({ success: true, data: result });
        } else {
            const errorMsg = result?.error || 'Error desconocido';
            console.error(`[ResumenORCAR][Drive] ❌ Error: ${errorMsg}`);
            console.error(`[ResumenORCAR][Drive] Respuesta completa:`, JSON.stringify(result, null, 2));
            sendResponse({ success: false, error: errorMsg });
        }

    } catch (error) {
        console.error('[ResumenORCAR][Drive] ❌ Error:', error.message);
        sendResponse({ success: false, error: error.message });
    }
}

/**
 * Añade una fila a una hoja de cálculo
 * @param {Object} data - Datos (filename, content: array)
 * @param {Function} sendResponse
 */
async function handleAppendRowToSheet(data, sendResponse) {
    try {
        console.log(`[ResumenORCAR][Drive] ===== INICIO APPEND ROW =====`);
        console.log(`[ResumenORCAR][Drive] Archivo: ${data.filename}`);
        console.log(`[ResumenORCAR][Drive] Folder ID usado: ${DRIVE_FOLDER_ID}`);

        const rowData = Array.isArray(data.content) ? data.content : [data.content];

        // Intentar obtener cookie CAR_SESSION si el usuario es desconocido
        if (rowData[0] === 'Desconocido') {
            try {
                const cookie = await chrome.cookies.get({
                    url: "https://www.cloudactivereception.com",
                    name: "CAR_SESSION"
                });
                if (cookie && cookie.value) {
                    let decoded = decodeURIComponent(cookie.value).replace(/^"|"$/g, '');
                    rowData[0] = decoded;
                }
            } catch (cookieErr) {
                console.warn('[ResumenORCAR][Drive] Error recuperando cookie:', cookieErr);
            }
        }

        const formBody = new URLSearchParams({
            apiKey: API_KEY,
            filename: data.filename,
            content: JSON.stringify(rowData),
            action: 'appendrow',
            folderId: DRIVE_FOLDER_ID
        }).toString();

        const response = await fetch(GOOGLE_SCRIPT_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            },
            body: formBody
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`HTTP ${response.status}: ${errorText}`);
        }

        const responseText = await response.text();
        const result = JSON.parse(responseText);

        if (result && result.ok) {
            console.log(`[ResumenORCAR][Drive] ✅ Fila añadida correctamente`);
            sendResponse({ success: true, data: result });
        } else {
            console.error(`[ResumenORCAR][Drive] ❌ Error script: ${result.error}`);
            sendResponse({ success: false, error: result.error });
        }

    } catch (error) {
        console.error('[ResumenORCAR][Drive] ❌ Error en appendRow:', error);
        sendResponse({ success: false, error: error.message });
    }
}

/**
 * Lista archivos de Google Drive con opción de prefijo
 */
async function listDriveFiles(data = {}) {
    try {
        const prefix = data?.prefix || '';
        const limit = data?.limit || 100;

        console.log('[ResumenORCAR][Drive] Listando archivos con prefijo:', prefix);
        console.log('[ResumenORCAR][Drive] Folder ID usado:', DRIVE_FOLDER_ID);

        const params = new URLSearchParams({
            action: 'list',
            limit: limit.toString(),
            folderId: DRIVE_FOLDER_ID
        });

        if (prefix) {
            params.append('prefix', prefix);
        }

        const url = `${GOOGLE_SCRIPT_URL}?${params.toString()}`;
        console.log('[ResumenORCAR][Drive] URL completa:', url);

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Accept': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        const result = await response.json();
        return result;

    } catch (error) {
        console.error('[ResumenORCAR][Drive] Error listando archivos:', error);
        return { ok: false, error: error.message };
    }
}

/**
 * Lee un archivo de Google Drive
 */
async function readFromDrive(data) {
    const filename = String(data?.name || '').trim();

    if (!filename) {
        throw new Error('name requerido');
    }

    try {
        console.log('[ResumenORCAR][Drive] Leyendo archivo:', filename);
        console.log('[ResumenORCAR][Drive] Folder ID usado:', DRIVE_FOLDER_ID);

        // Incluir apiKey siempre para consistencia con save/list y futura validación en GAS
        const url = `${GOOGLE_SCRIPT_URL}?action=read&name=${encodeURIComponent(filename)}&match=exact&as=text&folderId=${encodeURIComponent(DRIVE_FOLDER_ID)}&apiKey=${encodeURIComponent(API_KEY)}`;
        console.log('[ResumenORCAR][Drive] URL de lectura (con apiKey):', url.replace(API_KEY, '***'));

        const res = await fetch(url, { method: 'GET' });
        let json;
        try {
            json = await res.json();
        } catch (_) {
            json = { ok: false, code: res.status, error: 'Invalid JSON' };
        }

        if (!json || !json.ok) {
            console.warn('[ResumenORCAR][Drive] Lectura fallida:', json?.error || res.status, '- Respuesta completa:', json);
        }
        return json;

    } catch (error) {
        console.error('[ResumenORCAR][Drive] Error leyendo archivo:', error);
        return { ok: false, error: error.message };
    }
}

// --- Estado para Side Panel ---
let pendingSidePanelData = null;

// Escuchar mensajes del content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('[ResumenORCAR][Drive] Mensaje recibido:', request.action);

    if (request.action === 'openSidePanel') {
        console.log('[ResumenORCAR][Drive] Solicitud de apertura del Side Panel');
        
        if (!chrome.sidePanel) {
            console.error('[ResumenORCAR][Drive] ❌ chrome.sidePanel NO está disponible. Asegúrate de eliminar y volver a cargar la extensión para que Chrome otorgue el permiso sidePanel.');
            sendResponse({ success: false, error: 'chrome.sidePanel no disponible. Elimina y recarga la extensión.' });
            return false;
        }
        
        const tabId = sender.tab ? sender.tab.id : undefined;
        const windowId = sender.tab ? sender.tab.windowId : undefined;
        
        if (tabId) {
            console.log('[ResumenORCAR][Drive] Abriendo Side Panel para tabId:', tabId, 'windowId:', windowId);
            chrome.sidePanel.open({ tabId: tabId }).then(() => {
                console.log('[ResumenORCAR][Drive] ✅ Side Panel abierto correctamente');
            }).catch((error) => {
                console.error('[ResumenORCAR][Drive] ❌ Error con tabId:', error.message, '- Intentando con windowId...');
                if (windowId) {
                    chrome.sidePanel.open({ windowId: windowId }).then(() => {
                        console.log('[ResumenORCAR][Drive] ✅ Side Panel abierto con windowId');
                    }).catch((err2) => {
                        console.error('[ResumenORCAR][Drive] ❌ Error definitivo abriendo Side Panel:', err2.message);
                    });
                }
            });
        }
        sendResponse({ success: true });
        return false;
    } else if (request.action === 'sendDataToSidePanel') {
        pendingSidePanelData = request.data.datosOR;
        console.log('[ResumenORCAR][Drive] Datos de OR recibidos, enviando al Side Panel...');
        
        chrome.runtime.sendMessage({
            action: 'sidePanelDataReady',
            datosOR: pendingSidePanelData
        }, () => {
            if (chrome.runtime.lastError) {
                console.warn('[ResumenORCAR][Drive] Side Panel no respondió al mensaje directo, usará getSidePanelData');
            }
        });
        
        sendResponse({ success: true });
        return false;
    } else if (request.action === 'getSidePanelData') {
        console.log('[ResumenORCAR][Drive] Side Panel solicita datos, disponible:', !!pendingSidePanelData);
        sendResponse({ success: !!pendingSidePanelData, data: pendingSidePanelData });
        return false;
    } else if (request.action === 'wakeup') {
        console.log('[ResumenORCAR][Drive] Service worker reactivado');
        sendResponse({ success: true, message: 'awake' });
        return true;
    } else if (request.action === 'saveToDrive') {
        handleSaveToDrive(request.data, sendResponse);
        return true;
    } else if (request.action === 'listDriveFiles') {
        listDriveFiles(request.data)
            .then((result) => sendResponse({ success: true, data: result }))
            .catch((err) => sendResponse({ success: false, error: String(err) }));
        return true;
    } else if (request.action === 'readFromDrive') {
        readFromDrive(request.data)
            .then((result) => sendResponse({ success: !!(result && result.ok), data: result }))
            .catch((err) => sendResponse({ success: false, error: String(err) }));
        return true;
    } else if (request.action === 'appendRowToSheet') {
        handleAppendRowToSheet(request.data, sendResponse);
        return true;
    }
});

// Manejar instalación de la extensión
chrome.runtime.onInstalled.addListener((details) => {
    console.log('[ResumenORCAR][Drive] Extensión instalada/actualizada:', details.reason);
});

chrome.runtime.onStartup.addListener(() => {
    console.log('[ResumenORCAR][Drive] Service Worker iniciado');
});

console.log('[ResumenORCAR][Drive] ✅ Background script cargado');

