# Correcciones Necesarias en manifest.json

El archivo `manifest.json` necesita las siguientes correcciones para ser aceptado en Chrome Web Store:

## IMPORTANTE: Correccion por Rechazo

La extension fue rechazada porque solicita permisos que no se usan:
1. `scripting` - ELIMINADO (no se usa chrome.scripting API)
2. `activeTab` - ELIMINADO (no se necesita porque se usan content_scripts)

## Cambios Requeridos

Reemplaza el contenido actual del archivo `manifest.json` con el siguiente:

```json
{
    "manifest_version": 3,
    "name": "ResumenORCAR",
    "version": "1.0.0",
    "description": "Genera resumenes inteligentes de Ordenes de Reparacion (OR) usando Inteligencia Artificial. Extrae informacion de CloudActiveReception y crea analisis detallados con Gemini AI.",
    "author": "INTURASA",
    "permissions": [
        "storage",
        "cookies"
    ],
    "host_permissions": [
        "https://www.cloudactivereception.com/*",
        "https://generativelanguage.googleapis.com/*",
        "https://script.google.com/*"
    ],
    "background": {
        "service_worker": "background.js"
    },
    "content_scripts": [
        {
            "matches": [
                "https://www.cloudactivereception.com/admin/es/workfile/edit/*"
            ],
            "js": [
                "marked.min.js",
                "coberturas_contratos.js",
                "privacidad.js",
                "gemini_prompt.js",
                "content.js"
            ],
            "run_at": "document_end"
        }
    ],
    "icons": {
        "16": "images/icon16.png",
        "48": "images/icon48.png",
        "128": "images/icon128.png"
    },
    "minimum_chrome_version": "114",
    "homepage_url": "https://www.inturasa.com"
}
```

## Cambios Realizados

1. **Permiso `scripting` ELIMINADO**: La extension no usa `chrome.scripting` API. Los scripts se inyectan automaticamente mediante `content_scripts` en el manifest, por lo que este permiso no es necesario.

2. **Permiso `activeTab` ELIMINADO**: La extension no tiene un popup ni un boton de accion. Los scripts se ejecutan automaticamente mediante `content_scripts` que ya tienen acceso al DOM de la pagina. El permiso `activeTab` solo es necesario cuando se accede a la pestaña desde un popup o boton de accion, lo cual NO es el caso.

3. **Descripcion corregida**: Eliminados caracteres mal codificados y descripcion mas clara

4. **Campo "author" añadido**: Identifica al desarrollador

5. **Campo "homepage_url" añadido**: URL del sitio web del desarrollador

## Por que se eliminaron estos permisos

### `scripting`
- La extension NO usa `chrome.scripting.executeScript()` ni ninguna otra funcion de la API `chrome.scripting`
- Los scripts se inyectan automaticamente mediante la declaracion `content_scripts` en el manifest.json
- El permiso `scripting` solo es necesario cuando se inyectan scripts dinamicamente usando `chrome.scripting.executeScript()`, lo cual NO es el caso

### `activeTab`
- La extension NO tiene un popup (action) ni un boton de accion en la barra de herramientas
- Los scripts se ejecutan automaticamente mediante `content_scripts` que ya tienen acceso completo al DOM de la pagina
- El permiso `activeTab` solo es necesario cuando:
  - Tienes un popup que necesita acceder al contenido de la pestaña activa
  - Tienes un boton de accion que ejecuta codigo que necesita acceso a la pestaña
  - Usas `chrome.tabs.executeScript()` desde un popup o background script
- NINGUNO de estos casos aplica a esta extension

## Permisos que se mantienen y por que

- **storage**: Se usa para almacenar la API Key de Gemini localmente (`chrome.storage.local`)
- **cookies**: Se usa para leer la cookie `CAR_SESSION` (`chrome.cookies.get()`)
- **host_permissions**: Necesarios para acceder a los dominios especificados

## Validacion

Despues de hacer los cambios, valida el manifest.json en:
- Chrome: `chrome://extensions` -> Modo de desarrollador -> Cargar extension sin empaquetar
- O usa la herramienta de validacion: https://developer.chrome.com/docs/extensions/mv3/manifest/
