# Instrucciones para Publicar ResumenORCAR en Chrome Web Store

## Paso 1: Preparar la Extensión

### 1.1 Actualizar manifest.json
- Abre el archivo `manifest.json`
- Reemplaza su contenido con el código proporcionado en `MANIFEST_CORRECCIONES.md`
- Guarda el archivo

### 1.2 Verificar Archivos Necesarios
Asegúrate de tener estos archivos en la carpeta `ResumenORCAR`:
- ✅ manifest.json (actualizado)
- ✅ background.js
- ✅ content.js
- ✅ marked.min.js
- ✅ coberturas_contratos.js
- ✅ privacidad.js
- ✅ gemini_prompt.js
- ✅ images/icon16.png
- ✅ images/icon48.png
- ✅ images/icon128.png

### 1.3 Crear Archivo ZIP
1. Selecciona todos los archivos de la carpeta `ResumenORCAR` (excepto archivos .md de documentación)
2. Crea un archivo ZIP con el nombre `ResumenORCAR-v1.0.0.zip`
3. **IMPORTANTE**: El ZIP debe contener los archivos directamente, NO una carpeta dentro

## Paso 2: Preparar Política de Privacidad

### 2.1 Alojar Política de Privacidad
1. Copia el contenido de `PRIVACY_POLICY.md`
2. Alójalo en un sitio web público accesible
3. Anota la URL completa (ejemplo: `https://www.inturasa.com/privacy/resumenorcar`)

**Opciones para alojar:**
- Tu sitio web de INTURASA
- GitHub Pages (gratis)
- Google Sites (gratis)
- Cualquier servicio de hosting

## Paso 3: Preparar Capturas de Pantalla

### 3.1 Requisitos
- **Cantidad**: Mínimo 1, máximo 5
- **Tamaño**: 1280x800 o 640x400 píxeles
- **Formato**: PNG o JPEG
- **Contenido**: Debe mostrar la extensión en uso

### 3.2 Sugerencias de Capturas
1. **Captura 1**: Botón "Resumen OR" visible en la página de edición de OR
2. **Captura 2**: Ventana de chat con análisis generado por IA
3. **Captura 3**: Ejemplo de resumen mostrando datos estructurados
4. **Captura 4**: Interfaz de chat con preguntas y respuestas

### 3.3 Cómo Hacer las Capturas
1. Abre Chrome y navega a una página de edición de OR en CloudActiveReception
2. Haz clic en el botón "Resumen OR"
3. Espera a que se genere el resumen
4. Haz captura de pantalla (Windows: Win + Shift + S, Mac: Cmd + Shift + 4)
5. Recorta y ajusta el tamaño si es necesario

## Paso 4: Crear Cuenta de Desarrollador

### 4.1 Registrarse en Chrome Web Store
1. Ve a: https://chrome.google.com/webstore/devconsole
2. Inicia sesión con tu cuenta de Google
3. Paga la tarifa única de $5 USD (solo se paga una vez)
4. Completa el formulario de información del desarrollador

## Paso 5: Subir la Extensión

### 5.1 Subir el ZIP
1. En Chrome Web Store Developer Dashboard, haz clic en "Nuevo elemento"
2. Sube el archivo ZIP `ResumenORCAR-v1.0.0.zip`
3. Espera a que se valide (puede tardar unos minutos)

### 5.2 Completar Información del Listado

Usa los textos del archivo `CHROME_STORE_TEXTS.md`:

#### Información Básica
- **Nombre**: ResumenORCAR
- **Descripción corta**: (132 caracteres máximo)
  ```
  Genera resúmenes inteligentes de Órdenes de Reparación usando Inteligencia Artificial. Extrae y analiza datos de CloudActiveReception.
  ```

#### Descripción Completa
Copia el texto completo de la sección "3. Descripción Completa" del archivo `CHROME_STORE_TEXTS.md`

#### Categoría
- Selecciona: **Productividad**

#### Idioma
- Selecciona: **Español (España)**

#### Capturas de Pantalla
- Sube las capturas preparadas (mínimo 1)

#### Iconos
- Los iconos se extraerán automáticamente del ZIP

#### Política de Privacidad
- Ingresa la URL donde alojaste `PRIVACY_POLICY.md`

#### Declaración de Uso de Datos
Responde las preguntas:
- **¿Recopila datos del usuario?** → Sí
- **Tipo de datos**: Información de uso, datos de sesión
- **¿Cómo se utilizan?** → Para generar resúmenes con IA, almacenamiento en Google Drive
- **¿Se venden los datos?** → No
- **¿Se comparten con terceros?** → Sí, con Google Gemini API

#### Permisos
Explica cada permiso usando las explicaciones del archivo `CHROME_STORE_TEXTS.md`:
- storage: Para almacenar la API Key localmente
- cookies: Para leer la cookie de sesion
- Host permissions: Explicar cada dominio

NOTAS IMPORTANTES:
- El permiso `scripting` fue eliminado porque no se usa. Los scripts se inyectan automaticamente mediante content_scripts en el manifest.json.
- El permiso `activeTab` fue eliminado porque no se usa. La extension usa content_scripts que ya tienen acceso al DOM. activeTab solo es necesario cuando se accede desde un popup o boton de accion.

#### Información Adicional
- **Versión**: 1.0.0
- **Desarrollador**: INTURASA
- **Sitio web**: https://www.inturasa.com
- **Soporte**: support@inturasa.com o URL de soporte

## Paso 6: Revisar y Enviar

### 6.1 Revisión Final
Antes de enviar, verifica:
- [ ] Todos los campos están completos
- [ ] La descripción no tiene errores
- [ ] Las capturas de pantalla son claras
- [ ] La política de privacidad es accesible
- [ ] Los permisos están justificados
- [ ] El ZIP se subió correctamente

### 6.2 Enviar para Revisión
1. Haz clic en "Enviar para revisión"
2. El proceso de revisión puede tardar de 1 a 7 días hábiles
3. Recibirás un email cuando se complete la revisión

## Paso 7: Después de la Publicación

### 7.1 Si es Aceptada
- La extensión estará disponible públicamente
- Recibirás estadísticas de instalaciones
- Podrás actualizar la extensión cuando sea necesario

### 7.2 Si es Rechazada
- Revisa los comentarios del revisor
- Corrige los problemas señalados
- Vuelve a enviar para revisión

## Checklist Final

Antes de enviar, asegúrate de tener:

- [ ] manifest.json actualizado y validado
- [ ] Archivo ZIP creado correctamente
- [ ] Política de privacidad alojada y accesible
- [ ] Al menos 1 captura de pantalla preparada
- [ ] Todos los textos copiados del archivo CHROME_STORE_TEXTS.md
- [ ] Cuenta de desarrollador creada y pagada ($5 USD)
- [ ] Extensión probada en modo de incógnito
- [ ] Todos los permisos justificados

## Recursos Útiles

- **Documentación oficial**: https://developer.chrome.com/docs/webstore/
- **Guía de políticas**: https://developer.chrome.com/docs/webstore/program-policies/
- **Foro de desarrolladores**: https://groups.google.com/a/chromium.org/g/chromium-extensions

## Notas Importantes

IMPORTANTE: La revision puede tardar varios dias. Se paciente.

IMPORTANTE: Si hay problemas, Google te enviara un email con detalles.

IMPORTANTE: Manten actualizada la politica de privacidad si cambias como se manejan los datos.

IMPORTANTE: Las actualizaciones tambien pasan por revision, pero suelen ser mas rapidas.
