# Registra una tarea programada de Windows que comprueba y aplica
# actualizaciones de ResumenORCAR en segundo plano, sin ventana visible y sin
# intervencion del usuario. Ejecutar UNA SOLA VEZ por equipo (tras instalar o
# actualizar manualmente por primera vez a una version que ya incluya este
# script y update-checker.js con auto-recarga).
#
# No requiere permisos de administrador: la tarea se registra para el usuario
# que la ejecuta y corre en su sesion, con los mismos permisos de carpeta que
# ya tiene para usar Chrome y esta carpeta.

$ErrorActionPreference = 'Stop'

$InstallDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ScriptPath = Join-Path $InstallDir 'actualizar.ps1'
$TaskName = 'ResumenORCAR-AutoUpdate'

if (-not (Test-Path $ScriptPath)) {
    throw "No se encontro actualizar.ps1 en $InstallDir."
}

$action = New-ScheduledTaskAction -Execute 'powershell.exe' `
    -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$ScriptPath`" -Silencioso"

$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(5) `
    -RepetitionInterval (New-TimeSpan -Hours 4) -RepetitionDuration ([TimeSpan]::MaxValue)

$settings = New-ScheduledTaskSettingsSet -Hidden -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable

Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings `
    -Description 'Comprueba y aplica actualizaciones de ResumenORCAR en segundo plano, sin avisar al usuario.' `
    -Force | Out-Null

Write-Host "Tarea programada '$TaskName' creada."
Write-Host "Comprobara actualizaciones cada 4 horas (primera pasada en 5 minutos)."
Write-Host "Log de cada comprobacion: $(Join-Path $InstallDir 'actualizar.log')"
